Bitte beachten:

Da f�r die Umkippanimation sowie die Attack Animation auf einem 96 X 96 er Tile schlichtweg zu wenig Platz vorhanden war,habe ich selbige in einer Gr�sse von 128 X 128 gerendert.
Dies bedeutet, dass sich der Nullpunkt im Vergleich zum restlichen Sprite f�r diese zwei Animationen bei -16 / -16 befindet ...
Deswegen befindet sich diese Animationen auch in einem Extraordner.

Reiner

Attention :

Because there wasn�t enough space to display the full tipping over Animation and Attack Animation at an 96 X 96 Tile, i have rendered the two Animations in a size of 128 x 128.
This means that the zero point of this animations is -16 /-16 compared to the rest of the sprite ...
That�s why they are in an extrafolder.

Reiner