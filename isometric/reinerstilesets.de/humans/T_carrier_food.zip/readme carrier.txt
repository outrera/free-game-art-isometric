Bitte beachten:

Dieses carrier Spriteset geh�rt zum Gesamtpaket carrier , dessen Kernst�ck der carrier basic ist . Die Animationen dieses Spritepaketes sind mit denen des carrier basic verkn�pft ...

Da f�r einige der Animationen auf einem 96 X 96 er Tile schlichtweg zu wenig Platz vorhanden war,habe ich selbige in einer Gr�sse von 128 X 128 gerendert.
Dies bedeutet, dass sich der Nullpunkt im Vergleich zum restlichen Sprite f�r diese zwei Animationen bei -16 / -16 befindet ...
Deswegen befindet sich diese Animationen auch in einem Extraordner.

Reiner

Attention :

This carrier Spriteset is part of the carrier package. The mainpiece of this package is the carrier basic . The animations of this Spriteset are connected to the animations of the carrier base Sprite ...

Because there wasn�t enough space to display some of the Animations at an 96 X 96 Tile, i have rendered them in a size of 128 x 128.
This means that the zero point of this animations is -16 /-16 compared to the rest of the sprite ...
That�s why they are in an extrafolder.

Reiner

http://www.reinerstileset.de

reiner.prokein@t-online.de