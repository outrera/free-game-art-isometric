//---------------------------------------------------------------------------------------------------------------------------------------------------

#define NAME "A.T.D. Brodie of Brodie"
#define TITLE "Ad-Infinitum"

#define WIN32_LEAN_AND_MEAN

const int true=1;
const int false=0;

#include <windows.h>
#include <windowsx.h>
#pragma comment(lib, "ddraw.lib")
#include <ddraw.h>
//#include <dinput.h>
#include <mmsystem.h>
//#include <stdio.h>
#include <math.h>
#include <stdlib.h>  // abs,  malloc, free

#include <string.h>   // fget,
#include <stdio.h>

//#include <Gdiplus.h>

#define BUFFERS     2  // note buffers are system memory therefore fake! (CZAR)


#include "files.h"
#include "global_vars.h"
#include "structures.h"
#include "platoons.h"
#include "prototypes.h"
#include "resources.h"
#include "rivers.h"
#include "road.h"
#include "workers.h"
#include "set_towns.h"
#include "status_bar.h"
#include "worlds.h"
#include "coast.h"
#include "hills.h"
#include "plant.h"
#include "unit_movement.h"
#include "node.h"
#include "release.h"
#include "home_worlds.h"

#include "run.h"
#include "town_marker.h"
#include "faction_flags.h"

#include "draw_world.h"
//#include "input.h"
#include "buttons.h"
#include "aliens.h"

BOOL LoadMyImage( LPDIRECTDRAWSURFACE lpDDS, LPSTR szImage )
{
    HBITMAP         hbm;
    HDC             hdcImage= NULL;
    HDC             hdcSurf = NULL;
    BOOL            bReturn = FALSE;


    ZeroMemory( &ddsd, sizeof( ddsd ) );
    ddsd.dwSize = sizeof( ddsd );

    if ( FAILED( lpDDS->GetSurfaceDesc( &ddsd ) ) )
	{
		debugfile ("failed to link surface in load.\n",1 );
		goto Exit;
    }

    // Try loading the image.
    hbm = ( HBITMAP )LoadImage( NULL, szImage,
            IMAGE_BITMAP, ddsd.dwWidth,
            ddsd.dwHeight, LR_LOADFROMFILE | LR_CREATEDIBSECTION );

    if ( hbm == NULL )
	{
		debugfile ("no resourse.\n",1 );
		OutputDebugString( " Couldn't find the resource.\n" );
        goto Exit;
    }

    // Create a DC and select the image into it.
    hdcImage = CreateCompatibleDC( NULL );
    SelectObject( hdcImage, hbm );

    // Get a DC for the surface.
    if ( FAILED( lpDDS->GetDC( &hdcSurf ) ) )
	{
		debugfile ("no dc.\n",1 );
		OutputDebugString( "Couldn't get a DC.\n" );
        goto Exit;
    }

    // The BitBlt will perform format conversion as necessary.
    if ( BitBlt( hdcSurf, 0, 0, ddsd.dwWidth, ddsd.dwHeight,
        hdcImage, 0, 0, SRCCOPY ) == FALSE )
	{
		debugfile ("blt failed.\n",1 );
		OutputDebugString( "Blt failed.\n" );
        goto Exit;
    }

	// Success.
    bReturn = TRUE;

Exit:
    // Clean up everything.
    if ( hdcSurf )
        lpDDS->ReleaseDC( hdcSurf );
    if ( hdcImage )
        DeleteDC( hdcImage );
    if( hbm )
        DeleteObject( hbm );

    return bReturn;
}


#include "nebula.h"
#include "gasgiant.h"
#include "set_worlds.h"
#include "creat_galaxy.h"
#include "mapszooms.h"
#include "solar_system.h"
#include "screen_maps.h"
#include "screen_system.h"
#include "update.h"
#include "palette.h"
#include "namernd.h"

static BOOL doInit( HINSTANCE hInstance, int nCmdShow )
{

    WNDCLASS            wc;
   // DDSURFACEDESC       ddsd;
   // DDSCAPS             ddscaps;    // Surface capabilities structure.

   //get screen size
    screen_x=GetSystemMetrics( SM_CXSCREEN );
    screen_y=GetSystemMetrics( SM_CYSCREEN );

     // Set up and register window class.

wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = WindowProc;
    wc.cbClsExtra = 0;
    wc.cbWndExtra = 0;
    wc.hInstance = hInstance;
    wc.hIcon = LoadIcon( hInstance, IDI_APPLICATION );
    wc.hCursor = LoadCursor( NULL, IDC_ARROW );
    wc.hbrBackground = NULL;
    wc.lpszMenuName = NAME;
    wc.lpszClassName = NAME;
    RegisterClass( &wc );

	// Create a fullscreen window.
    hwnd = CreateWindowEx(
        WS_EX_TOPMOST,
        NAME,
        TITLE,
        WS_POPUP,
        0, 0,
        GetSystemMetrics( SM_CXSCREEN ),
        GetSystemMetrics( SM_CYSCREEN ),
        NULL,
        NULL,
        hInstance,
        NULL );

    if ( !hwnd )
    {
		debugfile ("hwnd false\n", 1 );
		return FALSE;
    }

    ShowWindow( hwnd, nCmdShow );
    UpdateWindow( hwnd );


    // Create the DirectDraw object -- we just need an IDirectDraw
    // interface so we won't bother to query an IDirectDraw2.
    if ( FAILED( DirectDrawCreate( NULL, &lpDD, NULL ) ) )
	{
		  debugfile ("Couldn't creat DirectDraw object\n", 1 );
          return Fail( hwnd, "Couldn't create DirectDraw object.\n" );
	}

	// Get exclusive mode.
    if ( FAILED( lpDD->SetCooperativeLevel( hwnd,
                        DDSCL_EXCLUSIVE | DDSCL_FULLSCREEN ) ) )
	{
          debugfile ("Couldn't set cooperative level.\n",1 );
          return Fail( hwnd, "Couldn't set cooperative level.\n" );
	}

    // Set the display mode.
	if ( FAILED( lpDD->SetDisplayMode( screen_x, screen_y, Color_bits ) ) )
	{
		  debugfile ("Couldn't set display mode.\n",1 );
          return Fail( hwnd, "Couldn't set display mode.\n" );
	}



	// Create the primary surface.      (with back buffer(s) CZAR)


    ddsd.dwSize = sizeof( ddsd );
    ddsd.dwFlags = DDSD_CAPS | DDSD_BACKBUFFERCOUNT;
    ddsd.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE |
    					  DDSCAPS_FLIP |
                          DDSCAPS_COMPLEX |
						  DDSCAPS_SYSTEMMEMORY ;  //MUST BE SYSTEM MEMORY AS MANY SHRINKING OPERATIONS
                              //|NULL;
    ddsd.dwBackBufferCount = BUFFERS;

	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSPrimary, NULL ) ) )
	{
		debugfile ("Couldn't create primary surface.\n",1 );
		return Fail( hwnd, "Couldn't create primary surface.\n" );
	}

   // Get a pointer to the back buffer.
    ddscaps.dwCaps = DDSCAPS_BACKBUFFER;
    if ( FAILED( lpDDSPrimary->GetAttachedSurface( &ddscaps,
		                                           &lpDDSBack ) ) )
	{
		debugfile ("Couldn't find the back buffer.\n",1 );
        return Fail( hwnd, "Couldn't find the back buffer.\n" );
    }


    //palettes();/////////////////////////////////////////////////////////


    // Get the pixel format of the primary and
    // use it to create values for pure green and pure blue.

    //dwGreen =254;// ddpf.dwGBitMask;
    //dwBlue =253;// ddpf.dwBBitMask;

	if (Color_bits==16)
	{
		//(r/7) | ((g/3)*64) | ((b/7)*2048)
		//dwGreen =RGB((255/7),((128/3)*64),((255/7)*2048));
		//int color = (r/7) | ((g/3)*64) | ((b/7)*2048);
		dwGreen =RGB(find_red,find_green,find_bleu) ;
		//dwBlue =RGB(30,30,30) ;

		//dwGreen =RGB(0,0,0) ;
		//dwBlue =RGB(0,0,0) ;
	}
	else
	{
		//dwBlue =RGB(200,150,200);///////////////////////////////
		//dwGreen =RGB(30,5,30) ;
		dwGreen =RGB(255,128,255);//////////////////////////

    }


    dwBackground =RGB(0,0,0);///black

    // Create the first off-screen surface.
    ddsd.dwFlags = DDSD_CAPS | DDSD_HEIGHT |
		           DDSD_WIDTH | DDSD_CKSRCBLT;
    ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN |
						  DDSCAPS_SYSTEMMEMORY ;  //MUST BE SYSTEM MEMORY AS MANY SHRINKING OPERATIONS
	ddsd.dwHeight =   screen_y ;
	ddsd.dwWidth  =   screen_x ;
    // Set the source color key to green.
	ddsd.ddckCKSrcBlt.dwColorSpaceLowValue = dwGreen;
	ddsd.ddckCKSrcBlt.dwColorSpaceHighValue = dwGreen;

    if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffScreen, NULL ) ) )
	{
		debugfile ("couldn't create off-screen.\n",1 );
		return Fail( hwnd, "Couldn't create off-screen.\n" );
	}

	////////////title screen/////////////
	FillScreen();
	lpDDSPrimary->Flip( NULL, DDFLIP_WAIT );
	FillScreen();
     ZeroMemory( &ddbltfx, sizeof( ddbltfx ) );
   ddbltfx.dwSize = sizeof( ddbltfx );

   // Fill the surface with background colour .
   ddbltfx.dwFillColor = dwBackground;
   lpDDSBack->Blt( NULL, NULL,        // black out screen
							NULL,
						DDBLT_COLORFILL |
						DDBLT_WAIT, &ddbltfx );


	ddsd.dwHeight = 256;
	ddsd.dwWidth =  256;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffAdInfinitum, NULL ) ) )
	{
		debugfile ("Couldn't create off-screen AdInfinitum.\n",1 );
		//return Fail( hwnd, "Couldn't create off-screen AdInfinitum.\n" );
	}
	ddsd.dwHeight = 110;
	ddsd.dwWidth = 256;
    if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffSuns, NULL ) ) )
	{
		debugfile ("Couldn't create offscreen surface",5 );
		//return Fail( hwnd, "Couldn't create offscreen suns.\n" );
	}
	if ( !LoadMyImage( lpDDSOffAdInfinitum, "grafix/darkworld.bmp" ) )
	{
		debugfile ("Couldn't load offscreen darkworld.bmp.\n",1 );
		//return Fail( hwnd, "Couldn't load offscreen darkworld.bmp.\n" );
	}
	  if ( !LoadMyImage( lpDDSOffSuns, "grafix/suns.bmp" ) )
	{
		//return Fail( hwnd, "Couldn't load offscreen SmaleStars.\n" );
	}

	lpDDSBack->BltFast( (screen_x/2)-(256/2),(screen_y/2)-(256/2) , lpDDSOffAdInfinitum, NULL,
										   DDBLTFAST_WAIT |
										   DDBLTFAST_SRCCOLORKEY );
	lpDDSBack->BltFast( (screen_x/2)-(256/2),(screen_y-(110)) , lpDDSOffSuns, NULL,
										   DDBLTFAST_WAIT |
										   DDBLTFAST_SRCCOLORKEY );
	lpDDSPrimary->Flip( NULL, DDFLIP_WAIT );
	debugfile ("done title screen.\n",1 );
	//////release from memory title screen and credits ///////////
	if ( lpDDSOffAdInfinitum != NULL )
			{
				lpDDSOffAdInfinitum->Release();
				lpDDSOffAdInfinitum = NULL;
			}
	if ( lpDDSOffSuns != NULL )
			{
				lpDDSOffSuns->Release();
				lpDDSOffSuns = NULL;
			}

	//////////////////creat other surfaces///////////////////
	    /*
        ddsd.dwHeight = 600;
        	ddsd.dwWidth =  800;
        	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffOne, NULL ) ) )
        	{
        		debugfile ("Couldn't create off-screen one",1 );
        		return Fail( hwnd, "Couldn't create off-screen one.\n" );
			}
	*/



	ddsd.dwHeight = 32;
	ddsd.dwWidth = 32;

   if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffCursor, NULL ) ) )
	{
		debugfile ("Couldn't create offscreen cursor",1 );
		return Fail( hwnd, "Couldn't create offscreen Cursor.\n" );
	}

	// Create the letters offscreen surface.
	ddsd.dwHeight = 200;
	ddsd.dwWidth = 600;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffLetters, NULL ) ) )
	{
		debugfile ("Couldn't create offscreen surface",6 );
		return Fail( hwnd, "Couldn't create offscreen letters.\n" );
	}


    // Create the third offscreen surface.
	    /*
        ddsd.dwHeight = 600;
        	ddsd.dwWidth = 800;
        	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffThree, NULL ) ) )
        	{
        		debugfile ("Couldn't create offscreen 3",1 );
        		return Fail( hwnd, "Couldn't create offscreen three.\n" );
			}
    */

   // Create the smale stars offscreen surface.
    ddsd.dwHeight = 50;
    ddsd.dwWidth = 50;
    if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffSmaleStars, NULL ) ) )
	{
		debugfile ("Couldn't create offscreen smalle stars",1 );
		return Fail( hwnd, "Couldn't create offscreen smale stars.\n" );
	}

//planet_see_y= screen_y-(45/ZooM)-(48*(45/ZooM))+((45/ZooM)*ZooM);
   // Create the letters offscreen surface.
    //int screenytoget= screen_y-(screen_y-(45/ZooM)-(48*(45/ZooM))+((45/ZooM)*ZooM));
	ddsd.dwHeight =  screen_y;
	ddsd.dwWidth = screen_x;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffWorlds, NULL ) ) )
	{
		debugfile ("Couldn't create offscreen surface",8 );
		return Fail( hwnd, "Couldn't create offscreen worlds.\n" );
	}

	 // Create worlds 1 offscreen surface.
	ddsd.dwHeight = 512;
	ddsd.dwWidth = 512;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffWorlds1, NULL ) ) )
	{
		debugfile ("Couldn't create offscreen surface",9 );
		return Fail( hwnd, "Couldn't create offscreen worlds1\n" );
	}

	// Create worlds 2 offscreen surface.
	ddsd.dwHeight = 512;
	ddsd.dwWidth = 512;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffWorlds2, NULL ) ) )
	{
		debugfile ("Couldn't create offscreen worlds2 ",10 );
		return Fail( hwnd, "Couldn't create offscreen worlds2\n" );
	}

	// Create worlds 3 offscreen surface.
	ddsd.dwHeight = 512;
	ddsd.dwWidth = 512;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffWorlds3, NULL ) ) )
	{
		debugfile ("Couldn't create offscreen worlds3 ",11 );
		return Fail( hwnd, "Couldn't create offscreen worlds3\n" );
	}

	// Create worlds 4 offscreen surface.
	ddsd.dwHeight = 512;
	ddsd.dwWidth = 512;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffWorlds4, NULL ) ) )
	{
		debugfile ("Couldn't create offscreen worlds4 ",12 );
		return Fail( hwnd, "Couldn't create offscreen worlds4\n" );
	}

	// Create worlds 5 offscreen surface.
	ddsd.dwHeight = 512;
	ddsd.dwWidth = 512;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffWorlds5, NULL ) ) )
	{
		debugfile ("Couldn't create offscreen Worlds5 ",13 );
		return Fail( hwnd, "Couldn't create offscreen worlds5\n" );
	}

	// Create worlds 6 offscreen surface.
	ddsd.dwHeight = 512;
	ddsd.dwWidth = 512;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffWorlds6, NULL ) ) )
	{
		debugfile ("Couldn't create offscreen Worlds6 ",14 );
		return Fail( hwnd, "Couldn't create offscreen worlds6\n" );
	}

	// Create worlds 7 offscreen surface.
	ddsd.dwHeight = 512;
	ddsd.dwWidth = 512;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffWorlds7, NULL ) ) )
	{
		debugfile ("Couldn't create offscreen Worlds7 ",15 );
		return Fail( hwnd, "Couldn't create offscreen worlds7\n" );
	}

	// Create worlds 8 offscreen surface.
	ddsd.dwHeight = 512;
	ddsd.dwWidth = 512;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffWorlds8, NULL ) ) )
	{
		debugfile ("Couldn't create offscreen Worlds8 ",16 );
		return Fail( hwnd, "Couldn't create offscreen worlds8\n" );
	}

	// Create worlds 9 offscreen surface.
	ddsd.dwHeight = 512;
	ddsd.dwWidth = 512;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffWorlds9, NULL ) ) )
	{
		debugfile ("Couldn't create offscreen Worlds9 ",17 );
		return Fail( hwnd, "Couldn't create offscreen worlds9\n" );
	}
// Create flagspoles offscreen surface.
	ddsd.dwHeight = 40;
	ddsd.dwWidth = 30;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffflagpole, NULL ) ) )
	{
		debugfile ("Couldn't create offscreen flagpole ",17 );
		return Fail( hwnd, "Couldn't create offscreen flagpole\n" );
	}
// Create flags1 offscreen surface.
	ddsd.dwHeight = 260;
	ddsd.dwWidth = 720;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffflags1, NULL ) ) )
	{
		debugfile ("Couldn't create offscreen flags1 ",17 );
		return Fail( hwnd, "Couldn't create offscreen flags1\n" );
	}
// Create flags2 offscreen surface.
	ddsd.dwHeight = 72;
	ddsd.dwWidth = 90;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffflags2, NULL ) ) )
	{
		debugfile ("Couldn't create offscreen flags2 ",17 );
		return Fail( hwnd, "Couldn't create offscreen flags2\n" );
	}

////////////obsolet////////////
	ddsd.dwHeight = 280;
	ddsd.dwWidth =  280;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffMap, NULL ) ) )
	{
		debugfile ("Couldn't create offscreen map",1 );
		return Fail( hwnd, "Couldn't create offscreen map.\n" );
	}

	// Create the second offscreen surface using the surface

	ddsd.dwHeight = 240;
	ddsd.dwWidth =  240;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffButtons, NULL ) ) )
	{
		debugfile ("Couldn't create offscreen buttons",1 );
		return Fail( hwnd, "Couldn't create offscreen buttons.\n" );
	}
	// Create the jump1 offscreen surface.
	ddsd.dwHeight = 80;
	ddsd.dwWidth = 80;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffJump1, NULL ) ) )
	{
		debugfile ("Couldn't create offscreen surface jump1 ",1 );
		return Fail( hwnd, "Couldn't create offscreen jump1.\n" );
	}
   // Create jump2 offscreen surface.
	ddsd.dwHeight = 160;
	ddsd.dwWidth = 160;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffJump2, NULL ) ) )
	{
		debugfile ("Couldn't create offscreen surface jump2 ",2 );
		return Fail( hwnd, "Couldn't create offscreen jump2.\n" );
	}
   // Create the jump3 offscreen surface.
	ddsd.dwHeight = 60;
	ddsd.dwWidth = 300;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffJump3, NULL ) ) )
	{
		debugfile ("Couldn't create offscreen surface jump 3 ",3 );
		return Fail( hwnd, "Couldn't create offscreen jump3.\n" );
	}

	// Create the globes offscreen surface.
	ddsd.dwHeight = 240;
	ddsd.dwWidth = 240;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffGlobes, NULL ) ) )
	{
		debugfile ("Couldn't create offscreen surface",4 );
		return Fail( hwnd, "Couldn't create offscreen globes.\n" );
	}

	 // Create the map colors offscreen surface.
	ddsd.dwHeight = 200;
	ddsd.dwWidth = 600;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffMap_color, NULL ) ) )
	{
		debugfile ("Couldn't create offscreen surface",7 );
		return Fail( hwnd, "Couldn't create offscreen Map_color.\n" );
	}

    ddsd.dwHeight = 40;
	ddsd.dwWidth = 270;

	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffBar1, NULL ) ) )
	{
		debugfile ("Couldn't create offscreen bar1",5 );
	}

	  if ( !LoadMyImage( lpDDSOffBar1, "grafix/generating.bmp" ) )
	{
		debugfile ("Couldn't load offscreen bar1",5 );
	}

	debugfile ("created base surfaces.\n",1 );

	/////creat units//////
	//civil unites///////
	ddsd.dwHeight = 98;
	ddsd.dwWidth = 223;

	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffNoble, NULL ) ) )
	{
		debugfile ("Couldn't create offscreen noble",1 );
	}

	  if ( !LoadMyImage( lpDDSOffNoble, "grafix/Unit_Noble.bmp" ) )
	{
		debugfile ("Couldn't load offscreen noble",1 );
	}
	///military units
	ddsd.dwHeight = 147;
	ddsd.dwWidth = 224;

	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffInfantry_1, NULL ) ) )
	{
		debugfile ("Couldn't create offscreen Infantry_1",1 );
	}

	  if ( !LoadMyImage( lpDDSOffInfantry_1, "grafix/Unit_Infantry_1.bmp" ) )
	{
		debugfile ("Couldn't load offscreen Infantry_1",1 );
	}
	/////////
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffInfantry_2, NULL ) ) )
	{
		debugfile ("Couldn't create offscreen Infantry_2",1 );
	}

	  if ( !LoadMyImage( lpDDSOffInfantry_2, "grafix/Unit_Infantry_2.bmp" ) )
	{
		debugfile ("Couldn't load offscreen Infantry_2",1 );
	}
	///////////
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffInfantry_3, NULL ) ) )
	{
		debugfile ("Couldn't create offscreen Infantry_3",1 );
	}

	  if ( !LoadMyImage( lpDDSOffInfantry_3, "grafix/Unit_Infantry_3.bmp" ) )
	{
		debugfile ("Couldn't load offscreen Infantry_3",1 );
	}
	///////////
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffInfantry_4, NULL ) ) )
	{
		debugfile ("Couldn't create offscreen Infantry_4",1 );
	}

	  if ( !LoadMyImage( lpDDSOffInfantry_4, "grafix/Unit_Infantry_4.bmp" ) )
	{
		debugfile ("Couldn't load offscreen Infantry_4",1 );
	}
	///////////
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffInfantry_5, NULL ) ) )
	{
		debugfile ("Couldn't create offscreen Infantry_5",1 );
	}

	  if ( !LoadMyImage( lpDDSOffInfantry_5, "grafix/Unit_Infantry_5.bmp" ) )
	{
		debugfile ("Couldn't load offscreen Infantry_5",1 );
	}


	//  ������������������� Load our images. ����������������������
	debugfile ("loading surfaces.\n",1 );

		/*
		if ( !LoadMyImage( lpDDSOffOne, "screen_main.bmp" ) )
			{
				return Fail( hwnd, "Couldn't load offscreen one.\n" );
			}
	*/

	if ( !LoadMyImage( lpDDSOffButtons, "grafix/butons.bmp" ) )
	{
		debugfile ( "Couldn't load buttons.\n",1 );

	}

	    /*
        if ( !LoadMyImage( lpDDSOffThree, "empty.bmp" ) )
        	{
        		return Fail( hwnd, "Couldn't load offscreen three.\n" );
			}
    */

   if ( !LoadMyImage( lpDDSOffCursor, "grafix/cursor.bmp" ) )
	{
		return Fail( hwnd, "Couldn't load offscreen Cursor.\n" );
	}


   if ( !LoadMyImage( lpDDSOffSmaleStars, "grafix/SmaleStars.bmp" ) )
	{
		return Fail( hwnd, "Couldn't load offscreen SmaleStars.\n" );
	}

   if ( !LoadMyImage( lpDDSOffJump1, "grafix/jump1.bmp" ) )
	{
		return Fail( hwnd, "Couldn't load offscreen SmaleStars.\n" );
	}

   if ( !LoadMyImage( lpDDSOffJump2, "grafix/jump2.bmp" ) )
	{
		return Fail( hwnd, "Couldn't load offscreen SmaleStars.\n" );
	}

   if ( !LoadMyImage( lpDDSOffJump3, "grafix/jump3.bmp" ) )
	{
		return Fail( hwnd, "Couldn't load offscreen SmaleStars.\n" );
	}



   if ( !LoadMyImage( lpDDSOffLetters, "grafix/letters.bmp" ) )
	{
		return Fail( hwnd, "Couldn't load offscreen letters.\n" );
	}

	if ( !LoadMyImage( lpDDSOffMap_color, "grafix/map_color.bmp" ) )
	{
		return Fail( hwnd, "Couldn't load offscreen map_color\n" );
	}

   //if ( !LoadMyImage( lpDDSOffWorlds, "grafix/worlds.bmp" ) )
	//{
	//	return Fail( hwnd, "Couldn't load offscreen worlds.\n" );
	//}

		 if ( !LoadMyImage( lpDDSOffGlobes, "grafix/globes.bmp" ) )
	{
		return Fail( hwnd, "Couldn't load offscreen globes.\n" );
	}

		  if ( !LoadMyImage( lpDDSOffWorlds1, "grafix/world1.bmp" ) )
	{
		return Fail( hwnd, "Couldn't load offscreen worlds 1.\n" );
	}

	if ( !LoadMyImage( lpDDSOffWorlds2, "grafix/world2.bmp" ) )
	{
		return Fail( hwnd, "Couldn't load offscreen worlds 2.\n" );
	}

	if ( !LoadMyImage( lpDDSOffWorlds3, "grafix/world3.bmp" ) )
	{
		return Fail( hwnd, "Couldn't load offscreen worlds 3.\n" );
	}

	if ( !LoadMyImage( lpDDSOffWorlds4, "grafix/world4.bmp" ) )
	{
		return Fail( hwnd, "Couldn't load offscreen worlds 4.\n" );
	}

	if ( !LoadMyImage( lpDDSOffWorlds5, "grafix/world5.bmp" ) )
	{
		return Fail( hwnd, "Couldn't load offscreen worlds 5.\n" );
	}

	if ( !LoadMyImage( lpDDSOffWorlds6, "grafix/world6.bmp" ) )
	{
		return Fail( hwnd, "Couldn't load offscreen worlds 6.\n" );
	}

			  if ( !LoadMyImage( lpDDSOffWorlds7, "grafix/world7.bmp" ) )
	{
		return Fail( hwnd, "Couldn't load offscreen worlds 7.\n" );
	}

	if ( !LoadMyImage( lpDDSOffWorlds8, "grafix/world8.bmp" ) )
	{
		return Fail( hwnd, "Couldn't load offscreen worlds 8.\n" );
	}

	if ( !LoadMyImage( lpDDSOffWorlds9, "grafix/world9.bmp" ) )
	{
		return Fail( hwnd, "Couldn't load offscreen worlds 9.\n" );
	}
	////
	if ( !LoadMyImage( lpDDSOffflagpole, "grafix/flag_pole.bmp" ) )
	{
		return Fail( hwnd, "Couldn't load offscreen flag_pole .\n" );
	}
	if ( !LoadMyImage( lpDDSOffflags1, "grafix/flags.bmp" ) )
	{
		return Fail( hwnd, "Couldn't load offscreen flags .\n" );
	}
	if ( !LoadMyImage( lpDDSOffflags2, "grafix/flags_small.bmp" ) )
	{
		return Fail( hwnd, "Couldn't load offscreen flags_small .\n" );
	}
    ////////////////////////////////////////////////////////////////////////
	debugfile ("loaded base surfases.\n",1 );

	Creat_Nebula (); // nebula set up
	Creat_GasGiant ();  // gg set up
	debugfile ("nebula set up done.\n",1 );
	Creat_Worlds (); //terrain set up
	debugfile ("terrain set up done.\n",1 );

    // Start the frame timer.
	dwFrameTime = timeGetTime();
	debugfile ("timer started.\n",1 );

	 rcRectAstar.top=0; rcRectAstar.bottom=4; rcRectAstar.left=0; rcRectAstar.right=4;
    rcRectBstar.top=5; rcRectBstar.bottom=9; rcRectBstar.left=0; rcRectBstar.right=4;
    rcRectCstar.top=9; rcRectCstar.bottom=14; rcRectCstar.left=0; rcRectCstar.right=5;
    rcRectDstar.top=14; rcRectDstar. bottom=22; rcRectDstar.left=0; rcRectDstar.right=7;
    rcRectHstar.top=43; rcRectHstar. bottom=50; rcRectHstar.left=0; rcRectHstar.right=8;

    rcRectZoom.top=0; rcRectZoom. bottom=27; rcRectZoom.left=22; rcRectZoom.right=49;

    rcRectSuns.top=0; rcRectSuns. bottom=299; rcRectSuns.left=0; rcRectSuns.right=239;
    rcRectRedSun.top=0; rcRectRedSun. bottom=60; rcRectRedSun.left=0; rcRectRedSun.right=60;
    rcRectOrangeSun.top=60; rcRectOrangeSun. bottom=120; rcRectOrangeSun.left=0; rcRectOrangeSun.right=60;
    rcRectYellowSun.top=120; rcRectYellowSun. bottom=180; rcRectYellowSun.left=0; rcRectYellowSun.right=60;
    rcRectBlueSun.top=180; rcRectBlueSun. bottom=240; rcRectBlueSun.left=0; rcRectBlueSun.right=60;
    rcRectWhiteSun.top=240; rcRectWhiteSun. bottom=299; rcRectWhiteSun.left=0; rcRectWhiteSun.right=60;

    rcRectWorld1.top=0; rcRectWorld1.bottom=28; rcRectWorld1.left=0; rcRectWorld1.right=28;

    rcRectSection2.top=313; rcRectSection2. bottom=589; rcRectSection2.left=513; rcRectSection2.right=789;
    rcRectSection1.top=110; rcRectSection1. bottom=589; rcRectSection1.left=6; rcRectSection1.right=485;

	rcRectShip.top=43; rcRectShip. bottom=49; rcRectShip.left=43; rcRectShip.right=49;

	Check_popu[0].popu = (LPhex)NULL;
	Check_popu[1].popu = (LPhex)NULL;
	Check_popu[2].popu = (LPhex)NULL;
	Check_popu[3].popu = (LPhex)NULL;
	Check_popu[4].popu = (LPhex)NULL;
	Check_popu[5].popu = (LPhex)NULL;

	return TRUE;

}



int PASCAL WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	MSG         msg;
	//DWORD       dwCopy_time; //make global for unit movement

	lpCmdLine = lpCmdLine;
	hPrevInstance = hPrevInstance;

	FILE *streamClear;
	streamClear = fopen("debug/debug.txt", "w");  // clear debuger
	fclose(streamClear);
	debugfile ("start......\n", 1 );

    LPMEMORYSTATUS memory;
	memory = (LPMEMORYSTATUS) malloc( sizeof(MEMORYSTATUS) );
	if ( memory == NULL )
	{ Fail( hwnd, "NO MEM: mem..\n" ); }
	GlobalMemoryStatus( memory );
	debugfile ("K Mem Total\n", memory->dwTotalPhys/1000 );
	debugfile ("% Mem in use befor grafix\n", memory->dwMemoryLoad );

	get_vars ();                   // open input file
    srand( timeGetTime() );        // set seed
    debugfile (" start game loop ", 1 );///////////

	if ( !doInit( hInstance, nCmdShow ) )
	{
		debugfile ("Couldn't doinit win\n", 1 );
		return FALSE;
	}
    galaxy ();                     // goto creat galaxy; later part of programe
	GlobalMemoryStatus( memory );
    debugfile ("% Mem in use after grafix\n", memory->dwMemoryLoad );
	debugfile ("K Mem left\n", memory->dwAvailPhys/1000 );

	while ( 1 )                              // program loop  (infinite)
	{
		if ( PeekMessage( &msg, NULL, 0, 0, PM_NOREMOVE ) )
		{
			if ( !GetMessage( &msg, NULL, 0, 0 ) )
			{
				return msg.wParam;
			}
			TranslateMessage( &msg );
			DispatchMessage( &msg );
		}
		else if ( bActive )
		{
			 ////////////////////////////////////////////
			/*
			 if (dwTime_animation> Animation_ratE)
			{
			animation++;            // timer for animation
			if (animation>3)
				{ animation=1; }
			animation2++;            // timer for animation
			if (animation2>12)
				{ animation2=1; }
			 }
			 */

			 ///////////////////////////////////////////
			 ////place one call to timeGetTime here
			dwCopy_time = timeGetTime();

			if (dwTime_animation > 100)
			{
				animation1++;            // timer for animation
				if (animation1>10)
					{ animation1=1; }
				animation2++;            // timer for animation
				if (animation2>6)
					{ animation2=1; }
				dwFrameTime2=dwCopy_time;
			 }

			 dwTime_animation = dwCopy_time - dwFrameTime2;

				if (dwTime>1000)
			{
			   dwFrameTime=dwCopy_time;
			   OneSecond++;
			   TotalSec++;    // used for waiting list
			}

			dwTime = dwCopy_time- dwFrameTime;


				  if (OneSecond>59)
					{
					OneSecond=0;
					OneMinute++;
					 if (OneMinute>59)
						{
						OneMinute=0;
						OneHoure++;
					}
				}



				UpdateFrame();          // goto update frame



		}
		else
		{
			WaitMessage();          // get input etc.
		}
	}


}


