//int find_pinky=0;
 int find_red=31;
 int find_green=252;
 int find_bleu=0;

 int turn_off_road_value=false;


const unsigned int GREATER_RACES=999;    //see also structures
const unsigned char TINY_STAR=   7;
const unsigned char SMALLE_STAR=10;
const unsigned char MEDIUM_STAR=14;
const unsigned char LARGE_STAR= 18;

///path finder types
const unsigned char ROAD=111;

const unsigned char EAST=1;
const unsigned char WEST=2;
const unsigned char NORTH_EAST=3;
const unsigned char NORTH_WEST=4;
const unsigned char SOUTH_EAST=5;
const unsigned char SOUTH_WEST=6;
const unsigned char CENTER=7;

const unsigned char FLAG_EAST=128;
const unsigned char FLAG_WEST= 64;
const unsigned char FLAG_NORTH_EAST=32;
const unsigned char FLAG_NORTH_WEST=16;
const unsigned char FLAG_SOUTH_EAST=8;
const unsigned char FLAG_SOUTH_WEST=4;
const unsigned char FLAG_BLANK=2;
const unsigned char FLAG_ON=1;

const unsigned char MAP=1;
const unsigned char SYSTEM=2;
const unsigned char WORLD=3;

const unsigned char EMPTY=0;
const unsigned char HYDRO=7;
const unsigned char PLAIN=0;
const unsigned char PLANT_PLAIN=3;
const unsigned char PLANT_HILL=4;
const unsigned char PLANT_SWAMP=5;
const unsigned char HILL =1;
const unsigned char MOUNT=2;
const unsigned char MARCH=115;
const unsigned char SHALOW=6;
const unsigned char DEEP=8;
const unsigned char RIVER_MARKER=9;
const unsigned char RIVER_MARKER_E=10;
const unsigned char RIVER_MARKER_W=11;
const unsigned char RIVER_MARKER_NE=12;
const unsigned char RIVER_MARKER_NW=13;
const unsigned char RIVER_MARKER_SE=14;
const unsigned char RIVER_MARKER_SW=15;
const unsigned char RIVER=200;

const unsigned char NUM_TERRAINS=7;  //(empty,hydro,plain,plant,hill,mount,march)
const unsigned char NUM_SECTIONS=12; //(map 3x4)   // Latter add poles CZAR
const unsigned char UNEXPLORED=1;
const unsigned char VIEWED=2;
const unsigned char COLONISSED=3;
const unsigned char NOTHING=0;
const unsigned char NOT_USED=0;
const unsigned char NONE=0;
const int YES_IF_BORDER=1;
const int YES_IF_NO_BORDER=0;
const unsigned char GROW_BY_INCREES=1;
const unsigned char GROW_BY_NEIBOUR=2;
const unsigned char GROW_BY_CHAIN=3;
const unsigned char GROW_BY_SEPERATE=4;
const unsigned char EDGE_OF_WORLD=255;

const unsigned char BROWN=101;
const unsigned char WATER=102;
const unsigned char DARK=103;
const unsigned char LAVA=104;
const unsigned char WHITE=105;
const unsigned char ICE=106;
const unsigned char JUNGLE=107;
const unsigned char GREY=108;
const unsigned char EXOTIC=109;
const unsigned char ACID=110;
const unsigned char TEMP=111;
const unsigned char ISLE=112;
const unsigned char DESERT=113;
const unsigned char MOON=114;
const unsigned char SWAMP=115;
const unsigned char DUNE=116;
const unsigned char OASIS=117;
const unsigned char ROCKY=118;

const unsigned char OIL=1;
const unsigned char STEEL=222;  ////////
const unsigned char METAL=2;
const unsigned char SPICE=3;
const unsigned char GEM=4;
const unsigned char TRACE=5;
const unsigned char CHEMICAL=6;
const unsigned char RADIOACTIVE=7;
const unsigned char HYPER_STEEL=8;
const unsigned char GOLD=9;


const unsigned char TOWN=1;
const unsigned char FACTORY=2;
const unsigned char CHURCH=3;
const unsigned char PALACE=4;
const unsigned char CHEMY=6;
//const unsigned char STEEL=5;
const unsigned char ELEC=7;
const unsigned char FARM=8;
const unsigned char FARM_LAND=9;
const unsigned char MINE=10;
const unsigned char WELL=11;
const unsigned char OFFSHORE_WELL=12;
const unsigned char RUINS=13;
const unsigned char STARPORT=14;
const unsigned char FORT=15;
const unsigned char BARRACKS=16;
const unsigned char UNI=17;
const unsigned char LAB=18;
const unsigned char ENCLOSED_FARM=19;
const unsigned char ANY_STRUCTURE=20;
const unsigned char MINE_TRACE=21;
const unsigned char MINE_GEMS=22;
const unsigned char MINE_HYPER_STEEL=23;
const unsigned char MINE_RADIOACTIVE=24;
const unsigned char MINE_CHEMY=25;
const unsigned char MINE_GOLD=26;


const unsigned char NUTRAL=105;  //
const unsigned char HIGH_STEWARD=2; //PURPLE
//const unsigned char CHURCH=3;  //
const unsigned char BLEU=103;    //
const unsigned char RED=102;    //  MILITARY
const unsigned char ORANGE=104;  // TRADERS
const unsigned char GREEN=7;   //
//const unsigned char WHITE=8;  //
const unsigned char ALIEN=9;   //
const unsigned char GUARD=10;  //
const unsigned char WEB=11;    //
const unsigned char NAVY=12;   //
const unsigned char GUILD=13;  // BROWN
const unsigned char YELLOW=101;  // BROWN

const unsigned char VERY_RARE=1;
const unsigned char RARE=10;
const unsigned char UNCOMMAN=20;
const unsigned char COMMAN=40;
const unsigned char VERY_COMMAN=80;

const unsigned char FACTORY_WORKER=101;
const unsigned char UNEMPLOYED=102;
const unsigned char OILWELL_WORKER=103;
const unsigned char MINER=104;
const unsigned char INFANTRY=105;
const unsigned char VEHICLE=106;
const unsigned char FARMER=107;
const unsigned char PALACE_STAFF=108;
const unsigned char STAR_PORT_DOCKER=109;
const unsigned char LAB_ASSISTANT=110;
const unsigned char MINER_HYPER_STEEL=111;
const unsigned char MINER_GEMS=112;
const unsigned char MINER_TRACE=113;
const unsigned char MINER_RADIOACTIVE=114;
const unsigned char OILPLATFORM_WORKER=115;
const unsigned char UNI_ASSISTANT=116;
const unsigned char FACTORY_WORKER_STEEL=117;
const unsigned char FACTORY_WORKER_ELEC=118;
const unsigned char FACTORY_WORKER_CHEMY=119;
const unsigned char FARM_LAND_ICON=120 ;
const unsigned char FLAG_ICON_CURSOR=121 ;
const unsigned char MINER_CHEMY=122; ///unused
const unsigned char MINER_GOLD=123;  ///unused

const unsigned char TRANSPORT=121;

const unsigned char SMALL=0;
const unsigned char LARGE=1;

 ///note: hex is  y high version 120x120
const unsigned char HEX_CENTER_X=60;
const unsigned char HEX_CENTER_Y=90;

////
const unsigned char HEX_BORDER_NE_X=88;
const unsigned char HEX_BORDER_NE_Y=64;
const unsigned char HEX_BORDER_E_X=112;
const unsigned char HEX_BORDER_E_Y=90;
const unsigned char HEX_BORDER_SE_X=87;
const unsigned char HEX_BORDER_SE_Y=109;
const unsigned char HEX_BORDER_SW_X=43;
const unsigned char HEX_BORDER_SW_Y=109;
const unsigned char HEX_BORDER_W_X=8;
const unsigned char HEX_BORDER_W_Y=90;
const unsigned char HEX_BORDER_NW_X=27;
const unsigned char HEX_BORDER_NW_Y=64;

/////tasks///doing////status
const unsigned char WAITING=1;
const unsigned char MOVING=2;
const unsigned char ATTACKING=3;
const unsigned char MOVING_TO_ATTACK=4;
const unsigned char DEFENDING=5;
const unsigned char INTERCEPTED=6;


////
//units
const unsigned char NOBLE=200;
const unsigned char INFANTRY_1=1;
const unsigned char INFANTRY_2=2;
const unsigned char INFANTRY_3=3;
const unsigned char INFANTRY_4=4;
const unsigned char INFANTRY_5=5;

/*
const unsigned char HEX_BORDER_NE_X=83;
const unsigned char HEX_BORDER_NE_Y=68;
const unsigned char HEX_BORDER_E_X=112;
const unsigned char HEX_BORDER_E_Y=90;
const unsigned char HEX_BORDER_SE_X=90;
const unsigned char HEX_BORDER_SE_Y=112;
const unsigned char HEX_BORDER_SW_X=36;
const unsigned char HEX_BORDER_SW_Y=112;
const unsigned char HEX_BORDER_W_X=8;
const unsigned char HEX_BORDER_W_Y=90;
const unsigned char HEX_BORDER_NW_X=30;
const unsigned char HEX_BORDER_NW_Y=68;
*/
////
int Cursor_Type = 0;

int town_view_number;
int hex_view_x;
int hex_view_y;

int town_view_on_off=false;
int work_view_on_off=false;


//int nebula[5][5];
int area[7+1][12+1];  // num terrains+1  num sections+1
int slot [12+1][10][10]={0};    // sections x 10x10
int cursorOff=false;

int ScreenType=MAP;
int ViewerType=MAP;
int seePlanet=false;
int FixedMouseX;int FixedMouseY ;
long sec;                             // part of timer
int animation1=1;                      // animation frame 1-10
int animation2=1;                      // animation frame  1-6

DWORD   dwTime_animation;   // time in milisecs in groups of 200

DWORD   dwCopy_time;

DWORD	dwCursor_Zoom_Time_Start;

unsigned int OneHoure=0; int OneMinute=0; int OneSecond=0; int TenthOfSecond=0;
unsigned int TotalSec=0;
int xPos; int yPos;                    // current x,y positions
float zDelta=1.0 ;                       //mouse wheel
//int old_zDelta=120;
double LMousexPos; double LMouseyPos; // mouse position (x,y)
int RMousexPos;
int RMouseyPos;
int RMousexDif=0;
int RMouseyDif=0;
int RMouseDown=0;
int Old_LMousexPos=0;
int Old_LMouseyPos=0;
int Mouse_Start_Move=true;

int find_screen_unit_x;
int find_screen_unit_y;

int LMouse_triger=true;
int RMouse_triger=true;

int start_at_x;
int start_at_y;

int LMouse_Hex_Click_X;
int LMouse_Hex_Click_Y;
int LMouse_Hex_Click=false;
int LMouseBeenUsed=false;

int RMouse_Hex_Click_X;
int RMouse_Hex_Click_Y;
int RMouse_Hex_Click=false;
int RMouseBeenUsed=false;

int regenerate=false;
int Zoomx=513; int Zoomy=313;         // zoom star coordinates
int LMouseDown=0;
int Zoomtype=2;   // zoomtype 1 is debug view all stars
int planet_draw;

int JUST_ONCE=true;
int ORBITAL_VIEW=false;
int DRAWN_PLANET_MAP=false;

int planet_see_x;
int planet_see_y;

int space_key_down=false;

int startgame=true;
int screenMap[70][70];                 // used to see if cursor over world
int firstx; int lastx;                 // used to speed up placing worlds
unsigned char Name[10];
int botton1=false, botton2=false, botton3=false, botton4=false, botton5=false, botton6=false;
int botton7=false, botton8=false, botton9=false, botton10=false,botton11=false,botton12=false;
short int first_task;
short int last_task;

int planet_size_x=48;
int planet_size_y=48;


BYTE                *dest;
HDC                 hdc;
HWND                hwnd;
DDSURFACEDESC       ddsd;
DDSCAPS             ddscaps;    // Surface capabilities structure.


//WNDCLASS            wc;

int 			arms=4;              // galaxy changable variables
float 		    spread=80;
float			shapeN=3.0;
float			shapeL=2.0;

char c_szClassName[] = "DIEX3";

HINSTANCE       g_hinst;                /* My instance handle */
BOOL            g_fPaused = TRUE;       /* Should I be paused? */

LPDIRECTDRAW            lpDD;               // DirectDraw object
LPDIRECTDRAWSURFACE     lpDDSPrimary;       // DirectDraw primary surface
LPDIRECTDRAWSURFACE     lpDDSOffScreen;     // DirectDraw OffScreen surface
LPDIRECTDRAWSURFACE 	lpDDSOffAdInfinitum; //title sreen
LPDIRECTDRAWSURFACE     lpDDSBack;      	// DirectDraw back buffer surface
LPDIRECTDRAWSURFACE     lpDDSOffOne;        // DirectDraw offscreen surface Main Nenu
LPDIRECTDRAWSURFACE     lpDDSOffButtons;    // DirectDraw offscreen surface Buttons
LPDIRECTDRAWSURFACE     lpDDSOffThree;      // DirectDraw offscreen surface (not used)
LPDIRECTDRAWSURFACE     lpDDSOffSmaleStars; // smale maps stars
LPDIRECTDRAWSURFACE     lpDDSOffCursor;     // Fake curser
LPDIRECTDRAWSURFACE     lpDDSOffJump1;
LPDIRECTDRAWSURFACE     lpDDSOffJump2;
LPDIRECTDRAWSURFACE     lpDDSOffJump3;
LPDIRECTDRAWSURFACE     lpDDSOffSuns;
LPDIRECTDRAWSURFACE     lpDDSOffMap;
LPDIRECTDRAWSURFACE     lpDDSOffLetters;
LPDIRECTDRAWSURFACE		lpDDSOffMap_color;
LPDIRECTDRAWSURFACE     lpDDSOffWorlds;
LPDIRECTDRAWSURFACE     lpDDSOffGlobes;

LPDIRECTDRAWSURFACE     lpDDSOffIcons1;

LPDIRECTDRAWSURFACE     lpDDSOffflagpole;
LPDIRECTDRAWSURFACE     lpDDSOffflags1;
LPDIRECTDRAWSURFACE     lpDDSOffflags2;

LPDIRECTDRAWSURFACE     lpDDSOffFactions1;

LPDIRECTDRAWSURFACE     lpDDSOffBar1;

LPDIRECTDRAWSURFACE     lpDDSOffPlain;

//LPDIRECTDRAWSURFACE     lpDDSOffPlain_Desert;
LPDIRECTDRAWSURFACE     lpDDSOffPlain_Desert1;
LPDIRECTDRAWSURFACE     lpDDSOffPlain_Desert2;
LPDIRECTDRAWSURFACE     lpDDSOffPlain_Desert3;
LPDIRECTDRAWSURFACE     lpDDSOffPlain_Desert4;
LPDIRECTDRAWSURFACE     lpDDSOffPlain_Desert5;

LPDIRECTDRAWSURFACE     lpDDSOffPlain_Dry1;
LPDIRECTDRAWSURFACE     lpDDSOffPlain_Dry2;
LPDIRECTDRAWSURFACE     lpDDSOffPlain_Dry3;
LPDIRECTDRAWSURFACE     lpDDSOffPlain_Dry4;
LPDIRECTDRAWSURFACE     lpDDSOffPlain_Dry5;

LPDIRECTDRAWSURFACE     lpDDSOffDunes_Desert1;
LPDIRECTDRAWSURFACE     lpDDSOffDunes_Desert2;
LPDIRECTDRAWSURFACE     lpDDSOffDunes_Desert3;
LPDIRECTDRAWSURFACE     lpDDSOffDunes_Desert4;
LPDIRECTDRAWSURFACE     lpDDSOffDunes_Desert5;

LPDIRECTDRAWSURFACE     lpDDSOffRocky_Plain_Desert1;
LPDIRECTDRAWSURFACE     lpDDSOffRocky_Plain_Desert2;
LPDIRECTDRAWSURFACE     lpDDSOffRocky_Plain_Desert3;
LPDIRECTDRAWSURFACE     lpDDSOffRocky_Plain_Desert4;
LPDIRECTDRAWSURFACE     lpDDSOffRocky_Plain_Desert5;

LPDIRECTDRAWSURFACE     lpDDSOffPlain_Ice;
LPDIRECTDRAWSURFACE     lpDDSOffPlain_Lava;
LPDIRECTDRAWSURFACE     lpDDSOffPlain_Moon;
LPDIRECTDRAWSURFACE     lpDDSOffPlain_Exotic;

LPDIRECTDRAWSURFACE     lpDDSOffSwamp;

LPDIRECTDRAWSURFACE     lpDDSOffSea;
LPDIRECTDRAWSURFACE     lpDDSOffShalow_Sea;
LPDIRECTDRAWSURFACE     lpDDSOffDeep_Sea;

///////////new sea//////////
LPDIRECTDRAWSURFACE     lpDDSOffSea1;
LPDIRECTDRAWSURFACE     lpDDSOffSea2;
LPDIRECTDRAWSURFACE     lpDDSOffSea3;
LPDIRECTDRAWSURFACE     lpDDSOffSea4;
LPDIRECTDRAWSURFACE     lpDDSOffSea5;
LPDIRECTDRAWSURFACE     lpDDSOffSea6;
LPDIRECTDRAWSURFACE     lpDDSOffSea7;
LPDIRECTDRAWSURFACE     lpDDSOffSea8;
LPDIRECTDRAWSURFACE     lpDDSOffSea9;
LPDIRECTDRAWSURFACE     lpDDSOffSea10;
//
LPDIRECTDRAWSURFACE     lpDDSOffSea_deep1;
LPDIRECTDRAWSURFACE     lpDDSOffSea_deep2;
LPDIRECTDRAWSURFACE     lpDDSOffSea_deep3;
LPDIRECTDRAWSURFACE     lpDDSOffSea_deep4;
LPDIRECTDRAWSURFACE     lpDDSOffSea_deep5;
LPDIRECTDRAWSURFACE     lpDDSOffSea_deep6;
LPDIRECTDRAWSURFACE     lpDDSOffSea_deep7;
LPDIRECTDRAWSURFACE     lpDDSOffSea_deep8;
LPDIRECTDRAWSURFACE     lpDDSOffSea_deep9;
LPDIRECTDRAWSURFACE     lpDDSOffSea_deep10;
//
//LPDIRECTDRAWSURFACE     lpDDSOffSea_desert;
LPDIRECTDRAWSURFACE     lpDDSOffSea_desert1;
LPDIRECTDRAWSURFACE     lpDDSOffSea_desert2;
LPDIRECTDRAWSURFACE     lpDDSOffSea_desert3;
LPDIRECTDRAWSURFACE     lpDDSOffSea_desert4;
LPDIRECTDRAWSURFACE     lpDDSOffSea_desert5;

LPDIRECTDRAWSURFACE     lpDDSOffSea_ice_1;
LPDIRECTDRAWSURFACE     lpDDSOffSea_ice_2;

LPDIRECTDRAWSURFACE     lpDDSOffSea_lava;
LPDIRECTDRAWSURFACE     lpDDSOffShalow_Sea_lava;
LPDIRECTDRAWSURFACE     lpDDSOffDeep_Sea_lava;

LPDIRECTDRAWSURFACE     lpDDSOffSea_exotic;
LPDIRECTDRAWSURFACE     lpDDSOffShalow_Sea_exotic;
LPDIRECTDRAWSURFACE     lpDDSOffDeep_Sea_exotic;

LPDIRECTDRAWSURFACE     lpDDSOffTrees;
LPDIRECTDRAWSURFACE     lpDDSOffHill_Trees;
LPDIRECTDRAWSURFACE     lpDDSOffSwamp_Trees;

LPDIRECTDRAWSURFACE     lpDDSOffTrees_a_1;
LPDIRECTDRAWSURFACE     lpDDSOffTrees_a_2;
LPDIRECTDRAWSURFACE     lpDDSOffTrees_a_3;
LPDIRECTDRAWSURFACE     lpDDSOffTrees_a_4;
LPDIRECTDRAWSURFACE     lpDDSOffTrees_a_5;

LPDIRECTDRAWSURFACE     lpDDSOffDesert_Trees1;
LPDIRECTDRAWSURFACE     lpDDSOffDesert_Trees2;
LPDIRECTDRAWSURFACE     lpDDSOffDesert_Trees3;
LPDIRECTDRAWSURFACE     lpDDSOffDesert_Trees4;
LPDIRECTDRAWSURFACE     lpDDSOffDesert_Trees5;

LPDIRECTDRAWSURFACE     lpDDSOffHill1;
LPDIRECTDRAWSURFACE     lpDDSOffHill2;
LPDIRECTDRAWSURFACE     lpDDSOffHill3;
LPDIRECTDRAWSURFACE     lpDDSOffHill4;
LPDIRECTDRAWSURFACE     lpDDSOffHill5;

LPDIRECTDRAWSURFACE     lpDDSOffHill_Ice1;
LPDIRECTDRAWSURFACE     lpDDSOffHill_Ice2;
LPDIRECTDRAWSURFACE     lpDDSOffHill_Ice3;
LPDIRECTDRAWSURFACE     lpDDSOffHill_Ice4;
LPDIRECTDRAWSURFACE     lpDDSOffHill_Ice5;

//LPDIRECTDRAWSURFACE     lpDDSOffHill_Desert;/////////
LPDIRECTDRAWSURFACE     lpDDSOffHill_Desert1;
LPDIRECTDRAWSURFACE     lpDDSOffHill_Desert2;
LPDIRECTDRAWSURFACE     lpDDSOffHill_Desert3;
LPDIRECTDRAWSURFACE     lpDDSOffHill_Desert4;
LPDIRECTDRAWSURFACE     lpDDSOffHill_Desert5;

LPDIRECTDRAWSURFACE     lpDDSOffRocky_Hill_Desert1;
LPDIRECTDRAWSURFACE     lpDDSOffRocky_Hill_Desert2;
LPDIRECTDRAWSURFACE     lpDDSOffRocky_Hill_Desert3;
LPDIRECTDRAWSURFACE     lpDDSOffRocky_Hill_Desert4;
LPDIRECTDRAWSURFACE     lpDDSOffRocky_Hill_Desert5;

LPDIRECTDRAWSURFACE     lpDDSOffHill_Lava;
LPDIRECTDRAWSURFACE     lpDDSOffHill_Moon;
LPDIRECTDRAWSURFACE     lpDDSOffHill_Exotic;

LPDIRECTDRAWSURFACE		lpDDSOffMount1;
LPDIRECTDRAWSURFACE		lpDDSOffMount2;
LPDIRECTDRAWSURFACE		lpDDSOffMount3;
LPDIRECTDRAWSURFACE		lpDDSOffMount4;
LPDIRECTDRAWSURFACE		lpDDSOffMount5;

//LPDIRECTDRAWSURFACE		lpDDSOffMount_Desert;////
LPDIRECTDRAWSURFACE		lpDDSOffMount_Desert1;
LPDIRECTDRAWSURFACE		lpDDSOffMount_Desert2;
LPDIRECTDRAWSURFACE		lpDDSOffMount_Desert3;
LPDIRECTDRAWSURFACE		lpDDSOffMount_Desert4;
LPDIRECTDRAWSURFACE		lpDDSOffMount_Desert5;

LPDIRECTDRAWSURFACE		lpDDSOffMount_Ice;
LPDIRECTDRAWSURFACE		lpDDSOffMount_Lava;
LPDIRECTDRAWSURFACE		lpDDSOffMount_Moon;
LPDIRECTDRAWSURFACE		lpDDSOffMount_Exotic;

LPDIRECTDRAWSURFACE		lpDDSOffRiver_E;
LPDIRECTDRAWSURFACE		lpDDSOffRiver_W;
LPDIRECTDRAWSURFACE		lpDDSOffRiver_NE;
LPDIRECTDRAWSURFACE		lpDDSOffRiver_NW;
LPDIRECTDRAWSURFACE		lpDDSOffRiver_SE;
LPDIRECTDRAWSURFACE		lpDDSOffRiver_SW;

LPDIRECTDRAWSURFACE		lpDDSOffRoad_E;
LPDIRECTDRAWSURFACE		lpDDSOffRoad_W;
LPDIRECTDRAWSURFACE		lpDDSOffRoad_W_NE;
LPDIRECTDRAWSURFACE		lpDDSOffRoad_NE;
LPDIRECTDRAWSURFACE		lpDDSOffRoad_NW;
LPDIRECTDRAWSURFACE		lpDDSOffRoad_NW_SW;
LPDIRECTDRAWSURFACE		lpDDSOffRoad_SE;
LPDIRECTDRAWSURFACE		lpDDSOffRoad_SW;

LPDIRECTDRAWSURFACE		lpDDSOffRiver_E_swamp;
LPDIRECTDRAWSURFACE		lpDDSOffRiver_W_swamp;
LPDIRECTDRAWSURFACE		lpDDSOffRiver_NE_swamp;
LPDIRECTDRAWSURFACE		lpDDSOffRiver_NW_swamp;
LPDIRECTDRAWSURFACE		lpDDSOffRiver_SE_swamp;
LPDIRECTDRAWSURFACE		lpDDSOffRiver_SW_swamp;

LPDIRECTDRAWSURFACE		lpDDSOffRiver_E_desert;
LPDIRECTDRAWSURFACE		lpDDSOffRiver_W_desert;
LPDIRECTDRAWSURFACE		lpDDSOffRiver_NE_desert;
LPDIRECTDRAWSURFACE		lpDDSOffRiver_NW_desert;
LPDIRECTDRAWSURFACE		lpDDSOffRiver_SE_desert;
LPDIRECTDRAWSURFACE		lpDDSOffRiver_SW_desert;

LPDIRECTDRAWSURFACE		lpDDSOffRiver_E_lava;
LPDIRECTDRAWSURFACE		lpDDSOffRiver_W_lava;
LPDIRECTDRAWSURFACE		lpDDSOffRiver_NE_lava;
LPDIRECTDRAWSURFACE		lpDDSOffRiver_NW_lava;
LPDIRECTDRAWSURFACE		lpDDSOffRiver_SE_lava;
LPDIRECTDRAWSURFACE		lpDDSOffRiver_SW_lava;

LPDIRECTDRAWSURFACE		lpDDSOffRiver_E_exotic;
LPDIRECTDRAWSURFACE		lpDDSOffRiver_W_exotic;
LPDIRECTDRAWSURFACE		lpDDSOffRiver_NE_exotic;
LPDIRECTDRAWSURFACE		lpDDSOffRiver_NW_exotic;
LPDIRECTDRAWSURFACE		lpDDSOffRiver_SE_exotic;
LPDIRECTDRAWSURFACE		lpDDSOffRiver_SW_exotic;

LPDIRECTDRAWSURFACE		lpDDSOffRes_radioactive;
LPDIRECTDRAWSURFACE		lpDDSOffRes_metal;
LPDIRECTDRAWSURFACE		lpDDSOffRes_oil;
LPDIRECTDRAWSURFACE		lpDDSOffRes_spice;
LPDIRECTDRAWSURFACE		lpDDSOffRes_gem;
LPDIRECTDRAWSURFACE		lpDDSOffRes_trace;
LPDIRECTDRAWSURFACE		lpDDSOffRes_chemy;
LPDIRECTDRAWSURFACE		lpDDSOffRes_hyper_steel;
LPDIRECTDRAWSURFACE		lpDDSOffRes_gold;

LPDIRECTDRAWSURFACE		lpDDSOffStruct_town1;
LPDIRECTDRAWSURFACE		lpDDSOffStruct_town2;
LPDIRECTDRAWSURFACE		lpDDSOffStruct_town3;
LPDIRECTDRAWSURFACE		lpDDSOffStruct_town4;
LPDIRECTDRAWSURFACE		lpDDSOffStruct_town5;

LPDIRECTDRAWSURFACE		lpDDSOffStruct_town_ice;

//LPDIRECTDRAWSURFACE		lpDDSOffStruct_town_desert;
LPDIRECTDRAWSURFACE		lpDDSOffStruct_town_desert1;
LPDIRECTDRAWSURFACE		lpDDSOffStruct_town_desert2;
LPDIRECTDRAWSURFACE		lpDDSOffStruct_town_desert3;
LPDIRECTDRAWSURFACE		lpDDSOffStruct_town_desert4;
LPDIRECTDRAWSURFACE		lpDDSOffStruct_town_desert5;

LPDIRECTDRAWSURFACE		lpDDSOffStruct_chemy;
LPDIRECTDRAWSURFACE		lpDDSOffStruct_steel;
LPDIRECTDRAWSURFACE		lpDDSOffStruct_elec;
LPDIRECTDRAWSURFACE		lpDDSOffStruct_church;
LPDIRECTDRAWSURFACE		lpDDSOffStruct_palace;
LPDIRECTDRAWSURFACE		lpDDSOffStruct_ruins;
LPDIRECTDRAWSURFACE		lpDDSOffStruct_well;
LPDIRECTDRAWSURFACE		lpDDSOffStruct_offshore_well;
LPDIRECTDRAWSURFACE		lpDDSOffStruct_mine;
LPDIRECTDRAWSURFACE		lpDDSOffStruct_farm;
LPDIRECTDRAWSURFACE		lpDDSOffStruct_farm_land;
LPDIRECTDRAWSURFACE		lpDDSOffStruct_factory;
LPDIRECTDRAWSURFACE		lpDDSOffStruct_starport;
LPDIRECTDRAWSURFACE		lpDDSOffStruct_fort;
LPDIRECTDRAWSURFACE		lpDDSOffStruct_barracks;
LPDIRECTDRAWSURFACE		lpDDSOffStruct_lab;
LPDIRECTDRAWSURFACE		lpDDSOffStruct_uni;
LPDIRECTDRAWSURFACE		lpDDSOffStruct_farm_enc;

LPDIRECTDRAWSURFACE		lpDDSOffCoast_a_1;
LPDIRECTDRAWSURFACE		lpDDSOffCoast_b_1;
LPDIRECTDRAWSURFACE		lpDDSOffCoast_a_2;
LPDIRECTDRAWSURFACE		lpDDSOffCoast_b_2;
LPDIRECTDRAWSURFACE		lpDDSOffCoast_a_3;
LPDIRECTDRAWSURFACE		lpDDSOffCoast_b_3;

LPDIRECTDRAWSURFACE		lpDDSOffCoast_a_1_ice;
LPDIRECTDRAWSURFACE		lpDDSOffCoast_b_1_ice;
LPDIRECTDRAWSURFACE		lpDDSOffCoast_a_2_ice;
LPDIRECTDRAWSURFACE		lpDDSOffCoast_b_2_ice;
LPDIRECTDRAWSURFACE		lpDDSOffCoast_a_3_ice;
LPDIRECTDRAWSURFACE		lpDDSOffCoast_b_3_ice;

LPDIRECTDRAWSURFACE		lpDDSOffCoast_a_1_desert;
LPDIRECTDRAWSURFACE		lpDDSOffCoast_b_1_desert;
LPDIRECTDRAWSURFACE		lpDDSOffCoast_a_2_desert;
LPDIRECTDRAWSURFACE		lpDDSOffCoast_b_2_desert;
LPDIRECTDRAWSURFACE		lpDDSOffCoast_a_3_desert;
LPDIRECTDRAWSURFACE		lpDDSOffCoast_b_3_desert;

LPDIRECTDRAWSURFACE		lpDDSOffCoast_a_1_lava;
LPDIRECTDRAWSURFACE		lpDDSOffCoast_b_1_lava;
LPDIRECTDRAWSURFACE		lpDDSOffCoast_a_2_lava;
LPDIRECTDRAWSURFACE		lpDDSOffCoast_b_2_lava;
LPDIRECTDRAWSURFACE		lpDDSOffCoast_a_3_lava;
LPDIRECTDRAWSURFACE		lpDDSOffCoast_b_3_lava;

LPDIRECTDRAWSURFACE		lpDDSOffCoast_a_1_exotic;
LPDIRECTDRAWSURFACE		lpDDSOffCoast_b_1_exotic;
LPDIRECTDRAWSURFACE		lpDDSOffCoast_a_2_exotic;
LPDIRECTDRAWSURFACE		lpDDSOffCoast_b_2_exotic;
LPDIRECTDRAWSURFACE		lpDDSOffCoast_a_3_exotic;
LPDIRECTDRAWSURFACE		lpDDSOffCoast_b_3_exotic;

LPDIRECTDRAWSURFACE     lpDDSOffNebula1;

LPDIRECTDRAWSURFACE     lpDDSOffAtmos1;
LPDIRECTDRAWSURFACE     lpDDSOffAtmos2;
LPDIRECTDRAWSURFACE     lpDDSOffAtmos3;
LPDIRECTDRAWSURFACE     lpDDSOffAtmos4;
LPDIRECTDRAWSURFACE     lpDDSOffAtmos5;
LPDIRECTDRAWSURFACE     lpDDSOffAtmos6;

LPDIRECTDRAWSURFACE     lpDDSOffGasGiant1;

LPDIRECTDRAWSURFACE     lpDDSOffWorlds1;
LPDIRECTDRAWSURFACE     lpDDSOffWorlds2;
LPDIRECTDRAWSURFACE     lpDDSOffWorlds3;
LPDIRECTDRAWSURFACE     lpDDSOffWorlds4;
LPDIRECTDRAWSURFACE     lpDDSOffWorlds5;
LPDIRECTDRAWSURFACE     lpDDSOffWorlds6;
LPDIRECTDRAWSURFACE     lpDDSOffWorlds7;
LPDIRECTDRAWSURFACE     lpDDSOffWorlds8;
LPDIRECTDRAWSURFACE     lpDDSOffWorlds9;

LPDIRECTDRAWSURFACE     lpDDSOffNoble;
LPDIRECTDRAWSURFACE		lpDDSOffInfantry_1;
LPDIRECTDRAWSURFACE		lpDDSOffInfantry_2;
LPDIRECTDRAWSURFACE		lpDDSOffInfantry_3;
LPDIRECTDRAWSURFACE		lpDDSOffInfantry_4;
LPDIRECTDRAWSURFACE		lpDDSOffInfantry_5;


LPDIRECTDRAWPALETTE     lpDDPal;            // The primary surface palette.

HBRUSH hBrushGreen;
HBRUSH hBrushRed;
HBRUSH hBrushJump1;
HBRUSH hBrushJump2;
HBRUSH hBrushJump3;
HPEN 	 hPenJump1;
HPEN 	 hPenJump2;
HPEN 	 hPenJump3;

BOOL                    DestKey = FALSE;    // Destination key capability
BOOL                    bActive;            // Is application active

DWORD					dwBackground;       // background colour
DWORD                   dwGreen;            // Pure green..eh more like pink--Back transperant
DWORD                   dwBlue;             // Pure blue
DWORD                   dwTime;             // time in milisecs
DWORD							dwFrameTime = 0;
DWORD							dwFrameTime2 = 0;

DDBLTFX     ddbltfx;    // For blit effects.
DDCOLORKEY  ddckey;     // For SetColorKey.

RECT        rcRect;     			// For shrinking.
RECT			rcRectSmaleStars;  	// smale stars bmp
RECT			rcRectAstar;         // spectrum of smale stars
RECT			rcRectBstar;
RECT			rcRectCstar;
RECT			rcRectDstar;
RECT			rcRectHstar;         // large map star/world
RECT			rcRectZoom;
RECT			rcRectJump1;
RECT			rcRectJump2;
RECT			rcRectJump3;
RECT			rcRectSuns;
RECT			rcRectRedSun;
RECT			rcRectOrangeSun;
RECT			rcRectYellowSun;
RECT			rcRectBlueSun;
RECT			rcRectWhiteSun;
RECT			rcRectSection2;       // smalle screen section
RECT			rcRectSection1;       // large screen section
RECT			rcRectPlaceSun;       // used for shrinking sun size
RECT			rcRectLetters;        // artificial fonts
RECT			rcRectWorld1;
RECT			rcRectPlaceWorld;
RECT			rcRectShip;

//////////debug///////
int out_num_rivers_ok=0;
int out_num_rivers_ko=0;
int out_num_rivers=0;
int out_mount_rivers=0;
int rivers_no_path_value=0;
int rivers_seeking=0;

int free_nodes=0;
int creat_nodes=0;
///////////////////////

//set dice///
int random ( int rand_range )
{
    int rand_value;
	rand_value=rand()%rand_range;
	return rand_value;
}

