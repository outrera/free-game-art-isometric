void randomname()
	{

      int nameLengh;  int Letter=0;
      int twoDice; int hundredSidedDice; int consDice;
      int nextLetter;
      int rt;
      int twoLetter;

      // first determine lenth of name
      hundredSidedDice=random(100)+1;
      nameLengh=2;        //default
      if ( hundredSidedDice>2 ) {nameLengh=3;}
      if ( hundredSidedDice>10 ) {nameLengh=4;}
      if ( hundredSidedDice>60 ) {nameLengh=5;}

      // then find if the first letter is voyel or consone
        // and do the first letter generation
	  twoDice=(random(6)+1)+(random(6)+1);
	  if ( twoDice<4 )
      	{
                          // voyel
			nextLetter=1;
            twoDice=(random(6)+1)+(random(6)+1);
			if ( twoDice<=2 ) { Name[Letter]='A' ; Name[Letter+1]='u' ; Letter+=2; } //au
			if ( twoDice==3 ) { Name[Letter]='O' ; Name[Letter+1]='u' ; Letter+=2; } //ou
			if ( twoDice==4 ) { Name[Letter]='E' ; Name[Letter+1]='a' ; Letter+=2; } //ea
			if ( twoDice==5 ) { Name[Letter]='A' ;  Letter++; } //a
			if ( twoDice==6 ) { Name[Letter]='A';  Letter++; } //a
			if ( twoDice==7 ) { Name[Letter]='E' ;  Letter++; } //e
			if ( twoDice==8 ) { Name[Letter]='I' ;  Letter++; } //i
			if ( twoDice==9 ) { Name[Letter]='O' ;  Letter++; } //o
			if (twoDice==10 ) { Name[Letter]='U' ;  Letter++; } //u
			if (twoDice==11 ) { Name[Letter]='A' ; Name[Letter+1]='i' ; Letter+=2; } //ai
			if (twoDice>=12 ) { Name[Letter]='A' ; Name[Letter+1]='i' ; Letter+=2; } //ai
         }

      else
     	  	{
      	                  // concone
            nextLetter=0;
            twoDice=(random(6)+1)+(random(6)+1);
            if ( twoDice<9 )               // single letter
      		{
               consDice=(random(21)+1);
				Name[Letter]='A'+consDice ;
			   if ( Name[Letter]=='E' ) { Name[Letter]='B' ; }     //
			   if ( Name[Letter]=='I' ) { Name[Letter]='D' ; }     //
			   if ( Name[Letter]=='O' ) { Name[Letter]='N' ; }     //
			   if ( Name[Letter]=='U' ) { Name[Letter]='T' ; }     //
			   if ( Name[Letter]=='Q' ) { Name[Letter]='Q' ;Name[Letter+1]='u' ; Letter++;}
               Letter++;
            }
            else
            {                             // dual letter
               consDice=(random(21)+1);
			   if ( consDice==1 ) { Name[Letter]='B' ; Name[Letter+1]= 'r';  } //br
				if ( consDice==2 ) { Name[Letter]='B' ; Name[Letter+1]= 'l';  } //bl
				if ( consDice==3 ) { Name[Letter]='C' ; Name[Letter+1]= 'r';  } //cr
			   if ( consDice==4 ) { Name[Letter]='C' ; Name[Letter+1]= 'l';  } //cl
				if ( consDice==5 ) { Name[Letter]='D' ; Name[Letter+1]= 'r';  } //dr
				if ( consDice==6 ) { Name[Letter]='F' ; Name[Letter+1]= 'r';  } //fr
			   if ( consDice==7 ) { Name[Letter]='F' ; Name[Letter+1]= 'l';  } //fl
				if ( consDice==8 ) { Name[Letter]='G' ; Name[Letter+1]= 'r';  } //gr
				if ( consDice==9 ) { Name[Letter]='G' ; Name[Letter+1]= 'l';  } //gl
			   if (consDice==10 ) { Name[Letter]='K' ; Name[Letter+1]= 'n';  } //kn
				if (consDice==11 ) { Name[Letter]='P' ; Name[Letter+1]= 'r';  } //pr
				if (consDice==12 ) { Name[Letter]='P' ; Name[Letter+1]= 'l';  } //pl
			   if (consDice==13 ) { Name[Letter]='S' ; Name[Letter+1]= 'w';  } //sw
				if (consDice==14 ) { Name[Letter]='S' ; Name[Letter+1]= 't';  } //st
				if (consDice==15 ) { Name[Letter]='S' ; Name[Letter+1]= 'l';  } //sl
			   if (consDice==16 ) { Name[Letter]='S' ; Name[Letter+1]= 'k';  } //sk
			   if (consDice==17 ) { Name[Letter]='S' ; Name[Letter+1]= 'h';  } //sh
			   if (consDice==18 ) { Name[Letter]='T' ; Name[Letter+1]= 'r';  } //tr
				if (consDice==19 ) { Name[Letter]='T' ; Name[Letter+1]= 'w';  } //tw
				if (consDice==20 ) { Name[Letter]='W' ; Name[Letter+1]= 'r';  } //wr
			   if (consDice==21 ) { Name[Letter]='W' ; Name[Letter+1]= 'h';  } //wh
               Letter+=2;
            }
         }
      if (Letter==3 && nameLengh>4) {twoLetter=1;}
      else {twoLetter=0;}

      nameLengh--;


      // next work out the middle letters

      for ( rt=nameLengh;rt>1; rt-- )
      {
      	 if ( nextLetter==0 )
      	{
            twoDice=(random(6)+1)+(random(6)+1);
			if ( twoDice<=2 ) { Name[Letter]='a' ; Letter++; } //a
			if ( twoDice==3 ) { Name[Letter]='o' ; Letter++; } //o
			if ( twoDice==4 ) { Name[Letter]='e' ; Letter++; } //e
			if ( twoDice==5 ) { Name[Letter]='a' ;  Letter++; } //a
			if ( twoDice==6 ) { Name[Letter]='a' ;  Letter++; } //a
			if ( twoDice==7 ) { Name[Letter]='e' ;  Letter++; } //e
			if ( twoDice==8 ) { Name[Letter]='i' ;  Letter++; } //i
			if ( twoDice==9 ) { Name[Letter]='o' ;  Letter++; } //o
			if (twoDice==10 ) { Name[Letter]='u' ;  Letter++; } //u
			if (twoDice==11 ) { Name[Letter]='a' ; Letter++; } //a
			if (twoDice>=12 ) { Name[Letter]='e' ; Letter++; } //e
         }
         else
     	  	{
			consDice=(random(21)+1);
			Name[Letter]='a'+consDice ;
			if ( Name[Letter]=='e' ) { Name[Letter]='b' ; }
			if ( Name[Letter]=='i' ) { Name[Letter]='d' ; }
			if ( Name[Letter]=='o' ) { Name[Letter]='l' ; }
			if ( Name[Letter]=='u' ) { Name[Letter]='m' ; }
			//if ( Name[Letter]==27 ) { Name[Letter]=50 ; }
			if ( Name[Letter]=='y' ) { Name[Letter]='r' ; }
			if ( Name[Letter]=='q' ) { Name[Letter]='t' ; }
            Letter++;
            if (twoLetter!=1)           // double consone
            	{
               	twoLetter=1;
                  twoDice=(random(6)+1)+(random(6)+1);
                  if ( twoDice<10 )
                  	{
                     	nextLetter=0;
                        if ( rt<=2 ) { nextLetter=1; }
                  	}
               }
         }
         if (nextLetter==0) {nextLetter=1;}
         else {nextLetter=0;}
      }

      // work out final letter
      if ( nextLetter==0 )
      	{
            twoDice=(random(6)+1)+(random(6)+1);
			if ( twoDice<=2 ) { Name[Letter]='a' ; Name[Letter+1]='w' ; Letter+=2; } //aw
			if ( twoDice==3 ) { Name[Letter]='e' ; Name[Letter+1]='e' ; Letter+=2; } //ee
			if ( twoDice==4 ) { Name[Letter]='u' ; Name[Letter+1]='e' ; Letter+=2; } //ue
			if ( twoDice==5 ) { Name[Letter]='a' ;  Letter++; } //a
			if ( twoDice==6 ) { Name[Letter]='a' ;  Letter++; } //a
			if ( twoDice==7 ) { Name[Letter]='e' ;  Letter++; } //e
			if ( twoDice==8 ) { Name[Letter]='o' ;  Letter++; } //o
			if ( twoDice==9 ) { Name[Letter]='y' ;  Letter++; } //y
			if (twoDice==10 ) { Name[Letter]='u' ;  Letter++; } //u
			if (twoDice==11 ) { Name[Letter]='o' ; Name[Letter+1]='u' ; Letter+=2; } //ou
			if (twoDice>=12 ) { Name[Letter]='a' ; Name[Letter+1]='y' ; Letter+=2; } //ay
         }
      else
     	  	{
            twoDice=(random(6)+1)+(random(6)+1);
            if ( twoDice<8 )               // single letter
      		{
               consDice=(random(21)+1);
				Name[Letter]='a'+consDice ;
				if ( Name[Letter]=='e' ) { Name[Letter]='b' ; }
				if ( Name[Letter]=='i' ) { Name[Letter]='d' ; }
				if ( Name[Letter]=='o' ) { Name[Letter]='l' ; }
				if ( Name[Letter]=='u' ) { Name[Letter]='m' ; }
				//if ( Name[Letter]==27 ) { Name[Letter]='n' ; }
				if ( Name[Letter]=='y' ) { Name[Letter]='r' ; }
			   if ( Name[Letter]=='q' ) { Name[Letter]='t' ; }
               Letter++;
            }
            else
            {                             // dual letter
               consDice=(random(17)+1);
			   if ( consDice==1 ) { Name[Letter]='c' ; Name[Letter+1]= 'k';  } //ck
				if ( consDice==2 ) { Name[Letter]='c' ; Name[Letter+1]= 'h';  } //ch
				if ( consDice==3 ) { Name[Letter]='d' ; Name[Letter+1]= 'd';  } //dd
			   if ( consDice==4 ) { Name[Letter]='f' ; Name[Letter+1]= 'f';  } //ff
				if ( consDice==5 ) { Name[Letter]='g' ; Name[Letter+1]= 'h';  } //gh
				if ( consDice==6 ) { Name[Letter]='t' ; Name[Letter+1]= 'h';  } //th
			   if ( consDice==7 ) { Name[Letter]='l' ; Name[Letter+1]= 'l';  } //ll
				if ( consDice==8 ) { Name[Letter]='l' ; Name[Letter+1]= 'k';  } //lk
				if ( consDice==9 ) { Name[Letter]='l' ; Name[Letter+1]= 't';  } //lt
			   if (consDice==10 ) { Name[Letter]='n' ; Name[Letter+1]= 'g';  } //ng
				if (consDice==11 ) { Name[Letter]='n' ; Name[Letter+1]= 't';  } //nt
				if (consDice==12 ) { Name[Letter]='n' ; Name[Letter+1]= 'd';  } //nd
			   if (consDice==13 ) { Name[Letter]='n' ; Name[Letter+1]= 'k';  } //nk
				if (consDice==14 ) { Name[Letter]='r' ; Name[Letter+1]= 'n';  } //rn
				if (consDice==15 ) { Name[Letter]='r' ; Name[Letter+1]= 'd';  } //rd
			   if (consDice==16 ) { Name[Letter]='s' ; Name[Letter+1]= 's';  } //ss
			   if (consDice==17 ) { Name[Letter]='s' ; Name[Letter+1]= 't';  } //st
               Letter+=2;
            }
         }
	  //Name[0]=Letter;
}
