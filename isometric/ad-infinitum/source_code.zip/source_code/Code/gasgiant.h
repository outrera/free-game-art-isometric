
void Creat_GasGiant (void)
{
	int diceA ;
	diceA = random( Num_GasGiant );
	debugfile ("creating nebula\n", diceA+1 );

	// release offscreen gasgiant if it exists
	if ( lpDDSOffGasGiant1 != NULL )
			{
				lpDDSOffGasGiant1->Release();
				lpDDSOffGasGiant1 = NULL;
			}

    // Create the offscreen gasgiant.
	ddsd.dwHeight = 500;
    ddsd.dwWidth = 500;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffGasGiant1, NULL ) ) )
	{
		debugfile ("could not creat gg\n", 1 );
	}

    if ( diceA < 1 )
    	  {
			 if ( !LoadMyImage( lpDDSOffGasGiant1, "grafix/gg1.bmp" ) )
	    	     {
					 debugfile ("could not load gg1\n", 1 );
                 }
	      }

    if ( diceA == 1 )
    	  {
			 if ( !LoadMyImage( lpDDSOffGasGiant1, "grafix/gg2.bmp" ) )
	    	     {
					 debugfile ("could not load gg2\n", 1 );
                 }
	      }

     if ( diceA == 2 )
    	  {
			 if ( !LoadMyImage( lpDDSOffGasGiant1, "grafix/gg3.bmp" ) )
	    	     {
					 debugfile ("could not load gg3\n", 1 );
                 }
	      }

     if ( diceA == 3 )
    	  {
			 if ( !LoadMyImage( lpDDSOffGasGiant1, "grafix/gg4.bmp" ) )
	    	     {
					 debugfile ("could not load gg4\n", 1 );
                 }
	      }

      if ( diceA == 4 )
    	  {
			 if ( !LoadMyImage( lpDDSOffGasGiant1, "grafix/gg5.bmp" ) )
	    	     {
					 debugfile ("could not load gg5\n", 1 );
                 }
	      }

           if ( diceA == 5 )
    	  {
			 if ( !LoadMyImage( lpDDSOffGasGiant1, "grafix/gg6.bmp" ) )
	    	     {
					 debugfile ("could not load gg6\n", 1 );
                 }
	      }

	      if ( diceA == 6 )
    	  {
			 if ( !LoadMyImage( lpDDSOffGasGiant1, "grafix/gg7.bmp" ) )
	    	     {
					 debugfile ("could not load gg7\n", 1 );
                 }
	      }

	      if ( diceA == 7 )
    	  {
			 if ( !LoadMyImage( lpDDSOffGasGiant1, "grafix/gg8.bmp" ) )
	    	     {
					 debugfile ("could not load gg8\n", 1 );
                 }
	      }

	      if ( diceA == 8 )
    	  {
			 if ( !LoadMyImage( lpDDSOffGasGiant1, "grafix/gg9.bmp" ) )
	    	     {
					 debugfile ("could not load gg9\n", 1 );
                 }
	      }

	      if ( diceA == 9 )
    	  {
			 if ( !LoadMyImage( lpDDSOffGasGiant1, "grafix/gg10.bmp" ) )
	    	     {
					 debugfile ("could not load gg10\n", 1 );
                 }
	      }

	      if ( diceA == 10 )
    	  {
			 if ( !LoadMyImage( lpDDSOffGasGiant1, "grafix/gg11.bmp" ) )
	    	     {
					 debugfile ("could not load gg11\n", 1 );
                 }
	      }

	      if ( diceA == 11 )
    	  {
			 if ( !LoadMyImage( lpDDSOffGasGiant1, "grafix/gg12.bmp" ) )
	    	     {
					 debugfile ("could not load gg12\n", 1 );
                 }
	      }

	      if ( diceA == 12 )
    	  {
			 if ( !LoadMyImage( lpDDSOffGasGiant1, "grafix/gg13.bmp" ) )
	    	     {
					 debugfile ("could not load gg13\n", 1 );
                 }
	      }

	      if ( diceA == 13 )
    	  {
			 if ( !LoadMyImage( lpDDSOffGasGiant1, "grafix/gg14.bmp" ) )
	    	     {
					 debugfile ("could not load gg14\n", 1 );
                 }
	      }

	      if ( diceA == 14 )
    	  {
			 if ( !LoadMyImage( lpDDSOffGasGiant1, "grafix/gg15.bmp" ) )
	    	     {
					 debugfile ("could not load gg15\n", 1 );
                 }
	      }

	      if ( diceA == 15 )
    	  {
			 if ( !LoadMyImage( lpDDSOffGasGiant1, "grafix/gg16.bmp" ) )
	    	     {
					 debugfile ("could not load gg16\n", 1 );
                 }
	      }

	      if ( diceA == 16 )
    	  {
			 if ( !LoadMyImage( lpDDSOffGasGiant1, "grafix/gg17.bmp" ) )
	    	     {
					 debugfile ("could not load gg17\n", 1 );
                 }
	      }

	      if ( diceA == 17 )
    	  {
			 if ( !LoadMyImage( lpDDSOffGasGiant1, "grafix/gg18.bmp" ) )
	    	     {
					 debugfile ("could not load gg18\n", 1 );
                 }
	      }

	      if ( diceA == 18 )
    	  {
			 if ( !LoadMyImage( lpDDSOffGasGiant1, "grafix/gg19.bmp" ) )
	    	     {
					 debugfile ("could not load gg19\n", 1 );
                 }
	      }

	      if ( diceA > 18 )
    	  {
			 if ( !LoadMyImage( lpDDSOffGasGiant1, "grafix/gg20.bmp" ) )
	    	     {
					 debugfile ("could not load gg20\n", 1 );
                 }
	      }

		  if ( lpDDSOffGasGiant1 == NULL )
            {
				debugfile ("did not load any gg\n", 1 );
            }

}

void Place_GasGiant (float x, float y)
{
	double MapAjuster=GalaxySize/280;
	float minX= (((x-550.0)/Small_Place)  )*MapAjuster*2;
	float minY= (((y-325.0)/Small_Place)  )*MapAjuster*2;
	//float Xpos, Ypos;
	RECT  rcRectGasGiant;


	rcRect.left=   ( 800 - minX * 4 )  ;
	rcRect.top=  (( 800 - minY * 4 )+100);
	rcRect.right=   ( 800 - minX * 4 +500);
	rcRect.bottom=    (( 800 - minY * 4 )+100+500);

//	Xpos= ( 600 - minX * 4 )    ;
//	Ypos= ( 400 - minY * 4 )+100;
	rcRectGasGiant.top=     0;
	rcRectGasGiant. bottom= 500;
	rcRectGasGiant.left=    0;
	rcRectGasGiant.right=   500;

	if (rcRect.left<0 && rcRect.right>0)
	{
		rcRectGasGiant.left =rcRectGasGiant.left+((0+(rcRect.left*-1)));
		rcRect.left=0;
	}
	if (rcRect.bottom>0 && rcRect.top<0  )
	{

		rcRectGasGiant.top= rcRectGasGiant.top+((0+(rcRect.top*-1)));
		rcRect.top=0;
	}
	if (rcRect.bottom>screen_y  &&  rcRect.top<screen_y)
	{
		rcRectGasGiant.bottom= rcRectGasGiant.bottom-((rcRect.bottom-screen_y));
		rcRect.bottom=screen_y;
	}
	if (rcRect.right>screen_x && rcRect.left<screen_x)
	{
		rcRectGasGiant.right=rcRectGasGiant.right-((rcRect.right-screen_x));
		rcRect.right=screen_x;
	}

	//if (  (Xpos>-500) && (Ypos>-500)  )
	//             {
	//       	          if  (Xpos<0)   { int(rcRectGasGiant.left=abs(Xpos)); Xpos=0;}
	//                  if  (Ypos<0)   {int(rcRectGasGiant.top=abs(Ypos));  Ypos=0;}
	//				  if  (Xpos>480-500+(12)+(screen_x-500))
	//						   {int(rcRectGasGiant.right=500+(12)+(480-500-Xpos)+(screen_x-500));}
	//				  if  (Ypos>599-500+(screen_y-600))
	//						   {int(rcRectGasGiant.bottom=500+(599-500-Ypos)+(screen_y-600));}
	//			 }

	lpDDSOffScreen->Blt(   &rcRect,
							lpDDSOffGasGiant1,
							&rcRectGasGiant,
							DDBLT_WAIT |
							DDBLT_KEYSRC,NULL );


	//lpDDSOffScreen->BltFast( Xpos,
	//                         Ypos,
	 //						 lpDDSOffGasGiant1,
	 //                        &rcRectGasGiant,
	 //                        DDBLTFAST_WAIT |
	 //                        DDBLTFAST_SRCCOLORKEY );

}
