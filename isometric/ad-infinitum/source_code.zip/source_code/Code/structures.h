struct                           // star system structure
	{
      int		seed;
      unsigned char	spectrum;   // star colour
      unsigned char	size;       //      size
      unsigned char	Bspectrum;   // companion star colour
      unsigned char	Bsize;       // companion   	 size
	  char name[20];    //      name
      short int	    x;             //      x coordinates
      short int	    y;             //      y coordinates
      unsigned char	worldType;  // world type
      unsigned char	worldSize;  //       size
      unsigned char	worldOrbit; //       orbit
      unsigned char	globeX;      // new globe pic (x find)
	  unsigned char	globeY;      // new globe pic (y find)
	  int 			alien;		 // alien home world
	  short int	    Neighbour[10];
	  struct _planet* planet_surface;
	  int owner;                 // who controls palace on world
   } star [250];            	 // absolute max number of stars

struct
	{
   	  int	StarNumber;
      int	starSeed;
	  int	AlphaSunSize;
      int	BetaSunSize;
      int	AlphaSunType;
      int	BetaSunType;
      int	AlphaSunOrbit;
      int	BetaSunOrbit;
      int	orbit[5];  	int	orbitstart[5];
      int	posNOWx[5]; int	posNOWy[5];
      int	GGmoon;
      int	worldmoon;
      int	world;
	}CheckSystem;                // temp viewer of star[] using seed

struct
	{
		//int size;
		int number;
		int hydrotype;
		int hydrosize;
		int landsections;
		int areatype[13];
		int area[7][13];
		int areaatmo[8];
		int arearesourses[12];
	}world;                      // temp viewer for worlds of star[] using seed

struct
	{
		short int capital;     			// world number for home
      short int Number_colonies;    // order first coloniesed
	  //colonie_first
	  //colonie_last
	  short int Number_unexplored;  // order by closest
      //unexplored_first
      //unexplored_last
      short int Number_explored;    // order by degree of exploration
      //explored_first
	  //explored_last
		short int number[10];         // world number tag
		unsigned char status[10];     // explored,survayed,colonized etc...
	}worldlist[999];       				// GREATER_RACES

typedef struct _NODE              // struct space ships
{
	struct _NODE*	next;
	struct _NODE*	prev;
   int				going_to;
   int				start_at;
   short int 		doing;
   unsigned int 	arrive_time;
   unsigned int		start_time;

}NODE;

typedef struct _TASK              // struct tasks
{
	struct _TASK*	next;
 	struct _TASK*	prev;
   short int 		alien_id;
   int				location;
   short int 		doing;
   unsigned int 	time;
   unsigned int	start_time;
}TASK;

typedef struct _NOTKNOWN             // struct unexplored
{
	struct _NOTKNOWN*	next;
 	struct _NOTKNOWN*	prev;
   short int 		world_number;
   short int      closest_distance;
}NOTKNOWN;

typedef struct _EXPLORED              // struct explored
{
	struct _EXPLORED*	next;
	struct _EXPLORED*	prev;
   short int 		world_number;
   short int      exploration;
}EXPLORED;

typedef struct _COLONY                // struct colony
{
	struct _COLONY*	next;
 	struct _COLONY*	prev;
   short int 		world_number;
   short int      to_capital;
   short int		colony_type;
   short int		colony_size;
}COLONY;

//////////////////////////////////////////////////

typedef struct _town       //town is a group of building hexes
	{
		unsigned char            type;               // fort, hospital, town, factory, mine ect..
		unsigned char            aligence;
		unsigned char            population;
		unsigned char            blank1;
		unsigned char			 town_number;
		struct _town*		     next;
		struct _town*		     prev;
		struct _building*		 housing;
		struct _building*		 industry;
		////
		//struct _unit*	unit_in_building;
		//struct _hex*    hex;
	}town;
typedef town* LPtown;

typedef struct _LABOUR
	{
		struct _building*		home;
		struct _building*		work;
		struct _LABOUR*			next;	///used to find the other labour in towns
		unsigned char           aligence;
		unsigned char           type;
		////unit long pointer here for army etc////
		////given that unit may be offworld, may need pointer to homeworld///
	}LABOUR;
typedef LABOUR* LPLABOUR;

typedef struct _building
	{
		int						 location_x;
		int						 location_y;
		unsigned char            type;               // fort, hospital, town, factory, mine ect..
		unsigned char            aligence;
		unsigned char            population;
		unsigned char            blank1;
		unsigned char			 town_number;
		struct _building*		 next;
		struct _building*		 prev;
		struct _LABOUR*			 worker;
		// struct _unit*	unit_in_building;
		// struct _hex*    hex;
	}building;
typedef building* LPbuilding;

typedef struct _hex
	{
		unsigned char                type;     // hill, marsh, mount, plaine, forest ect..
        unsigned char                sub_type; // type of sea, hill mount etc
		unsigned char                flag;     // binary flags for rivers , crevases
		unsigned char                blank1;   // used temp mount hill set
		unsigned char                coast;    // cost line (binary flag)
		unsigned char                resourse; // metal, gem, radioactive, trace, spice, oil
		unsigned char                road;     // binary flag for road

		unsigned char                X_hex_location; //reference to planet_matrice[X][ ]
		unsigned char                Y_hex_location; //reference to planet_matrice[ ][Y]

		struct _planet*		planet; ///pointer to the hexs home
		struct _building*	build_in_hex; // pointer to the hexs infrastructure
		struct _unit*	    unit_in_hex;  // pointer to units in hex
	}hex;
typedef hex* LPhex;

struct
	{
		struct _hex*			popu;

	}Check_popu[6];

struct
	{
		struct _hex*			home_hex;
		struct _hex*			work_hex;
		struct _building*		building_selected;
		struct _LABOUR*			worker;
	}popu_selected;


typedef struct _planet
	{
		unsigned char planet_type;

		unsigned char hydro_type;                      // H�o, clore, lava, heavy gas ect...
		unsigned char hydro_size;                      // 0% to 100%

		unsigned char section_type;                    // seas, islands, lakes, crevaces ect..
		unsigned char land_type;                       // temp, jungle, ice, desert, barren ect..

		unsigned char plant_type;                       //
		unsigned char plant_size;                       //

		unsigned char swamp_size;

		int number;                          // used to see struct: star [number]
		struct _hex* planet_matrice[48][48]; // size of planet

		struct _town*		     first_town;
		struct _building*		 palace;
		struct _building*		 forts;
		struct _building*		 churches;
		struct _building*		 mines;
		struct _building*		 wells;
		struct _building*		 farms;
		struct _building*		 starports;
		struct _building*		 labs;
        struct _building*		 ruins;
		struct _building*		 other_build;

	}planet;
typedef planet* LPplanet;
///////////////////////////////////////

typedef struct _UNIT_DOING_TASK              // struct tasks
{
		struct _unit*				unit_doing;
		struct _unit*				link_to_another_unit;
		struct _UNIT_DOING_TASK*	next;
		struct _UNIT_DOING_TASK*	prev;
		int							going_to_x;
		int							going_to_y;
		long						start_at_x;
		long						start_at_y;
		short int 					doing;
		DWORD 						time;
		DWORD						start_time;
}UNIT_DOING_TASK;

//////////////////////////
typedef UNIT_DOING_TASK* LPUNIT_DOING_TASK;
LPUNIT_DOING_TASK g_bottom_unit_task ;
LPUNIT_DOING_TASK g_top_unit_task ;
/////////////////////////////
typedef struct _HEX_LIST              // terraine hexes
{
   int x_location;
   int y_location;
   struct _HEX_LIST*	next;
   struct _HEX_LIST*	prev;
   int	   value;
   struct _HEX_LIST*	creater;
   int creater_direction;
}HEX_LIST;

typedef HEX_LIST* LPHEX_LIST;    //hexs on list
LPHEX_LIST g_bottom_hex_list;
LPHEX_LIST g_top_hex_list;
LPHEX_LIST desti_hex_list;

///structure-unit////
typedef struct _unit
	{
		short int 				 hex_x_loc;
		short int 				 hex_y_loc;

		unsigned char            type;               // army, hely, tank, artilery, civil ect..
		unsigned char            aligence;
		unsigned char            blank1;
		unsigned char            facing; //direction facing in hex///used if  at rest or attacking

		struct _unit*	next;
		struct _unit*   next_in_hex;
		struct _unit*   prev_in_hex;
		struct _hex*    hex;

		struct _LPhex_path*	going_path;
		struct _HEX_LIST*   desty_path;      ///REMOVE ONNCE DEBUG IN FAVOUR OF PATH

		struct _UNIT_DOING_TASK* task;

	}unit;
typedef unit* LPunit;
////global unit selected////
LPunit unit_selected;  //global click on flag to move, set to null
LPunit unit_first_in_list;  //global finder for unit list

//// ///////////////////////////////////
typedef struct _LPhex_path              // path nodes to be used in actual movement
{
		struct _hex*    	hex_this_path_node_at;
		struct _LPhex_path*	next_path_node;
		unsigned char direction_next_path_node;
}hex_path;
typedef hex_path* LPhex_path;    //hexs on list
///////////////////////////////////////////////////////////////////////////////
// a few Globals
    //ships
typedef NODE* LPNODE;    //tasks
LPNODE g_bottom_node;
LPNODE g_top_node;

typedef TASK* LPTASK;    //tasks
LPTASK g_bottom_task;
LPTASK g_top_task;

typedef NOTKNOWN* LPNOTKNOWN;    	//unexplored
LPNOTKNOWN g_bottom_notknown;
LPNOTKNOWN g_top_notknown;

typedef EXPLORED* LPEXPLORED;    		//explored
LPEXPLORED g_bottom_explored;
LPEXPLORED g_top_explored;

typedef COLONY* LPCOLONY;    				//colonys
LPCOLONY g_bottom_colony;
LPCOLONY g_top_colony;
