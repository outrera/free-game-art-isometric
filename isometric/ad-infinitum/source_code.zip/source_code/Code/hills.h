////////////////////////////////////////////////////////////////////////
//////////hills mountains and forests///////////////////////////////////

void hills( LPplanet planet_creat )
{ 
   int ny,nx; int dice;
   //find individual hills from sections 
   for (ny=0; ny< planet_size_y; ny++)  
   {  
       for (nx=0; nx< planet_size_x; nx++ ) 
       { 
           if  (planet_creat->planet_matrice[nx][ny]->blank1  == HILL)  
           {
               if (planet_creat->planet_matrice[nx][ny]->type == PLAIN)
               {
                   dice=random(100)+1;
                   if ( dice < 25 )
                   {
                       planet_creat->planet_matrice[nx][ny]->type = HILL;
                   }
               }    
               //planet_creat->planet_matrice[nx][ny]->blank1 = NOT_USED;  
           }
           
           if  (planet_creat->planet_matrice[nx][ny]->blank1  == MOUNT)  
		   {
               if (planet_creat->planet_matrice[nx][ny]->type == PLAIN)
               {
                   dice=random(100)+1;
                   if ( dice < 25 )
                   {
                       planet_creat->planet_matrice[nx][ny]->type = HILL;
                   }
               }     
           } 
              
       }      
   }
   place_terain( planet_creat, PLAIN, NONE, HILL, HILL, hills_adjust, GROW_BY_INCREES );
   place_terain( planet_creat, PLAIN, NONE, HILL, HILL, hills_adjust, GROW_BY_INCREES );
   place_terain( planet_creat, PLAIN, NONE, HILL, HILL, hills_adjust, GROW_BY_INCREES );
   place_terain( planet_creat, PLAIN, NONE, HILL, HILL, hills_adjust, GROW_BY_INCREES );
   place_terain( planet_creat, PLAIN, NONE, HILL, HILL, hills_adjust, GROW_BY_INCREES );
   
   for (ny=0; ny< planet_size_y; ny++)  
   {  
       for (nx=0; nx< planet_size_x; nx++ ) 
       {     
           if  (planet_creat->planet_matrice[nx][ny]->blank1  == MOUNT)  
           {
               if (    (planet_creat->planet_matrice[nx][ny]->type == PLAIN)
                    || (planet_creat->planet_matrice[nx][ny]->type == HILL)   )
               {
				   dice=random(100)+1;
                   if ( dice < 25 )
                   {
                       planet_creat->planet_matrice[nx][ny]->type = MOUNT;
                   }
               }     
           }
           planet_creat->planet_matrice[nx][ny]->blank1 = NOT_USED;    
       }      
   }
   if  (planet_creat->planet_type  != OASIS  || planet_creat->planet_type  != DESERT)
	{
		place_terain( planet_creat, PLAIN, HILL, MOUNT, MOUNT, hills_adjust, GROW_BY_NEIBOUR );
		place_terain( planet_creat, PLAIN, HILL, MOUNT, MOUNT, hills_adjust, GROW_BY_NEIBOUR );
		place_terain( planet_creat, PLAIN, HILL, MOUNT, MOUNT, hills_adjust, GROW_BY_NEIBOUR );
		place_terain( planet_creat, PLAIN, HILL, MOUNT, MOUNT, hills_adjust, GROW_BY_NEIBOUR );
		place_terain( planet_creat, PLAIN, HILL, MOUNT, MOUNT, hills_adjust, GROW_BY_NEIBOUR );
	}
	else
	{
		
	}
}

/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////

void place_terain( LPplanet planet_creat,
						int change_from_1, int change_from_2,
						int change_to_1, int change_to_2, int rnd_factor,
						unsigned char place_type )
{
    
   int check_hex_x, check_hex_y;
   int Number_diferent;
   //int change_for_coast;
   int temp [100][100];
   int nx,ny;
   int odd_even;
   int planet_number = planet_creat->number;
   int dice;
   
    for (ny=0; ny< planet_size_y; ny++)  
   {  
	   for (nx=0; nx< planet_size_x; nx++ ) { temp [nx][ny] =  0; }  //set to null
   }
   
      
   for (ny=0; ny< planet_size_y; ny++)  
   {  
       
	   odd_even = (ny+1) % 2;
            
	   for (nx=0; nx< planet_size_x; nx++ )
       {          
            //if ( planet_number ==0 ) debugfile ("X  \n", nx );
            // check to see which terain changing

                
            if (     (planet_creat->planet_matrice[nx][ny]->type == change_from_1)
                  || (planet_creat->planet_matrice[nx][ny]->type == change_from_2)   )
            { 
                Number_diferent=0;
                
                if ( planet_creat->planet_matrice[nx][ny] == NULL ) debugfile ("error....no hex \n", planet_number );
                
                /// check east hex
                check_hex_x = nx+1;
                if ( check_hex_x >= planet_size_x ) 
                     { check_hex_x = 0; }  //go round world if over
				if ( change_to_1 == (planet_creat->planet_matrice[check_hex_x][ny]->type) ||
					 change_to_2 == (planet_creat->planet_matrice[check_hex_x][ny]->type) )
                     { Number_diferent++; }
                     
                /// check west hex
                check_hex_x = nx-1;
                if ( check_hex_x < 0 ) 
					 { check_hex_x = planet_size_x-1; }  //go round world if over
				if ( change_to_1 == (planet_creat->planet_matrice[check_hex_x][ny]->type) ||
					 change_to_2 == (planet_creat->planet_matrice[check_hex_x][ny]->type) )
					 { Number_diferent++; }
                
                /// check north west hex 
                check_hex_y = ny-1;
                if ( check_hex_y >= 0 ) //only check if not over top
                {  
                     if ( odd_even == 1 )
					 {
						   if ( change_to_1 == (planet_creat->planet_matrice[nx][check_hex_y]->type) ||
								change_to_2 == (planet_creat->planet_matrice[nx][check_hex_y]->type))
							{ Number_diferent++; }
                     } 
                     else
                     {
                           check_hex_x = nx-1;
                           if ( check_hex_x < 0 ) 
                             { check_hex_x = planet_size_x-1; }  //go round world if over
						   if ( change_to_1 == (planet_creat->planet_matrice[check_hex_x][check_hex_y]->type) ||
								change_to_2 == (planet_creat->planet_matrice[check_hex_x][check_hex_y]->type))
							 { Number_diferent++; }
                     } 
                }       
                
                /// check north east hex
                check_hex_y = ny-1;
                if ( check_hex_y >= 0 ) //only check if not over top
                {   
                     if ( odd_even == 0 )
					 {
						   if ( change_to_1 == (planet_creat->planet_matrice[nx][check_hex_y]->type) ||
								change_to_2 == (planet_creat->planet_matrice[nx][check_hex_y]->type))
							{ Number_diferent++; }
					 }
                     else
                     {
                           check_hex_x = nx+1;
                           if ( check_hex_x >= planet_size_x ) 
                                { check_hex_x = 0; }  //go round world if over
						   if ( change_to_1 == (planet_creat->planet_matrice[check_hex_x][check_hex_y]->type) ||
								change_to_2 == (planet_creat->planet_matrice[check_hex_x][check_hex_y]->type))
								{ Number_diferent++; }
                     } 
                }       
                   
                
                /// check South west hex
                check_hex_y = ny+1;
                if ( check_hex_y < planet_size_y ) //only check if not over bottom
                {  
                     if ( odd_even == 1 )
					 {
						   if ( change_to_1 == (planet_creat->planet_matrice[nx][check_hex_y]->type) ||
								change_to_2 == (planet_creat->planet_matrice[nx][check_hex_y]->type))
                            { Number_diferent++; }
                     } 
                     else
                     {
                           check_hex_x = nx-1;
                           if ( check_hex_x < 0 ) 
                             { check_hex_x = planet_size_x-1; }  //go round world if over
						   if ( change_to_1 == (planet_creat->planet_matrice[check_hex_x][check_hex_y]->type) ||
								change_to_2 == (planet_creat->planet_matrice[check_hex_x][check_hex_y]->type))
							 { Number_diferent++; }
                     } 
                }    
                
                /// check South east hex
                check_hex_y = ny+1;
                if ( check_hex_y < planet_size_y ) //only check if not over bottom
                {   
                     if ( odd_even == 0 )
                     {
						   if ( change_to_1 == (planet_creat->planet_matrice[nx][check_hex_y]->type) ||
								change_to_2 == (planet_creat->planet_matrice[nx][check_hex_y]->type))
							{ Number_diferent++; }
                     } 
                     else
                     {
                           check_hex_x = nx+1;
                           if ( check_hex_x >= planet_size_x ) 
                                { check_hex_x = 0; }  //go round world if over
						   if ( change_to_1 == (planet_creat->planet_matrice[check_hex_x][check_hex_y]->type) ||
								change_to_2 == (planet_creat->planet_matrice[check_hex_x][check_hex_y]->type))
								{ Number_diferent++; }
                     } 
                }
                       
                if ( place_type == GROW_BY_INCREES )
                { 
					 dice=random(100)+1;
					 if ( dice < (Number_diferent*rnd_factor) )
					 {  temp [nx][ny] = 1;  }
                }
                if ( place_type == GROW_BY_NEIBOUR )
                { 
					 if ( Number_diferent >= 1 )
					 {
						  dice=random(100)+1;
						  if ( dice < rnd_factor )
						  {  temp [nx][ny] = 1;  }
					 }
                }
                if ( place_type == GROW_BY_CHAIN )
                { 
					 if ( Number_diferent >= 1 )
					 {
                          dice=random(100)+1;
                          if ( dice > (Number_diferent*rnd_factor) )
                          {  temp [nx][ny] = 1;  }
					 }
                }
				if ( place_type == GROW_BY_SEPERATE )
                { 
					 //if ( Number_diferent < 1 )
					 //{
					 //     dice=random(100)+1;
					 //	  if ( dice > 99 )
					 //     {  temp [nx][ny] = 1;  }
					 //}
                      if ( Number_diferent >= 1 )
					 {
						  dice=random(100)+1;
					 if ( dice < (Number_diferent*rnd_factor) )
					 {  temp [nx][ny] = 1;  }
					 }
                }
                    
                            
				if ( check_hex_x < 0 )
				debugfile ("error....check hex less than zero, x\n", check_hex_x );
				if ( check_hex_x >= planet_size_x )
				debugfile ("error....check hex too big, x\n", check_hex_x );
            }
           
       }    
   }
   
   for (ny=0; ny< planet_size_y; ny++)  
   {  
       for (nx=0; nx< planet_size_x; nx++ ) 
       { 
           if ( temp [nx][ny] == 1 )
                {  
					temp [nx][ny] = 0;
					if (  planet_creat->planet_matrice[nx][ny]->type == change_from_1   )
						 { planet_creat->planet_matrice[nx][ny]->type = change_to_1; }

					if (  planet_creat->planet_matrice[nx][ny]->type == change_from_2  )
						 { planet_creat->planet_matrice[nx][ny]->type = change_to_2; }
                }
       }        
   }
                  
}        

