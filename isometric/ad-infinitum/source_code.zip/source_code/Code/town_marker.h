 int find_profession ( int building_type )
 {
	   int return_value;
	   switch ( building_type )
		{
			case FACTORY:
			return_value=FACTORY_WORKER;
			break;

			case PALACE:
			return_value=PALACE_STAFF;
			break;

			case CHEMY:
			return_value=FACTORY_WORKER_CHEMY;
			break;

			case STEEL:
			return_value=FACTORY_WORKER_STEEL;
			break;

			case ELEC:
			return_value=FACTORY_WORKER_ELEC;
			break;

			case FARM:
			return_value=FARMER;
			break;

			case MINE:
			return_value=MINER;
			break;

			case WELL:
			return_value=OILWELL_WORKER;
			break;

			case OFFSHORE_WELL:
			return_value=OILPLATFORM_WORKER;
			break;

			case STARPORT:
			return_value=STAR_PORT_DOCKER;
			break;

			case UNI:
			return_value=UNI_ASSISTANT;
			break;

			case LAB:
			return_value=LAB_ASSISTANT;
			break;

			case ENCLOSED_FARM:
			return_value=FARMER;
			break;

			case MINE_TRACE:
			return_value=MINER_TRACE;
			break;

			case MINE_GEMS:
			return_value=MINER_GEMS;
			break;

			case MINE_HYPER_STEEL:
			return_value=MINER_HYPER_STEEL;
			break;

			case MINE_RADIOACTIVE:
			return_value=MINER_RADIOACTIVE;
			break;

			case MINE_CHEMY:
			return_value=MINER_CHEMY;
			break;

			case MINE_GOLD:
			return_value=MINER_GOLD;
			break;
		}
		return return_value;
 }

 ///////////////////////////////////////////////////////////
 int icon_activation (  LPLABOUR the_icon_used, LPbuilding the_building_going )
 {
	 return false; //turn off for debug

	 ///first check that aligenge is the sane for icon and desty
	 if (the_icon_used->aligence!=the_building_going->aligence)
	 {
		 return false;
	 }
	 //then check buidding type not special
	 if (the_building_going->type==BARRACKS)
	 {
		 return false;
	 }
	 //then check buidding type if not Home
	 if (the_building_going->type==TOWN)
	 {
		 return false;
	 }
	 ///then check if building can take popu units
	 if ( 		(the_building_going->type==FARM_LAND)
			||	(the_building_going->type==RUINS)
			||	(the_building_going->type==FORT)
			||	(the_building_going->type==CHURCH)		)
	 {
		 return false;
	 }
	 //then check if industry or building asosiated with town
	 if ( 		(the_building_going->type==FACTORY)
			||	(the_building_going->type==CHEMY)
			||	(the_building_going->type==ELEC)
			||	(the_building_going->type==STEEL)  )
	 {
		 //if true, check that pert of same town
		 if (the_icon_used->home->town_number!=the_building_going->town_number)
		{
			return false;
		}
	 }
	 ///check if not the same building/worker
	 if ( the_building_going == the_icon_used->work )
	 {
	 	return true;
	 }
	 ///if all is ok, assigne new popu, return old popu to its town (if any)

		 if (the_icon_used->work!=(LPbuilding)NULL)
		 {
			//security
			if (the_icon_used->work->worker != (LPLABOUR)NULL)
			{
				the_icon_used->work->worker->work = (LPbuilding)NULL;
				the_icon_used->work->worker = (LPLABOUR)NULL;
			}
		 }
		 if (the_building_going->worker!=(LPLABOUR)NULL)
		 {
			the_building_going->worker->work=(LPbuilding)NULL;
			the_building_going->worker->type= UNEMPLOYED;
		 }


	 the_building_going->worker=the_icon_used;
	 the_icon_used->work=the_building_going;
	 the_icon_used->type = find_profession ( the_building_going->type );
	 return true;
 }
 ///////////////////////////////////////////////////////////////
void click_on_world_hex ( LPhex the_hex, LPplanet planet, int  nx, int ny )
{
	if (the_hex==Check_popu[0].popu)
	{
		// return;   ///return if allready have info
	}
	///set all to null
	Check_popu[0].popu = (LPhex)NULL;
	Check_popu[1].popu = (LPhex)NULL;
	Check_popu[2].popu = (LPhex)NULL;
	Check_popu[3].popu = (LPhex)NULL;
	Check_popu[4].popu = (LPhex)NULL;
	Check_popu[5].popu = (LPhex)NULL;
	town_view_on_off=false;
	work_view_on_off=false;
	///check location///
	if (the_hex->build_in_hex!=(LPbuilding) NULL)  ///check if on building
	{
		LPLABOUR workers ;
		int nnn=1;
		if (the_hex->build_in_hex->type==TOWN)   ///if on town
		{
				  hex_view_x = nx;
				  hex_view_y = ny;
				  town_view_on_off=true;
				  work_view_on_off=false;
				  if (town_view_number==the_hex->build_in_hex->town_number)
				  {
					 LMouseBeenUsed=false;
				  }
				  else
				  {
					 town_view_number=the_hex->build_in_hex->town_number;
					 LMouseBeenUsed=true;
				  }

				  /*
                      Check_popu[0].popu = the_hex;

					  for ( workers=the_hex->build_in_hex->worker; workers != (LPLABOUR)NULL; workers=workers->next )
					  {

							if( (workers->work!=(LPbuilding)NULL)   )
							{
								Check_popu[nnn].popu = planet->planet_matrice[workers->work->location_x][workers->work->location_y];
							}

							nnn++  ;
					  }
                  */

		}
		else   ///if not on town
		{
				  if  (the_hex->build_in_hex->worker == (LPLABOUR)NULL)
				  {
						town_view_on_off=false;
						work_view_on_off=false;

						return;
				  }
				  hex_view_x = nx;
				  hex_view_y = ny;
				  town_view_on_off=true;
				  work_view_on_off=false;
				  if (town_view_number==the_hex->build_in_hex->worker->home->town_number)
				  {
					 LMouseBeenUsed=false;
				  }
				  else
				  {
					 town_view_number=the_hex->build_in_hex->worker->home->town_number;
					 LMouseBeenUsed=true;
				  }



/*       ///////turned off for debug....using system of all town view for now
    			town_view_on_off=false;

    			town_view_number=NONE;
    			hex_view_x = nx;
    			hex_view_y = ny;
    			///security incase building does not have workers
    			if (the_hex->build_in_hex->worker!=(LPLABOUR)NULL)
    			{
    				  workers=the_hex->build_in_hex->worker;
    				  //Check_popu[1].popu = the_hex ;
    				  if( (the_hex->build_in_hex->worker->home!=(LPbuilding)NULL)   )
    				  {
    						work_view_on_off=true;
    						Check_popu[0].popu = planet->planet_matrice[workers->home->location_x][workers->home->location_y];
    						for ( workers=Check_popu[0].popu->build_in_hex->worker; workers != (LPLABOUR)NULL; workers=workers->next )
    						{

    							if( (workers->work!=(LPbuilding)NULL)   )
    							{
    							 Check_popu[nnn].popu = planet->planet_matrice[workers->work->location_x][workers->work->location_y];
    							}

    							nnn++  ;
    						}
    				  }

				}
*/
		}
	}

}
 /////////////////////////


