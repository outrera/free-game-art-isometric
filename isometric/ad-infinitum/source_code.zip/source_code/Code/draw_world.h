void place_moon_object_neb ( LPplanet planet_draw, double first_x, double first_y )
{
	float neb_stretch_factor = (500 * nebula_size)/2;

	RECT		rcRectPutNeb;
	RECT		rcRectGetNeb;

	rcRectGetNeb.bottom = 	500;             // default get terraines
	rcRectGetNeb.right = 	500;
	rcRectGetNeb.left=		0;
	rcRectGetNeb.top=		0;

	rcRectPutNeb.bottom = 	first_y+200+neb_stretch_factor;             // default get terraines
	rcRectPutNeb.right = 	1600+neb_stretch_factor;
	rcRectPutNeb.left=		1600-neb_stretch_factor;
	rcRectPutNeb.top=		200+first_y-neb_stretch_factor;

	if (rcRectPutNeb.left<0 && rcRectPutNeb.right>0)
	{
		rcRectGetNeb.left =rcRectGetNeb.left+((0+(rcRectPutNeb.left*-1))/nebula_size);
		rcRectPutNeb.left=0;
	}
	if (rcRectPutNeb.bottom>0 && rcRectPutNeb.top<0  )
	{

		rcRectGetNeb.top= rcRectGetNeb.top+((0+(rcRectPutNeb.top*-1))/nebula_size);
		rcRectPutNeb.top=0;
	}
	if (rcRectPutNeb.bottom>screen_y  &&  rcRectPutNeb.top<screen_y)
	{
		rcRectGetNeb.bottom= rcRectGetNeb.bottom-((rcRectPutNeb.bottom-screen_y)/nebula_size);
		rcRectPutNeb.bottom=screen_y;
	}
	if (rcRectPutNeb.right>screen_x && rcRectPutNeb.left<screen_x)
	{
		rcRectGetNeb.right=rcRectGetNeb.right-((rcRectPutNeb.right-screen_x)/nebula_size);
		rcRectPutNeb.right=screen_x;
	}

	lpDDSBack->Blt(   &rcRectPutNeb,
							lpDDSOffNebula1,
							&rcRectGetNeb,
							DDBLT_WAIT |
							DDBLT_KEYSRC,NULL );
}

void place_moon_object_gg ( LPplanet planet_draw, double first_x, double first_y )
{
	 ///gg //
	int gg_size=2;
	float neb_stretch_factor = (500 * 2)/gg_size;
	RECT		rcRectPutGG;
	RECT		rcRectGetGG;

	rcRectGetGG.bottom = 	500;             // default get terraines
	rcRectGetGG.right = 	500;
	rcRectGetGG.left=		0;
	rcRectGetGG.top=		0;

	rcRectPutGG.bottom = 	first_y+200+neb_stretch_factor;             // default get terraines
	rcRectPutGG.right = 	-50+neb_stretch_factor;
	rcRectPutGG.left=		-50-neb_stretch_factor;
	rcRectPutGG.top=		200+first_y-neb_stretch_factor;

	if (rcRectPutGG.left<0 && rcRectPutGG.right>0)
	{
		rcRectGetGG.left =rcRectGetGG.left+((0+(rcRectPutGG.left*-1))/gg_size);
		rcRectPutGG.left=0;
	}
	if (rcRectPutGG.bottom>0 && rcRectPutGG.top<0  )
	{

		rcRectGetGG.top= rcRectGetGG.top+((0+(rcRectPutGG.top*-1))/gg_size);
		rcRectPutGG.top=0;
	}
	if (rcRectPutGG.bottom>screen_y  &&  rcRectPutGG.top<screen_y)
	{
		rcRectGetGG.bottom= rcRectGetGG.bottom-((rcRectPutGG.bottom-screen_y)/gg_size);
		rcRectPutGG.bottom=screen_y;
	}
	if (rcRectPutGG.right>screen_x && rcRectPutGG.left<screen_x)
	{
		rcRectGetGG.right=rcRectGetGG.right-((rcRectPutGG.right-screen_x)/gg_size);
		rcRectPutGG.right=screen_x;
	}

	lpDDSBack->Blt(   &rcRectPutGG,
							lpDDSOffGasGiant1,
							&rcRectGetGG,
							DDBLT_WAIT |
							DDBLT_KEYSRC,NULL );
}

void place_atmosphere ( LPplanet planet_draw, double first_x, double first_y )
{

	RECT		rcRectPutAtmo;
	RECT		rcRectGetAtmo;

	rcRectGetAtmo.bottom = 	360;             // default get terraines
	rcRectGetAtmo.right = 	9;
	rcRectGetAtmo.left=		0;
	rcRectGetAtmo.top=		0;

	int ZoomDownY;
	int can_leave_loop=false;

	for (int i = 0; ; i++)
	{
				ZoomDownY = 360-(360.0/ZooM);

				rcRectPutAtmo.left =   first_x+(9*i);           // default place terrains
				rcRectPutAtmo.top =    (first_y+(ZoomDownY))+120/ZooM;
				rcRectPutAtmo.right  = first_x+(9*(i+1));
				rcRectPutAtmo.bottom = (first_y+(360.0/ZooM)+ZoomDownY)+120/ZooM;

				 // the scroll cut
				if (rcRectPutAtmo.bottom>screen_y  &&  rcRectPutAtmo.top<screen_y)
					{
						rcRectGetAtmo.bottom =360-((rcRectPutAtmo.bottom-screen_y)*ZooM);
						rcRectPutAtmo.bottom=screen_y;
					}
				if (rcRectPutAtmo.bottom>0  &&  rcRectPutAtmo.top<0)
					{
					   rcRectGetAtmo.top =((0+(rcRectPutAtmo.top*-1)));
					   rcRectPutAtmo.top=0;
					}
				if (rcRectPutAtmo.right>screen_x && rcRectPutAtmo.left<screen_x)
					{
						rcRectGetAtmo.right=rcRectGetAtmo.right-((rcRectPutAtmo.right-screen_x));
						rcRectPutAtmo.right=screen_x;
						can_leave_loop=true;
					}

				//diferent atmos for diferent planets
				if (planet_draw->planet_type==LAVA)
				{
					lpDDSBack->Blt( &rcRectPutAtmo , lpDDSOffAtmos3, &rcRectGetAtmo,
											   DDBLT_WAIT |
											   DDBLT_KEYSRC, NULL );
				}
				else if (planet_draw->planet_type==ICE)
				{
					lpDDSBack->Blt( &rcRectPutAtmo , lpDDSOffAtmos2, &rcRectGetAtmo,
											   DDBLT_WAIT |
											   DDBLT_KEYSRC, NULL );
				}
				else if (planet_draw->planet_type==EXOTIC)
				{
					lpDDSBack->Blt( &rcRectPutAtmo , lpDDSOffAtmos5, &rcRectGetAtmo,
											   DDBLT_WAIT |
											   DDBLT_KEYSRC, NULL );
				}
				else if (planet_draw->planet_type==JUNGLE)
				{
					lpDDSBack->Blt( &rcRectPutAtmo , lpDDSOffAtmos4, &rcRectGetAtmo,
											   DDBLT_WAIT |
											   DDBLT_KEYSRC, NULL );
				}
				else if (planet_draw->planet_type==SWAMP)
				{
					lpDDSBack->Blt( &rcRectPutAtmo , lpDDSOffAtmos4, &rcRectGetAtmo,
											   DDBLT_WAIT |
											   DDBLT_KEYSRC, NULL );
				}
				else     // default atmo
				{
					lpDDSBack->Blt( &rcRectPutAtmo , lpDDSOffAtmos1, &rcRectGetAtmo,
											   DDBLT_WAIT |
											   DDBLT_KEYSRC, NULL );
				}

				if (can_leave_loop==true)
				{
					 break;
				}
	}


}
///////////////////////////////// ///////////////////////////
/////////////////////////////////  .........................
/////////////////////////////////  ........................
///////////////////////////////// /////////////////////////////
void Draw_the_World ( LPplanet planet_draw, double first_x, double first_y )
{
  LMouse_Hex_Click   = false;

  //Right_mouse_check=false;
  //Left_mouse_check=false;
   //first check if not exit world map // or click on skyline

   int start_at_x;
   int start_at_y;

   int facterOFtwo;





	if  ( (RMouseDown==true) && (RMouse_triger==true) )
	{
		//update: exit to space if right click or deselect or out zoom
		//{
		//	Cursor_Type=NONE;
			//LMouse_Hex_Click   = false;

		//}

		//if (RMouseyPos<first_y)  //old system of click on spacw=go to space

		if (ORBITAL_VIEW == true)
		{
				town_view_on_off=false;
				work_view_on_off=false;
				LMouseBeenUsed=false;
				Cursor_Type=NONE;
				ScreenType=MAP;
				LMouse_Hex_Click   = false;
				RMouse_triger=false;
				return;
		}
	}




   int animation_frame_number;
   int ajust_animation_frame_number;

   LPhex next_hex;
   LPhex thehex;
   //LPNODE next_node;
   //LPNODE thenode;
   //int anipace; int facing;

	RECT		rcRectGet_coast;  // area get for  coast
	RECT		rcRectPut_coast;  // area put for  coast

	RECT        rcRect_get_object;     // For small objects.
	RECT        rcRect_put_object;

	//RECT        rcRectFlag; // Small animation
	RECT			rcRectHex;  // Hex area in form of square

	//RECT			rcRectMen;  // sheet of people animation

	RECT			rcRect_120x120    ;
	RECT			rcRectGet_120x120 ;

	RECT			rcRect_120x60    ;
	RECT			rcRectGet_120x60 ;

	RECT			rcRect_120x80    ;
	RECT			rcRectGet_120x80 ;

   //.right=240; .left=0; .top=0; .bottom=240;
	//rcRectHex.left = 0; rcRectHex.top =  0; rcRectHex.right =210; rcRectHex.bottom =90;

   LPhex start_hex= planet_draw->planet_matrice[planet_size_x][0] ;

	double x= first_x;
	double y= first_y;
	int ny=0;
	unsigned char river_type;
	unsigned char coast_type;
	unsigned char road_type;
	int nn; int n;

   ZeroMemory( &ddbltfx, sizeof( ddbltfx ) );
   ddbltfx.dwSize = sizeof( ddbltfx );

   // Fill the surface with background colour .
   ddbltfx.dwFillColor = dwBackground;
   lpDDSBack->Blt( NULL, NULL,        // black out screen
							NULL,
						DDBLT_COLORFILL |
						DDBLT_WAIT, &ddbltfx );


	if ( (RMouseDown == true) && ( ORBITAL_VIEW == false ) && (RMouse_triger==true) )
				{

					LMouse_Hex_Click   = false;
					RMouse_triger=false;

					//Right_mouse_check   =false;

					if (Cursor_Type == FLAG_ICON_CURSOR)
						{
							Cursor_Type = NONE;
							unit_selected=(LPunit)NULL;
						}

					else if ( (town_view_on_off==true) && (work_view_on_off=true) )
						{
							town_view_on_off=false;
							work_view_on_off=false;
						}
					else
						{
							ORBITAL_VIEW = true;
						}

					//debugfile ("ZooM x 1000\n", ZooM * 1000 );
				}

	if ( ORBITAL_VIEW == true )  //no map scroll if orbit view, reset map to fixed position
		{
			x= screen_x;
			first_x= screen_x;
			ZooM=(101.0*48.0)/screen_x;
		    y= screen_y-(45/ZooM)-(48*(45/ZooM))+((45/ZooM)*ZooM);
			first_y= screen_y-(45/ZooM)-(48*(45/ZooM))+((45/ZooM)*ZooM);
		}



   //atmosphere
   if (planet_draw->planet_type!=MOON)  // not atmo for moons
   {
	  place_atmosphere ( planet_draw, 0, (y-360));
   }
   else
   {
	   place_moon_object_neb ( planet_draw, 0, (y-300) );
   }

   //fill star background
   if (planet_draw->planet_type==MOON)
   {
	  StarBackground (0 , (y-(Y_size *3))+120);
   }
   else
   {
	  StarBackground (0 , (y-(Y_size *3))-(120/ZooM));
   }

   //gg object
   if (planet_draw->planet_type==MOON)
   {
	  place_moon_object_gg ( planet_draw, 0, (y-500) );
   }

	start_at_x=x;//useful to find start after loop without retdoing map or zoom calculations
	start_at_y=y;

   for ( int ny = 0 ; ny < planet_size_y ; ny++ )
   {

	  if ( y > screen_y ) {break;} // no point drawing if out south

	  nn = (ny+1) % 2;


	  if (nn==0) { x= first_x; }
	  else { x=first_x - (45.0/ZooM); }

	  for ( int nx = 0 ;  ; nx++ )
	  {

			if (nx >= planet_size_x)
			{
                nx=0;
			}
			thehex =  planet_draw->planet_matrice [nx][ny];

			animation_frame_number = (thehex->sub_type)+ animation1;
			if (animation_frame_number > 10)
			{
				animation_frame_number = animation_frame_number-10;
			}



			rcRect_120x120.left = x;                     // default place terrains
			rcRect_120x120.top =  y;
			rcRect_120x120.right =x+(120.0/ZooM);
			rcRect_120x120.bottom =y+(120.0/ZooM);

			rcRect_120x60.left = x;                     // default place terrains
			rcRect_120x60.top =  y;
			rcRect_120x60.right =x+(120.0/ZooM);
			rcRect_120x60.bottom =y+(120.0/ZooM);

			rcRect_120x80.left = x;                     // default place terrains
			rcRect_120x80.top =  y;
			rcRect_120x80.right =x+(120.0/ZooM);
			rcRect_120x80.bottom =y+(120.0/ZooM);

			if ( rcRect_120x120.right < 0 ) { break; } // next if out west

			rcRectGet_120x120.bottom = 	120;             // default get terraines
			rcRectGet_120x120.right = 	120;
			rcRectGet_120x120.left=		0;
			rcRectGet_120x120.top=		0;

			rcRectGet_120x60.bottom = 	120;             // default get terraines
			rcRectGet_120x60.right = 	120;
			rcRectGet_120x60.left=		0;
			rcRectGet_120x60.top=		0;

			rcRectGet_120x80.bottom = 	120;             // default get terraines
			rcRectGet_120x80.right = 	120;
			rcRectGet_120x80.left=		0;
			rcRectGet_120x80.top=		0;


			// fake hex rectagle possition
			/*
			rcRectHex.left = (x )+(15/2)/ZooM;
			rcRectHex.top =  (y )+(135/2)/ZooM;
			rcRectHex.right =(x)+120/ZooM -15/ZooM;
			rcRectHex.bottom =(y)+120/ZooM -15/ZooM;
		   */
			rcRectHex.left = x+(7.0/ZooM);                     // default hex
			rcRectHex.right =x+(113.0/ZooM);
			rcRectHex.top =  y+60/ZooM;
			rcRectHex.bottom =y+105/ZooM;

			// first scroll cut (e & w)
			if (rcRect_120x120.right>screen_x  &&  rcRect_120x120.left<screen_x)
					{rcRectGet_120x120.right =120-((rcRect_120x120.right-screen_x)*ZooM);rcRect_120x120.right=screen_x;}
			if (rcRect_120x120.right>0  &&  rcRect_120x120.left<0)
					{rcRectGet_120x120.left =((0+(rcRect_120x120.left*-1))*ZooM);rcRect_120x120.left=0; }

			// first scroll cut (e & w)
			if (rcRect_120x60.right>screen_x  &&  rcRect_120x60.left<screen_x)
					{rcRectGet_120x60.right =120-((rcRect_120x60.right-screen_x)*ZooM);rcRect_120x60.right=screen_x;}
			if (rcRect_120x60.right>0  &&  rcRect_120x60.left<0)
					{rcRectGet_120x60.left =((0+(rcRect_120x60.left*-1))*ZooM);rcRect_120x60.left=0; }

			// first scroll cut (e & w)
			if (rcRect_120x80.right>screen_x  &&  rcRect_120x80.left<screen_x)
					{
						rcRectGet_120x80.right =120-((rcRect_120x80.right-screen_x)*ZooM);
						rcRect_120x80.right=screen_x;
					}
			if (rcRect_120x80.right>0  &&  rcRect_120x80.left<0)
					{
						rcRectGet_120x80.left =((0+(rcRect_120x80.left*-1))*ZooM);
						rcRect_120x80.left=0;
					}

			//////////set 120x120 hexes////////////
			rcRect_120x120.top =  		y;
			rcRect_120x120.bottom =		y+120/ZooM;
			rcRectGet_120x120.bottom = 	120;  // default get terraines
			rcRectGet_120x120.top=		0;
			if (rcRect_120x120.bottom>screen_y  &&  rcRect_120x120.top<screen_y)// the scroll cut (n & s)
						{
							rcRectGet_120x120.bottom =120-((rcRect_120x120.bottom-screen_y)*ZooM);
							rcRect_120x120.bottom=screen_y;
						}
			if (rcRect_120x120.bottom>0  &&  rcRect_120x120.top<0)
						{
							rcRectGet_120x120.top =(0+(rcRect_120x120.top*-1))*ZooM;
							rcRect_120x120.top=0;
						}

			//////////set 120x60 hexes////////////
			rcRect_120x60.top =  y+60/ZooM;
			rcRect_120x60.bottom =y+120/ZooM;
			rcRectGet_120x60.top=		  0; //reset from scroll adjust
			rcRectGet_120x60.bottom = 	60;
			if (rcRect_120x60.bottom>screen_y  &&  rcRect_120x60.top<screen_y)          // the scroll cut
					{
						rcRectGet_120x60.bottom =60-((rcRect_120x60.bottom-screen_y)*ZooM);
						rcRect_120x60.bottom=screen_y;
					}
			if (rcRect_120x60.bottom>0  &&  rcRect_120x60.top<0)
					{
						rcRectGet_120x60.top =(0+(rcRect_120x60.top*-1))*ZooM;
						rcRect_120x60.top=0;
					}

			//////////set 120x80 hexes////////////
			rcRect_120x80.top =  y+40/ZooM;
			rcRect_120x80.bottom =y+120/ZooM;
			rcRectGet_120x80.top=		  0; //reset from scroll adjust
			rcRectGet_120x80.bottom = 	 80;
			if (rcRect_120x80.bottom>screen_y  &&  rcRect_120x80.top<screen_y)          // the scroll cut
					{
						rcRectGet_120x80.bottom =80-((rcRect_120x80.bottom-screen_y)*ZooM);
						rcRect_120x80.bottom=screen_y;
					}
			if (rcRect_120x80.bottom>0  &&  rcRect_120x80.top<0)
					{
						rcRectGet_120x80.top =(0+(rcRect_120x80.top*-1))*ZooM;
						rcRect_120x80.top=0;
					}
			//////////////////////////////////////

			//  center of hex (usefull for placing things)
			//int centerx = (rcRectHex.left)+(105/2)/ZooM;   // centerx=120
			//int centery = (rcRectHex.top)+(45/2)/ZooM;     // centery=   80
			int centerx = x+(60/ZooM);   // centerx=120
			int centery = y+(90/ZooM);     // centery=   80

			//   find left click location
			if 	(       (LMousexPos >  rcRectHex.left )
				   &&   (LMousexPos <= rcRectHex.right)
			       &&   (LMouseyPos >  rcRectHex.top )
			       &&   (LMouseyPos <= rcRectHex.bottom)
			       &&	(LMouseDown==true) && (LMouse_triger==true) ) //&& (LMouse_Hex_Click   == true)
				{

					/////////////click location////////////
					LMouse_Hex_Click_X = nx;
					LMouse_Hex_Click_Y = ny;
					LMouse_Hex_Click   = true;
					//RMouse_Hex_Click   = false;
                    //LMouse_triger=false;

				}



				/*
				if (LMouseDown==1)

				{
					Left_mouse_check =true;
				}
				else
				{
					Left_mouse_check =false;
				}

				if (RMouseDown==1)

				{
					Right_mouse_check =true;
				}
				else
				{
					Right_mouse_check =false;
				}

				*/


			 //   find right click location
			if 	((RMousexPos >  rcRectHex.left )
				&&  (RMousexPos <= rcRectHex.right)
			   &&  (RMouseyPos >  rcRectHex.top )
			   &&  (RMouseyPos <= rcRectHex.bottom)
			   &&	(RMouseDown==1))
				{

					/////////////click location////////////
					RMouse_Hex_Click_X = nx;
					RMouse_Hex_Click_Y = ny;
					RMouse_Hex_Click   = true;


				}
			else
				{
					RMouse_Hex_Click   = false;

                }

				/////////////////place map and returm if orbit view and map in memory////////////////////
				if (DRAWN_PLANET_MAP==true)
				{

					//lpDDSBack->BltFast( 0, 0 ,  lpDDSOffWorlds, NULL,
					//					  DDBLTFAST_WAIT |
					//					   DDBLTFAST_SRCCOLORKEY );
					//return;

				}
				///////////////////////////////////

				///check if LEFT click on buildding//////
			 if ( LMouse_Hex_Click==true && LMouse_Hex_Click_X == nx &&  LMouse_Hex_Click_Y == ny)
			 {
				   if (  (thehex->build_in_hex!=(LPbuilding) NULL) || (unit_selected!=(LPunit)NULL))
				   {
						click_on_world_hex ( thehex, planet_draw, nx, ny ) ;
				   }
				   else
				   {
						town_view_on_off=false;
						work_view_on_off=false;
				   }
			 }

					///////////////////////////////////////

				  int move_horizon_x; int horizon_adjust;


					if (thehex->type == PLAIN)            // plaine
					{

						if (planet_draw->land_type==PLAIN)
						{
								lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffPlain, &rcRectGet_120x60,
											   DDBLT_WAIT |
											   DDBLT_KEYSRC, NULL );
						}
						if (planet_draw->land_type==WATER)
						{
								lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffPlain, &rcRectGet_120x60,
											   DDBLT_WAIT |
											   DDBLT_KEYSRC, NULL );
						}
						if (planet_draw->land_type==JUNGLE)
						{
								lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffPlain, &rcRectGet_120x60,
											   DDBLT_WAIT |
											   DDBLT_KEYSRC, NULL );
						}
						if (planet_draw->land_type==GREY)
						{
								lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffPlain_Moon, &rcRectGet_120x60,
											   DDBLT_WAIT |
											   DDBLT_KEYSRC, NULL );
						}
						if (planet_draw->land_type==EXOTIC)
						{
								lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffPlain_Exotic, &rcRectGet_120x60,
											   DDBLT_WAIT |
											   DDBLT_KEYSRC, NULL );
						}
						if (planet_draw->land_type==BROWN)
						{
								if (thehex->sub_type==1 ||thehex->sub_type==2)
								{
									lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffPlain_Desert1, &rcRectGet_120x60,
											   DDBLT_WAIT |
											   DDBLT_KEYSRC, NULL );
								}
								if (thehex->sub_type==3 ||thehex->sub_type==4)
								{
									lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffPlain_Desert2, &rcRectGet_120x60,
											   DDBLT_WAIT |
											   DDBLT_KEYSRC, NULL );
								}
								if (thehex->sub_type==5 ||thehex->sub_type==6)
								{
									lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffPlain_Desert3, &rcRectGet_120x60,
											   DDBLT_WAIT |
											   DDBLT_KEYSRC, NULL );
								}
								if (thehex->sub_type==7 ||thehex->sub_type==8)
								{
									lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffPlain_Desert4, &rcRectGet_120x60,
											   DDBLT_WAIT |
											   DDBLT_KEYSRC, NULL );
								}
								if (thehex->sub_type==9 ||thehex->sub_type==10)
								{
									lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffPlain_Desert5, &rcRectGet_120x60,
											   DDBLT_WAIT |
											   DDBLT_KEYSRC, NULL );
								}
						}


						if (planet_draw->land_type==WHITE)
						{
								lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffPlain_Ice, &rcRectGet_120x60,
											   DDBLT_WAIT |
											   DDBLT_KEYSRC, NULL );
						}
						if (planet_draw->land_type==DARK)
						{
								lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffPlain_Lava, &rcRectGet_120x60,
											   DDBLT_WAIT |
											   DDBLT_KEYSRC, NULL );
						}
						if (planet_draw->land_type==SWAMP)
						{
								lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffPlain, &rcRectGet_120x60,
											   DDBLT_WAIT |
											   DDBLT_KEYSRC, NULL );

						}
					}
					////////////
					if (thehex->build_in_hex!=(LPbuilding) NULL)  //place farm land under river
					{
						if (thehex->build_in_hex->type==FARM_LAND)       // farm land
						{
							lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffStruct_farm_land, &rcRectGet_120x60,
														   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );
						}
						if (thehex->build_in_hex->type==FARM)       // land under farm
						{
							lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffStruct_farm_land, &rcRectGet_120x60,
														   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );
						}

					}
				////////surface under plant////////
				////////temp plain under plant/////////
				if ( (thehex->type == PLANT_PLAIN) )
				{
						lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffPlain, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
				}
				////////temp swamp under plant/////////
				if ( (thehex->type == PLANT_SWAMP) && (planet_draw->planet_type != OASIS))
				{
						lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffSwamp, &rcRectGet_120x60,
								DDBLT_WAIT |
								DDBLT_KEYSRC, NULL );
				}
				////////temp hill under plant/////////
				if ( (thehex->type == PLANT_HILL) )
				{

								if (thehex->sub_type==1 ||thehex->sub_type==2)
								{
									lpDDSBack->Blt ( &rcRect_120x80 , lpDDSOffHill1, &rcRectGet_120x80,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
								if (thehex->sub_type==3 ||thehex->sub_type==4)
								{
									lpDDSBack->Blt ( &rcRect_120x80 , lpDDSOffHill2, &rcRectGet_120x80,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
								if (thehex->sub_type==5 ||thehex->sub_type==6)
								{
									lpDDSBack->Blt ( &rcRect_120x80 , lpDDSOffHill3, &rcRectGet_120x80,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
								if (thehex->sub_type==7 ||thehex->sub_type==8)
								{
									lpDDSBack->Blt ( &rcRect_120x80 , lpDDSOffHill4, &rcRectGet_120x80,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
								if (thehex->sub_type==9 ||thehex->sub_type==10)
								{
									lpDDSBack->Blt ( &rcRect_120x80 , lpDDSOffHill5, &rcRectGet_120x80,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}

				}
				//////////oasis Swamp plain under plant//////
				if ( (thehex->type == PLANT_SWAMP) && (planet_draw->planet_type == OASIS))
				{


						if (thehex->sub_type==1 ||thehex->sub_type==2)
									{
										lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffPlain_Dry1, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );

									}
						if (thehex->sub_type==3 ||thehex->sub_type==4)
									{
										lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffPlain_Dry2, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );

									}
						if (thehex->sub_type==5 ||thehex->sub_type==6)
									{
										lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffPlain_Dry3, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );

									}
						if (thehex->sub_type==7 ||thehex->sub_type==8)
									{
										lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffPlain_Dry4, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );

									}
						if (thehex->sub_type==9 ||thehex->sub_type==10)
									{
										lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffPlain_Dry5, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );

									}
				}
					///////////swamp/////////////
					if (thehex->type == SWAMP)
					{
						if (planet_draw->planet_type!=OASIS)
							{
								lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffSwamp, &rcRectGet_120x60,
								DDBLT_WAIT |
								DDBLT_KEYSRC, NULL );
							}
						else
							{
								if (thehex->sub_type==1 ||thehex->sub_type==2)
									{
										lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffPlain_Dry1, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
									}
								if (thehex->sub_type==3 ||thehex->sub_type==4)
									{
										lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffPlain_Dry2, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
									}
								if (thehex->sub_type==5 ||thehex->sub_type==6)
									{
										lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffPlain_Dry3, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
									}
								if (thehex->sub_type==7 ||thehex->sub_type==8)
									{
										lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffPlain_Dry4, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
									}
								if (thehex->sub_type==9 ||thehex->sub_type==10)
									{
										lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffPlain_Dry5, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
									}

								//////////

								if (thehex->build_in_hex!=(LPbuilding) NULL)  //place farm land under river
								{
									if (thehex->build_in_hex->type==FARM_LAND)       // farm land
										{
											lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffStruct_farm_land, &rcRectGet_120x60,
														   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );
										}
									if (thehex->build_in_hex->type==FARM)       // land under farm
										{
											lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffStruct_farm_land, &rcRectGet_120x60,
														   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );
										}

								}

								//desert coast line//

								coast_type = thehex->coast;

								if ( (coast_type & FLAG_EAST)!= NONE )     // note: directions E W reversed
								{
									rcRectPut_coast.left = x;
									rcRectPut_coast.top =  y+(60.0/ZooM);
									rcRectPut_coast.right =x+(40.0/ZooM);
									rcRectPut_coast.bottom =y+(120.0/ZooM);

									rcRectGet_coast.left=		0;
									rcRectGet_coast.top=		0;
									rcRectGet_coast.right = 	40;
									rcRectGet_coast.bottom = 	60;

									if (thehex->sub_type==1 ||thehex->sub_type==2 ||thehex->sub_type==3 ||thehex->sub_type==4)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_1_desert, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==5 ||thehex->sub_type==6 ||thehex->sub_type==7 ||thehex->sub_type==8)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_2_desert, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==9 ||thehex->sub_type==10 )
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_3_desert, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
								}
								if ( (coast_type & FLAG_NORTH_WEST)!= NONE )
								{
									rcRectPut_coast.left = x+(40.0/ZooM);
									rcRectPut_coast.top =  y+(60.0/ZooM);
									rcRectPut_coast.right =x+(120.0/ZooM);
									rcRectPut_coast.bottom =y+(90.0/ZooM);

									rcRectGet_coast.left=		40;
									rcRectGet_coast.top=		0;
									rcRectGet_coast.right = 	120;
									rcRectGet_coast.bottom = 	30;

									if (thehex->sub_type==1 ||thehex->sub_type==2 ||thehex->sub_type==3 ||thehex->sub_type==4)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_1_desert, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==5 ||thehex->sub_type==6 ||thehex->sub_type==7 ||thehex->sub_type==8)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_2_desert, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==9 ||thehex->sub_type==10 )
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_3_desert, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
								}
								if ( (coast_type & FLAG_SOUTH_WEST)!= NONE )
								{
									rcRectPut_coast.left = x+(40.0/ZooM);
									rcRectPut_coast.top =  y+(90.0/ZooM);
									rcRectPut_coast.right =x+(120.0/ZooM);
									rcRectPut_coast.bottom =y+(120.0/ZooM);

									rcRectGet_coast.left=		40;
									rcRectGet_coast.top=		30;
									rcRectGet_coast.right = 	120;
									rcRectGet_coast.bottom = 	60;

									if (thehex->sub_type==1 ||thehex->sub_type==2 ||thehex->sub_type==3 ||thehex->sub_type==4)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_1_desert, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==5 ||thehex->sub_type==6 ||thehex->sub_type==7 ||thehex->sub_type==8)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_2_desert, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==9 ||thehex->sub_type==10 )
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_3_desert, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
								}


								if ( (coast_type & FLAG_WEST)!= NONE )
								{
									rcRectPut_coast.left = x+(80/ZooM);
									rcRectPut_coast.top =  y+(60.0/ZooM);
									rcRectPut_coast.right =x+(120.0/ZooM);
									rcRectPut_coast.bottom =y+(120.0/ZooM);

									rcRectGet_coast.left=		80;
									rcRectGet_coast.top=		0;
									rcRectGet_coast.right = 	120;
									rcRectGet_coast.bottom = 	60;

									if (thehex->sub_type==1 ||thehex->sub_type==2 ||thehex->sub_type==3 ||thehex->sub_type==4)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_1_desert, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==5 ||thehex->sub_type==6 ||thehex->sub_type==7 ||thehex->sub_type==8)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_2_desert, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==9 ||thehex->sub_type==10 )
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_3_desert, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
								}
								if ( (coast_type & FLAG_NORTH_EAST)!= NONE )
								{
									rcRectPut_coast.left = x;
									rcRectPut_coast.top =  y+(60.0/ZooM);
									rcRectPut_coast.right =x+(80.0/ZooM);
									rcRectPut_coast.bottom =y+(90.0/ZooM);

									rcRectGet_coast.left=		0;
									rcRectGet_coast.top=		0;
									rcRectGet_coast.right = 	80;
									rcRectGet_coast.bottom = 	30;

									if (thehex->sub_type==1 ||thehex->sub_type==2 ||thehex->sub_type==3 ||thehex->sub_type==4)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_1_desert, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==5 ||thehex->sub_type==6 ||thehex->sub_type==7 ||thehex->sub_type==8)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_2_desert, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==9 ||thehex->sub_type==10 )
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_3_desert, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
								}
								if ( (coast_type & FLAG_SOUTH_EAST)!= NONE )
								{
									rcRectPut_coast.left = x;
									rcRectPut_coast.top =  y+(90.0/ZooM);
									rcRectPut_coast.right =x+(80.0/ZooM);
									rcRectPut_coast.bottom =y+(120.0/ZooM);

									rcRectGet_coast.left=		0;
									rcRectGet_coast.top=		30;
									rcRectGet_coast.right = 	80;
									rcRectGet_coast.bottom = 	60;

									if (thehex->sub_type==1 ||thehex->sub_type==2 ||thehex->sub_type==3 ||thehex->sub_type==4)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_1_desert, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==5 ||thehex->sub_type==6 ||thehex->sub_type==7 ||thehex->sub_type==8)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_2_desert, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==9 ||thehex->sub_type==10 )
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_3_desert, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
								}

							//}
							}
					}

					///////////hydro////////
					if (planet_draw->hydro_type==LAVA)
					{
						if (thehex->type == HYDRO )
						{
							lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffSea_lava, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
						}

						if (thehex->type ==  SHALOW )
						{
							lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffShalow_Sea_lava, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
						}

						if (thehex->type ==  DEEP)
						{
							lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffDeep_Sea_lava, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
						}
						//lava coast line//
						if ( thehex->type == SHALOW )
						{
							coast_type = thehex->coast;

								if ( (coast_type & FLAG_EAST)!= NONE )     // note: directions E W reversed
								{
									rcRectPut_coast.left = x;
									rcRectPut_coast.top =  y+(60.0/ZooM);
									rcRectPut_coast.right =x+(40.0/ZooM);
									rcRectPut_coast.bottom =y+(120.0/ZooM);

									rcRectGet_coast.left=		0;
									rcRectGet_coast.top=		0;
									rcRectGet_coast.right = 	40;
									rcRectGet_coast.bottom = 	60;

									if (thehex->sub_type==1 ||thehex->sub_type==2 ||thehex->sub_type==3 ||thehex->sub_type==4)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_1_lava, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==5 ||thehex->sub_type==6 ||thehex->sub_type==7 ||thehex->sub_type==8)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_2_lava, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==9 ||thehex->sub_type==10 )
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_3_lava, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
								}
								if ( (coast_type & FLAG_NORTH_WEST)!= NONE )
								{
									rcRectPut_coast.left = x+(40.0/ZooM);
									rcRectPut_coast.top =  y+(60.0/ZooM);
									rcRectPut_coast.right =x+(120.0/ZooM);
									rcRectPut_coast.bottom =y+(90.0/ZooM);

									rcRectGet_coast.left=		40;
									rcRectGet_coast.top=		0;
									rcRectGet_coast.right = 	120;
									rcRectGet_coast.bottom = 	30;

									if (thehex->sub_type==1 ||thehex->sub_type==2 ||thehex->sub_type==3 ||thehex->sub_type==4)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_1_lava, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==5 ||thehex->sub_type==6 ||thehex->sub_type==7 ||thehex->sub_type==8)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_2_lava, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==9 ||thehex->sub_type==10 )
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_3_lava, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
								}
								if ( (coast_type & FLAG_SOUTH_WEST)!= NONE )
								{
									rcRectPut_coast.left = x+(40.0/ZooM);
									rcRectPut_coast.top =  y+(90.0/ZooM);
									rcRectPut_coast.right =x+(120.0/ZooM);
									rcRectPut_coast.bottom =y+(120.0/ZooM);

									rcRectGet_coast.left=		40;
									rcRectGet_coast.top=		30;
									rcRectGet_coast.right = 	120;
									rcRectGet_coast.bottom = 	60;

									if (thehex->sub_type==1 ||thehex->sub_type==2 ||thehex->sub_type==3 ||thehex->sub_type==4)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_1_lava, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==5 ||thehex->sub_type==6 ||thehex->sub_type==7 ||thehex->sub_type==8)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_2_lava, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==9 ||thehex->sub_type==10 )
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_3_lava, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
								}


								if ( (coast_type & FLAG_WEST)!= NONE )
								{
									rcRectPut_coast.left = x+(80/ZooM);
									rcRectPut_coast.top =  y+(60.0/ZooM);
									rcRectPut_coast.right =x+(120.0/ZooM);
									rcRectPut_coast.bottom =y+(120.0/ZooM);

									rcRectGet_coast.left=		80;
									rcRectGet_coast.top=		0;
									rcRectGet_coast.right = 	120;
									rcRectGet_coast.bottom = 	60;

									if (thehex->sub_type==1 ||thehex->sub_type==2 ||thehex->sub_type==3 ||thehex->sub_type==4)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_1_lava, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==5 ||thehex->sub_type==6 ||thehex->sub_type==7 ||thehex->sub_type==8)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_2_lava, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==9 ||thehex->sub_type==10 )
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_3_lava, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
								}
								if ( (coast_type & FLAG_NORTH_EAST)!= NONE )
								{
									rcRectPut_coast.left = x;
									rcRectPut_coast.top =  y+(60.0/ZooM);
									rcRectPut_coast.right =x+(80.0/ZooM);
									rcRectPut_coast.bottom =y+(90.0/ZooM);

									rcRectGet_coast.left=		0;
									rcRectGet_coast.top=		0;
									rcRectGet_coast.right = 	80;
									rcRectGet_coast.bottom = 	30;

									if (thehex->sub_type==1 ||thehex->sub_type==2 ||thehex->sub_type==3 ||thehex->sub_type==4)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_1_lava, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==5 ||thehex->sub_type==6 ||thehex->sub_type==7 ||thehex->sub_type==8)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_2_lava, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==9 ||thehex->sub_type==10 )
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_3_lava, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
								}
								if ( (coast_type & FLAG_SOUTH_EAST)!= NONE )
								{
									rcRectPut_coast.left = x;
									rcRectPut_coast.top =  y+(90.0/ZooM);
									rcRectPut_coast.right =x+(80.0/ZooM);
									rcRectPut_coast.bottom =y+(120.0/ZooM);

									rcRectGet_coast.left=		0;
									rcRectGet_coast.top=		30;
									rcRectGet_coast.right = 	80;
									rcRectGet_coast.bottom = 	60;

									if (thehex->sub_type==1 ||thehex->sub_type==2 ||thehex->sub_type==3 ||thehex->sub_type==4)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_1_lava, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==5 ||thehex->sub_type==6 ||thehex->sub_type==7 ||thehex->sub_type==8)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_2_lava, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==9 ||thehex->sub_type==10 )
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_3_lava, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
								}

						}
					}
					else if (planet_draw->hydro_type==ACID)
					{
						if (thehex->type == HYDRO )
						{
							lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffSea_exotic, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
						}

						if (thehex->type ==  SHALOW )
						{
							lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffShalow_Sea_exotic, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
						}

						if (thehex->type ==  DEEP)
						{
							lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffDeep_Sea_exotic, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
						}
						//exotic coast line//
					  	if ( thehex->type == SHALOW )
						{
							coast_type = thehex->coast;

								if ( (coast_type & FLAG_EAST)!= NONE )     // note: directions E W reversed
								{
									rcRectPut_coast.left = x;
									rcRectPut_coast.top =  y+(60.0/ZooM);
									rcRectPut_coast.right =x+(40.0/ZooM);
									rcRectPut_coast.bottom =y+(120.0/ZooM);

									rcRectGet_coast.left=		0;
									rcRectGet_coast.top=		0;
									rcRectGet_coast.right = 	40;
									rcRectGet_coast.bottom = 	60;

									if (thehex->sub_type==1 ||thehex->sub_type==2 ||thehex->sub_type==3 ||thehex->sub_type==4)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_1_exotic, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==5 ||thehex->sub_type==6 ||thehex->sub_type==7 ||thehex->sub_type==8)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_2_exotic, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==9 ||thehex->sub_type==10 )
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_3_exotic, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
								}
								if ( (coast_type & FLAG_NORTH_WEST)!= NONE )
								{
									rcRectPut_coast.left = x+(40.0/ZooM);
									rcRectPut_coast.top =  y+(60.0/ZooM);
									rcRectPut_coast.right =x+(120.0/ZooM);
									rcRectPut_coast.bottom =y+(90.0/ZooM);

									rcRectGet_coast.left=		40;
									rcRectGet_coast.top=		0;
									rcRectGet_coast.right = 	120;
									rcRectGet_coast.bottom = 	30;

									if (thehex->sub_type==1 ||thehex->sub_type==2 ||thehex->sub_type==3 ||thehex->sub_type==4)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_1_exotic, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==5 ||thehex->sub_type==6 ||thehex->sub_type==7 ||thehex->sub_type==8)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_2_exotic, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==9 ||thehex->sub_type==10 )
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_3_exotic, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
								}
								if ( (coast_type & FLAG_SOUTH_WEST)!= NONE )
								{
									rcRectPut_coast.left = x+(40.0/ZooM);
									rcRectPut_coast.top =  y+(90.0/ZooM);
									rcRectPut_coast.right =x+(120.0/ZooM);
									rcRectPut_coast.bottom =y+(120.0/ZooM);

									rcRectGet_coast.left=		40;
									rcRectGet_coast.top=		30;
									rcRectGet_coast.right = 	120;
									rcRectGet_coast.bottom = 	60;

									if (thehex->sub_type==1 ||thehex->sub_type==2 ||thehex->sub_type==3 ||thehex->sub_type==4)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_1_exotic, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==5 ||thehex->sub_type==6 ||thehex->sub_type==7 ||thehex->sub_type==8)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_2_exotic, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==9 ||thehex->sub_type==10 )
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_3_exotic, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
								}


								if ( (coast_type & FLAG_WEST)!= NONE )
								{
									rcRectPut_coast.left = x+(80/ZooM);
									rcRectPut_coast.top =  y+(60.0/ZooM);
									rcRectPut_coast.right =x+(120.0/ZooM);
									rcRectPut_coast.bottom =y+(120.0/ZooM);

									rcRectGet_coast.left=		80;
									rcRectGet_coast.top=		0;
									rcRectGet_coast.right = 	120;
									rcRectGet_coast.bottom = 	60;

									if (thehex->sub_type==1 ||thehex->sub_type==2 ||thehex->sub_type==3 ||thehex->sub_type==4)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_1_exotic, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==5 ||thehex->sub_type==6 ||thehex->sub_type==7 ||thehex->sub_type==8)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_2_exotic, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==9 ||thehex->sub_type==10 )
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_3_exotic, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
								}
								if ( (coast_type & FLAG_NORTH_EAST)!= NONE )
								{
									rcRectPut_coast.left = x;
									rcRectPut_coast.top =  y+(60.0/ZooM);
									rcRectPut_coast.right =x+(80.0/ZooM);
									rcRectPut_coast.bottom =y+(90.0/ZooM);

									rcRectGet_coast.left=		0;
									rcRectGet_coast.top=		0;
									rcRectGet_coast.right = 	80;
									rcRectGet_coast.bottom = 	30;

									if (thehex->sub_type==1 ||thehex->sub_type==2 ||thehex->sub_type==3 ||thehex->sub_type==4)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_1_exotic, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==5 ||thehex->sub_type==6 ||thehex->sub_type==7 ||thehex->sub_type==8)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_2_exotic, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==9 ||thehex->sub_type==10 )
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_3_exotic, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
								}
								if ( (coast_type & FLAG_SOUTH_EAST)!= NONE )
								{
									rcRectPut_coast.left = x;
									rcRectPut_coast.top =  y+(90.0/ZooM);
									rcRectPut_coast.right =x+(80.0/ZooM);
									rcRectPut_coast.bottom =y+(120.0/ZooM);

									rcRectGet_coast.left=		0;
									rcRectGet_coast.top=		30;
									rcRectGet_coast.right = 	80;
									rcRectGet_coast.bottom = 	60;

									if (thehex->sub_type==1 ||thehex->sub_type==2 ||thehex->sub_type==3 ||thehex->sub_type==4)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_1_exotic, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==5 ||thehex->sub_type==6 ||thehex->sub_type==7 ||thehex->sub_type==8)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_2_exotic, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==9 ||thehex->sub_type==10 )
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_3_exotic, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
								}

						}
					}
					else if ( (planet_draw->hydro_type==DESERT) || (planet_draw->hydro_type==DUNE)   )
					{
					   if   (planet_draw->hydro_type==DESERT)
					   {
						 if ( (thehex->type == HYDRO) || (thehex->type ==  SHALOW ) ||(thehex->type ==  DEEP))
						 {

							if (thehex->sub_type==1 ||thehex->sub_type==2)
								{
									lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffSea_desert1, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
							if (thehex->sub_type==3 ||thehex->sub_type==4)
								{
									lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffSea_desert2, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
							if (thehex->sub_type==5 ||thehex->sub_type==6)
								{
									lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffSea_desert3, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
							if (thehex->sub_type==7 ||thehex->sub_type==8)
								{
									lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffSea_desert4, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
							if (thehex->sub_type==9 ||thehex->sub_type==10)
								{
									lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffSea_desert5, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}

					   }
					}
					if   (planet_draw->hydro_type==DUNE)
					   {
						 if ( (thehex->type == HYDRO) || (thehex->type ==  SHALOW ) ||(thehex->type ==  DEEP))
						 {

							if (thehex->sub_type==1 ||thehex->sub_type==2)
								{
									lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffDunes_Desert1, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
							if (thehex->sub_type==3 ||thehex->sub_type==4)
								{
									lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffDunes_Desert2, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
							if (thehex->sub_type==5 ||thehex->sub_type==6)
								{
									lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffDunes_Desert3, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
							if (thehex->sub_type==7 ||thehex->sub_type==8)
								{
									lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffDunes_Desert4, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
							if (thehex->sub_type==9 ||thehex->sub_type==10)
								{
									lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffDunes_Desert5, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}

						}
					 }
					  //desert coast line//
						if ( thehex->type == SHALOW )
						{
							coast_type = thehex->coast;

								if ( (coast_type & FLAG_EAST)!= NONE )     // note: directions E W reversed
								{
									rcRectPut_coast.left = x;
									rcRectPut_coast.top =  y+(60.0/ZooM);
									rcRectPut_coast.right =x+(40.0/ZooM);
									rcRectPut_coast.bottom =y+(120.0/ZooM);

									rcRectGet_coast.left=		0;
									rcRectGet_coast.top=		0;
									rcRectGet_coast.right = 	40;
									rcRectGet_coast.bottom = 	60;

									if (thehex->sub_type==1 ||thehex->sub_type==2 ||thehex->sub_type==3 ||thehex->sub_type==4)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_1_desert, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==5 ||thehex->sub_type==6 ||thehex->sub_type==7 ||thehex->sub_type==8)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_2_desert, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==9 ||thehex->sub_type==10 )
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_3_desert, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
								}
								if ( (coast_type & FLAG_NORTH_WEST)!= NONE )
								{
									rcRectPut_coast.left = x+(40.0/ZooM);
									rcRectPut_coast.top =  y+(60.0/ZooM);
									rcRectPut_coast.right =x+(120.0/ZooM);
									rcRectPut_coast.bottom =y+(90.0/ZooM);

									rcRectGet_coast.left=		40;
									rcRectGet_coast.top=		0;
									rcRectGet_coast.right = 	120;
									rcRectGet_coast.bottom = 	30;

									if (thehex->sub_type==1 ||thehex->sub_type==2 ||thehex->sub_type==3 ||thehex->sub_type==4)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_1_desert, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==5 ||thehex->sub_type==6 ||thehex->sub_type==7 ||thehex->sub_type==8)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_2_desert, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==9 ||thehex->sub_type==10 )
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_3_desert, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
								}
								if ( (coast_type & FLAG_SOUTH_WEST)!= NONE )
								{
									rcRectPut_coast.left = x+(40.0/ZooM);
									rcRectPut_coast.top =  y+(90.0/ZooM);
									rcRectPut_coast.right =x+(120.0/ZooM);
									rcRectPut_coast.bottom =y+(120.0/ZooM);

									rcRectGet_coast.left=		40;
									rcRectGet_coast.top=		30;
									rcRectGet_coast.right = 	120;
									rcRectGet_coast.bottom = 	60;

									if (thehex->sub_type==1 ||thehex->sub_type==2 ||thehex->sub_type==3 ||thehex->sub_type==4)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_1_desert, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==5 ||thehex->sub_type==6 ||thehex->sub_type==7 ||thehex->sub_type==8)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_2_desert, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==9 ||thehex->sub_type==10 )
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_3_desert, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
								}


								if ( (coast_type & FLAG_WEST)!= NONE )
								{
									rcRectPut_coast.left = x+(80/ZooM);
									rcRectPut_coast.top =  y+(60.0/ZooM);
									rcRectPut_coast.right =x+(120.0/ZooM);
									rcRectPut_coast.bottom =y+(120.0/ZooM);

									rcRectGet_coast.left=		80;
									rcRectGet_coast.top=		0;
									rcRectGet_coast.right = 	120;
									rcRectGet_coast.bottom = 	60;

									if (thehex->sub_type==1 ||thehex->sub_type==2 ||thehex->sub_type==3 ||thehex->sub_type==4)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_1_desert, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==5 ||thehex->sub_type==6 ||thehex->sub_type==7 ||thehex->sub_type==8)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_2_desert, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==9 ||thehex->sub_type==10 )
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_3_desert, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
								}
								if ( (coast_type & FLAG_NORTH_EAST)!= NONE )
								{
									rcRectPut_coast.left = x;
									rcRectPut_coast.top =  y+(60.0/ZooM);
									rcRectPut_coast.right =x+(80.0/ZooM);
									rcRectPut_coast.bottom =y+(90.0/ZooM);

									rcRectGet_coast.left=		0;
									rcRectGet_coast.top=		0;
									rcRectGet_coast.right = 	80;
									rcRectGet_coast.bottom = 	30;

									if (thehex->sub_type==1 ||thehex->sub_type==2 ||thehex->sub_type==3 ||thehex->sub_type==4)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_1_desert, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==5 ||thehex->sub_type==6 ||thehex->sub_type==7 ||thehex->sub_type==8)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_2_desert, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==9 ||thehex->sub_type==10 )
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_3_desert, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
								}
								if ( (coast_type & FLAG_SOUTH_EAST)!= NONE )
								{
									rcRectPut_coast.left = x;
									rcRectPut_coast.top =  y+(90.0/ZooM);
									rcRectPut_coast.right =x+(80.0/ZooM);
									rcRectPut_coast.bottom =y+(120.0/ZooM);

									rcRectGet_coast.left=		0;
									rcRectGet_coast.top=		30;
									rcRectGet_coast.right = 	80;
									rcRectGet_coast.bottom = 	60;

									if (thehex->sub_type==1 ||thehex->sub_type==2 ||thehex->sub_type==3 ||thehex->sub_type==4)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_1_desert, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==5 ||thehex->sub_type==6 ||thehex->sub_type==7 ||thehex->sub_type==8)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_2_desert, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==9 ||thehex->sub_type==10 )
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_3_desert, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
								}

						}


					}
					else
					{
                      ///////////////under test/////////
					  /////rutine to speed up map////////
                      /*
					  if (ZooM==(101.0*48.0)/screen_x)
					  {
							if (thehex->type == HYDRO )
							{


								lpDDSBack->BltFast( x, y , lpDDSOffSea, NULL,
									   DDBLTFAST_WAIT |
								       DDBLTFAST_SRCCOLORKEY );
							}

							if (thehex->type ==  SHALOW )
							{

								lpDDSBack->BltFast( x, y , lpDDSOffShalow_Sea, NULL,
									   DDBLTFAST_WAIT |
								       DDBLTFAST_SRCCOLORKEY );
							}


							if (thehex->type ==  DEEP)
							{

								lpDDSBack->BltFast( x, y , lpDDSOffDeep_Sea, NULL,
									   DDBLTFAST_WAIT |
								       DDBLTFAST_SRCCOLORKEY );
							}
						}
					   else
						*/
					   {

						if ( (thehex->type ==  SHALOW ) || (thehex->type == HYDRO ) )
						{


							switch ( animation_frame_number )
							{
								case 1:
									lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffSea1, &rcRectGet_120x60,
																	   DDBLT_WAIT |
																	   DDBLT_KEYSRC, NULL );
									break;
								case 2:
									lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffSea2, &rcRectGet_120x60,
																	   DDBLT_WAIT |
																	   DDBLT_KEYSRC, NULL );
									break;
								case 3:
									lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffSea3, &rcRectGet_120x60,
																	   DDBLT_WAIT |
																	   DDBLT_KEYSRC, NULL );
									break;
								case 4:
									lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffSea4, &rcRectGet_120x60,
																	   DDBLT_WAIT |
																	   DDBLT_KEYSRC, NULL );
									break;
								case 5:
									lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffSea5, &rcRectGet_120x60,
																	   DDBLT_WAIT |
																	   DDBLT_KEYSRC, NULL );
									break;
								case 6:
									lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffSea6, &rcRectGet_120x60,
																	   DDBLT_WAIT |
																	   DDBLT_KEYSRC, NULL );
									break;
								case 7:
									lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffSea7, &rcRectGet_120x60,
																	   DDBLT_WAIT |
																	   DDBLT_KEYSRC, NULL );
									break;
								case 8:
									lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffSea8, &rcRectGet_120x60,
																	   DDBLT_WAIT |
																	   DDBLT_KEYSRC, NULL );
									break;
								case 9:
									lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffSea9, &rcRectGet_120x60,
																	   DDBLT_WAIT |
																	   DDBLT_KEYSRC, NULL );
									break;
								default:
									lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffSea10, &rcRectGet_120x60,
																	   DDBLT_WAIT |
																	   DDBLT_KEYSRC, NULL );
							}


						}
						///ice burgs/////
						if ( (thehex->type ==  SHALOW ) && (planet_draw->land_type==WHITE) )
						{
								lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffSea_ice_1, &rcRectGet_120x60,
											   DDBLT_WAIT |
											   DDBLT_KEYSRC, NULL );
						}
						///ice burgs/////
						if ( (thehex->type ==  HYDRO ) && (planet_draw->land_type==WHITE) )
						{
								lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffSea_ice_2, &rcRectGet_120x60,
											   DDBLT_WAIT |
											   DDBLT_KEYSRC, NULL );
						}
						//deep sea
						if ( (thehex->type ==  DEEP)  )
						{
							switch ( animation_frame_number )
							{
								case 1:
									lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffSea_deep1, &rcRectGet_120x60,
																	   DDBLT_WAIT |
																	   DDBLT_KEYSRC, NULL );
									break;
								case 2:
									lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffSea_deep2, &rcRectGet_120x60,
																	   DDBLT_WAIT |
																	   DDBLT_KEYSRC, NULL );
									break;
								case 3:
									lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffSea_deep3, &rcRectGet_120x60,
																	   DDBLT_WAIT |
																	   DDBLT_KEYSRC, NULL );
									break;
								case 4:
									lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffSea_deep4, &rcRectGet_120x60,
																	   DDBLT_WAIT |
																	   DDBLT_KEYSRC, NULL );
									break;
								case 5:
									lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffSea_deep5, &rcRectGet_120x60,
																	   DDBLT_WAIT |
																	   DDBLT_KEYSRC, NULL );
									break;
								case 6:
									lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffSea_deep6, &rcRectGet_120x60,
																	   DDBLT_WAIT |
																	   DDBLT_KEYSRC, NULL );
									break;
								case 7:
									lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffSea_deep7, &rcRectGet_120x60,
																	   DDBLT_WAIT |
																	   DDBLT_KEYSRC, NULL );
									break;
								case 8:
									lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffSea_deep8, &rcRectGet_120x60,
																	   DDBLT_WAIT |
																	   DDBLT_KEYSRC, NULL );
									break;
								case 9:
									lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffSea_deep9, &rcRectGet_120x60,
																	   DDBLT_WAIT |
																	   DDBLT_KEYSRC, NULL );
									break;
								default:
									lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffSea_deep10, &rcRectGet_120x60,
																	   DDBLT_WAIT |
																	   DDBLT_KEYSRC, NULL );
							}

						}
					}				////coast line////


						if ( thehex->type == SHALOW )
						{


							coast_type = thehex->coast;

							if (planet_draw->hydro_type==WATER)
							{

								if ( (coast_type & FLAG_EAST)!= NONE )     // note: directions E W reversed
								{
									rcRectPut_coast.left = x;
									rcRectPut_coast.top =  y+(60.0/ZooM);
									rcRectPut_coast.right =x+(40.0/ZooM);
									rcRectPut_coast.bottom =y+(120.0/ZooM);

									rcRectGet_coast.left=		0;
									rcRectGet_coast.top=		0;
									rcRectGet_coast.right = 	40;
									rcRectGet_coast.bottom = 	60;

									if (thehex->sub_type==1 ||thehex->sub_type==2 ||thehex->sub_type==3 ||thehex->sub_type==4)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_1, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==5 ||thehex->sub_type==6 ||thehex->sub_type==7 ||thehex->sub_type==8)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_2, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==9 ||thehex->sub_type==10 )
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_3, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
								}
								if ( (coast_type & FLAG_NORTH_WEST)!= NONE )
								{
									rcRectPut_coast.left = x+(40.0/ZooM);
									rcRectPut_coast.top =  y+(60.0/ZooM);
									rcRectPut_coast.right =x+(120.0/ZooM);
									rcRectPut_coast.bottom =y+(90.0/ZooM);

									rcRectGet_coast.left=		40;
									rcRectGet_coast.top=		0;
									rcRectGet_coast.right = 	120;
									rcRectGet_coast.bottom = 	30;

									if (thehex->sub_type==1 ||thehex->sub_type==2 ||thehex->sub_type==3 ||thehex->sub_type==4)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_1, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==5 ||thehex->sub_type==6 ||thehex->sub_type==7 ||thehex->sub_type==8)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_2, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==9 ||thehex->sub_type==10 )
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_3, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
								}
								if ( (coast_type & FLAG_SOUTH_WEST)!= NONE )
								{
									rcRectPut_coast.left = x+(40.0/ZooM);
									rcRectPut_coast.top =  y+(90.0/ZooM);
									rcRectPut_coast.right =x+(120.0/ZooM);
									rcRectPut_coast.bottom =y+(120.0/ZooM);

									rcRectGet_coast.left=		40;
									rcRectGet_coast.top=		30;
									rcRectGet_coast.right = 	120;
									rcRectGet_coast.bottom = 	60;

									if (thehex->sub_type==1 ||thehex->sub_type==2 ||thehex->sub_type==3 ||thehex->sub_type==4)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_1, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==5 ||thehex->sub_type==6 ||thehex->sub_type==7 ||thehex->sub_type==8)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_2, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==9 ||thehex->sub_type==10 )
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_3, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
								}


								if ( (coast_type & FLAG_WEST)!= NONE )
								{
									rcRectPut_coast.left = x+(80/ZooM);
									rcRectPut_coast.top =  y+(60.0/ZooM);
									rcRectPut_coast.right =x+(120.0/ZooM);
									rcRectPut_coast.bottom =y+(120.0/ZooM);

									rcRectGet_coast.left=		80;
									rcRectGet_coast.top=		0;
									rcRectGet_coast.right = 	120;
									rcRectGet_coast.bottom = 	60;

									if (thehex->sub_type==1 ||thehex->sub_type==2 ||thehex->sub_type==3 ||thehex->sub_type==4)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_1, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==5 ||thehex->sub_type==6 ||thehex->sub_type==7 ||thehex->sub_type==8)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_2, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==9 ||thehex->sub_type==10 )
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_3, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
								}
								if ( (coast_type & FLAG_NORTH_EAST)!= NONE )
								{
									rcRectPut_coast.left = x;
									rcRectPut_coast.top =  y+(60.0/ZooM);
									rcRectPut_coast.right =x+(80.0/ZooM);
									rcRectPut_coast.bottom =y+(90.0/ZooM);

									rcRectGet_coast.left=		0;
									rcRectGet_coast.top=		0;
									rcRectGet_coast.right = 	80;
									rcRectGet_coast.bottom = 	30;

									if (thehex->sub_type==1 ||thehex->sub_type==2 ||thehex->sub_type==3 ||thehex->sub_type==4)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_1, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==5 ||thehex->sub_type==6 ||thehex->sub_type==7 ||thehex->sub_type==8)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_2, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==9 ||thehex->sub_type==10 )
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_3, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
								}
								if ( (coast_type & FLAG_SOUTH_EAST)!= NONE )
								{
									rcRectPut_coast.left = x;
									rcRectPut_coast.top =  y+(90.0/ZooM);
									rcRectPut_coast.right =x+(80.0/ZooM);
									rcRectPut_coast.bottom =y+(120.0/ZooM);

									rcRectGet_coast.left=		0;
									rcRectGet_coast.top=		30;
									rcRectGet_coast.right = 	80;
									rcRectGet_coast.bottom = 	60;

									if (thehex->sub_type==1 ||thehex->sub_type==2 ||thehex->sub_type==3 ||thehex->sub_type==4)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_1, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==5 ||thehex->sub_type==6 ||thehex->sub_type==7 ||thehex->sub_type==8)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_2, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==9 ||thehex->sub_type==10 )
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_3, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
								}

							}
							if (planet_draw->hydro_type==ICE)
							{

								if ( (coast_type & FLAG_EAST)!= NONE )     // note: directions E W reversed
								{
									rcRectPut_coast.left = x;
									rcRectPut_coast.top =  y+(60.0/ZooM);
									rcRectPut_coast.right =x+(40.0/ZooM);
									rcRectPut_coast.bottom =y+(120.0/ZooM);

									rcRectGet_coast.left=		0;
									rcRectGet_coast.top=		0;
									rcRectGet_coast.right = 	40;
									rcRectGet_coast.bottom = 	60;

									if (thehex->sub_type==1 ||thehex->sub_type==2 ||thehex->sub_type==3 ||thehex->sub_type==4)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_1_ice, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==5 ||thehex->sub_type==6 ||thehex->sub_type==7 ||thehex->sub_type==8)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_2_ice, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==9 ||thehex->sub_type==10 )
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_3_ice, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
								}
								if ( (coast_type & FLAG_NORTH_WEST)!= NONE )
								{
									rcRectPut_coast.left = x+(40.0/ZooM);
									rcRectPut_coast.top =  y+(60.0/ZooM);
									rcRectPut_coast.right =x+(120.0/ZooM);
									rcRectPut_coast.bottom =y+(90.0/ZooM);

									rcRectGet_coast.left=		40;
									rcRectGet_coast.top=		0;
									rcRectGet_coast.right = 	120;
									rcRectGet_coast.bottom = 	30;

									if (thehex->sub_type==1 ||thehex->sub_type==2 ||thehex->sub_type==3 ||thehex->sub_type==4)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_1_ice, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==5 ||thehex->sub_type==6 ||thehex->sub_type==7 ||thehex->sub_type==8)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_2_ice, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==9 ||thehex->sub_type==10 )
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_3_ice, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
								}
								if ( (coast_type & FLAG_SOUTH_WEST)!= NONE )
								{
									rcRectPut_coast.left = x+(40.0/ZooM);
									rcRectPut_coast.top =  y+(90.0/ZooM);
									rcRectPut_coast.right =x+(120.0/ZooM);
									rcRectPut_coast.bottom =y+(120.0/ZooM);

									rcRectGet_coast.left=		40;
									rcRectGet_coast.top=		30;
									rcRectGet_coast.right = 	120;
									rcRectGet_coast.bottom = 	60;

									if (thehex->sub_type==1 ||thehex->sub_type==2 ||thehex->sub_type==3 ||thehex->sub_type==4)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_1_ice, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==5 ||thehex->sub_type==6 ||thehex->sub_type==7 ||thehex->sub_type==8)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_2_ice, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==9 ||thehex->sub_type==10 )
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_b_3_ice, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
								}


								if ( (coast_type & FLAG_WEST)!= NONE )
								{
									rcRectPut_coast.left = x+(80/ZooM);
									rcRectPut_coast.top =  y+(60.0/ZooM);
									rcRectPut_coast.right =x+(120.0/ZooM);
									rcRectPut_coast.bottom =y+(120.0/ZooM);

									rcRectGet_coast.left=		80;
									rcRectGet_coast.top=		0;
									rcRectGet_coast.right = 	120;
									rcRectGet_coast.bottom = 	60;

									if (thehex->sub_type==1 ||thehex->sub_type==2 ||thehex->sub_type==3 ||thehex->sub_type==4)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_1_ice, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==5 ||thehex->sub_type==6 ||thehex->sub_type==7 ||thehex->sub_type==8)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_2_ice, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==9 ||thehex->sub_type==10 )
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_3_ice, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
								}
								if ( (coast_type & FLAG_NORTH_EAST)!= NONE )
								{
									rcRectPut_coast.left = x;
									rcRectPut_coast.top =  y+(60.0/ZooM);
									rcRectPut_coast.right =x+(80.0/ZooM);
									rcRectPut_coast.bottom =y+(90.0/ZooM);

									rcRectGet_coast.left=		0;
									rcRectGet_coast.top=		0;
									rcRectGet_coast.right = 	80;
									rcRectGet_coast.bottom = 	30;

									if (thehex->sub_type==1 ||thehex->sub_type==2 ||thehex->sub_type==3 ||thehex->sub_type==4)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_1_ice, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==5 ||thehex->sub_type==6 ||thehex->sub_type==7 ||thehex->sub_type==8)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_2_ice, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==9 ||thehex->sub_type==10 )
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_3_ice, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
								}
								if ( (coast_type & FLAG_SOUTH_EAST)!= NONE )
								{
									rcRectPut_coast.left = x;
									rcRectPut_coast.top =  y+(90.0/ZooM);
									rcRectPut_coast.right =x+(80.0/ZooM);
									rcRectPut_coast.bottom =y+(120.0/ZooM);

									rcRectGet_coast.left=		0;
									rcRectGet_coast.top=		30;
									rcRectGet_coast.right = 	80;
									rcRectGet_coast.bottom = 	60;

									if (thehex->sub_type==1 ||thehex->sub_type==2 ||thehex->sub_type==3 ||thehex->sub_type==4)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_1_ice, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==5 ||thehex->sub_type==6 ||thehex->sub_type==7 ||thehex->sub_type==8)
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_2_ice, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==9 ||thehex->sub_type==10 )
									{
										lpDDSBack->Blt ( &rcRectPut_coast, lpDDSOffCoast_a_3_ice, &rcRectGet_coast,
																				   DDBLT_WAIT |
																				   DDBLT_KEYSRC, NULL );
									}
								}

							}

						}

						//////////////////
					}

			////////////////////////hills/////////////////////
            //////////////////###################/////////////
			/////////////////////////////////////////////////

			if (thehex->type==HILL)
			{
										// hill
						if (planet_draw->land_type==PLAIN)
						{
								if (thehex->sub_type==1 ||thehex->sub_type==2)
								{
									lpDDSBack->Blt ( &rcRect_120x80 , lpDDSOffHill1, &rcRectGet_120x80,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
								if (thehex->sub_type==3 ||thehex->sub_type==4)
								{
									lpDDSBack->Blt ( &rcRect_120x80 , lpDDSOffHill2, &rcRectGet_120x80,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
								if (thehex->sub_type==5 ||thehex->sub_type==6)
								{
									lpDDSBack->Blt ( &rcRect_120x80 , lpDDSOffHill3, &rcRectGet_120x80,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
								if (thehex->sub_type==7 ||thehex->sub_type==8)
								{
									lpDDSBack->Blt ( &rcRect_120x80 , lpDDSOffHill4, &rcRectGet_120x80,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
								if (thehex->sub_type==9 ||thehex->sub_type==10)
								{
									lpDDSBack->Blt ( &rcRect_120x80 , lpDDSOffHill5, &rcRectGet_120x80,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
						}
						if (planet_draw->land_type==SWAMP)
						{
								if (thehex->sub_type==1 ||thehex->sub_type==2)
								{
									lpDDSBack->Blt ( &rcRect_120x80 , lpDDSOffHill1, &rcRectGet_120x80,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
								if (thehex->sub_type==3 ||thehex->sub_type==4)
								{
									lpDDSBack->Blt ( &rcRect_120x80 , lpDDSOffHill2, &rcRectGet_120x80,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
								if (thehex->sub_type==5 ||thehex->sub_type==6)
								{
									lpDDSBack->Blt ( &rcRect_120x80 , lpDDSOffHill3, &rcRectGet_120x80,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
								if (thehex->sub_type==7 ||thehex->sub_type==8)
								{
									lpDDSBack->Blt ( &rcRect_120x80 , lpDDSOffHill4, &rcRectGet_120x80,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
								if (thehex->sub_type==9 ||thehex->sub_type==10)
								{
									lpDDSBack->Blt ( &rcRect_120x80 , lpDDSOffHill5, &rcRectGet_120x80,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
						}
						if (planet_draw->land_type==JUNGLE)
						{
								if (thehex->sub_type==1 ||thehex->sub_type==2)
								{
									lpDDSBack->Blt ( &rcRect_120x80 , lpDDSOffHill1, &rcRectGet_120x80,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
								if (thehex->sub_type==3 ||thehex->sub_type==4)
								{
									lpDDSBack->Blt ( &rcRect_120x80 , lpDDSOffHill2, &rcRectGet_120x80,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
								if (thehex->sub_type==5 ||thehex->sub_type==6)
								{
									lpDDSBack->Blt ( &rcRect_120x80 , lpDDSOffHill3, &rcRectGet_120x80,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
								if (thehex->sub_type==7 ||thehex->sub_type==8)
								{
									lpDDSBack->Blt ( &rcRect_120x80 , lpDDSOffHill4, &rcRectGet_120x80,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
								if (thehex->sub_type==9 ||thehex->sub_type==10)
								{
									lpDDSBack->Blt ( &rcRect_120x80 , lpDDSOffHill5, &rcRectGet_120x80,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
						}
						if (planet_draw->land_type==GREY)
						{
								lpDDSBack->Blt( &rcRect_120x120 , lpDDSOffHill_Moon, &rcRectGet_120x120,
											   DDBLT_WAIT |
											   DDBLT_KEYSRC, NULL );
						}
						if (planet_draw->land_type==EXOTIC)
						{
								lpDDSBack->Blt( &rcRect_120x120 , lpDDSOffHill_Exotic, &rcRectGet_120x120,
											   DDBLT_WAIT |
											   DDBLT_KEYSRC, NULL );
						}
						if (planet_draw->land_type==BROWN)
						{
							if (planet_draw->planet_type != OASIS)
							{

								if (thehex->sub_type==1 ||thehex->sub_type==2)
								{
									lpDDSBack->Blt( &rcRect_120x120 , lpDDSOffHill_Desert1, &rcRectGet_120x120,
											   DDBLT_WAIT |
											   DDBLT_KEYSRC, NULL );
								}
								if (thehex->sub_type==3 ||thehex->sub_type==4)
								{
									lpDDSBack->Blt( &rcRect_120x120 , lpDDSOffHill_Desert2, &rcRectGet_120x120,
											   DDBLT_WAIT |
											   DDBLT_KEYSRC, NULL );
								}
								if (thehex->sub_type==5 ||thehex->sub_type==6)
								{
									lpDDSBack->Blt( &rcRect_120x120 , lpDDSOffHill_Desert3, &rcRectGet_120x120,
											   DDBLT_WAIT |
											   DDBLT_KEYSRC, NULL );
								}
								if (thehex->sub_type==7 ||thehex->sub_type==8)
								{
									lpDDSBack->Blt( &rcRect_120x120 , lpDDSOffHill_Desert4, &rcRectGet_120x120,
											   DDBLT_WAIT |
											   DDBLT_KEYSRC, NULL );
								}
								if (thehex->sub_type==9 ||thehex->sub_type==10)
								{
									lpDDSBack->Blt( &rcRect_120x120 , lpDDSOffHill_Desert5, &rcRectGet_120x120,
											   DDBLT_WAIT |
											   DDBLT_KEYSRC, NULL );
								}
							}
							else
							{    //reset from scroll adjust


								 if (thehex->sub_type==1 ||thehex->sub_type==2)
								{
									lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffDunes_Desert1, &rcRectGet_120x60,
											   DDBLT_WAIT |
											   DDBLT_KEYSRC, NULL );
								}
								if (thehex->sub_type==3 ||thehex->sub_type==4)
								{
									lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffDunes_Desert2, &rcRectGet_120x60,
											   DDBLT_WAIT |
											   DDBLT_KEYSRC, NULL );
								}
								if (thehex->sub_type==5 ||thehex->sub_type==6)
								{
									lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffDunes_Desert3, &rcRectGet_120x60,
											   DDBLT_WAIT |
											   DDBLT_KEYSRC, NULL );
								}
								if (thehex->sub_type==7 ||thehex->sub_type==8)
								{
									lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffDunes_Desert4, &rcRectGet_120x60,
											   DDBLT_WAIT |
											   DDBLT_KEYSRC, NULL );
								}
								if (thehex->sub_type==9 ||thehex->sub_type==10)
								{
									lpDDSBack->Blt( &rcRect_120x60 , lpDDSOffDunes_Desert5, &rcRectGet_120x60,
											   DDBLT_WAIT |
											   DDBLT_KEYSRC, NULL );
								}


                            }
						}
						if (planet_draw->land_type==WHITE)
						{
								if (thehex->sub_type==1 ||thehex->sub_type==2)
								{
									lpDDSBack->Blt ( &rcRect_120x120 , lpDDSOffHill_Ice1, &rcRectGet_120x120,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
								if (thehex->sub_type==3 ||thehex->sub_type==4)
								{
									lpDDSBack->Blt ( &rcRect_120x120 , lpDDSOffHill_Ice2, &rcRectGet_120x120,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
								if (thehex->sub_type==5 ||thehex->sub_type==6)
								{
									lpDDSBack->Blt ( &rcRect_120x120 , lpDDSOffHill_Ice3, &rcRectGet_120x120,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
								if (thehex->sub_type==7 ||thehex->sub_type==8)
								{
									lpDDSBack->Blt ( &rcRect_120x120 , lpDDSOffHill_Ice4, &rcRectGet_120x120,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
								if (thehex->sub_type==9 ||thehex->sub_type==10)
								{
									lpDDSBack->Blt ( &rcRect_120x120 , lpDDSOffHill_Ice5, &rcRectGet_120x120,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
						}
						/* done, no?
						if (planet_draw->land_type==JUNGLE)
						{
								if (thehex->sub_type==1 ||thehex->sub_type==2)
								{
									lpDDSBack->Blt ( &rcRect_120x120 , lpDDSOffHill1, &rcRectGet_120x120,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
								if (thehex->sub_type==3 ||thehex->sub_type==4)
								{
									lpDDSBack->Blt ( &rcRect_120x120 , lpDDSOffHill2, &rcRectGet_120x120,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
								if (thehex->sub_type==5 ||thehex->sub_type==6)
								{
									lpDDSBack->Blt ( &rcRect_120x120 , lpDDSOffHill3, &rcRectGet_120x120,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
								if (thehex->sub_type==7 ||thehex->sub_type==8)
								{
									lpDDSBack->Blt ( &rcRect_120x120 , lpDDSOffHill4, &rcRectGet_120x120,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
								if (thehex->sub_type==9 ||thehex->sub_type==10)
								{
									lpDDSBack->Blt ( &rcRect_120x120 , lpDDSOffHill5, &rcRectGet_120x120,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
						}
						*/
						if (planet_draw->land_type==DARK)
						{
								lpDDSBack->Blt( &rcRect_120x120 , lpDDSOffHill_Lava, &rcRectGet_120x120,
											   DDBLT_WAIT |
											   DDBLT_KEYSRC, NULL );
						}
			}

			if (thehex->type==MOUNT)             	// mount
			{
						if (planet_draw->land_type==PLAIN)
						{
							 if (thehex->sub_type==1 ||thehex->sub_type==2)
								{
									lpDDSBack->Blt ( &rcRect_120x120 , lpDDSOffMount1, &rcRectGet_120x120,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
							 if (thehex->sub_type==3 ||thehex->sub_type==4)
								{
									lpDDSBack->Blt ( &rcRect_120x120 , lpDDSOffMount2, &rcRectGet_120x120,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
							 if (thehex->sub_type==5 ||thehex->sub_type==6)
								{
									lpDDSBack->Blt ( &rcRect_120x120 , lpDDSOffMount3, &rcRectGet_120x120,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
							 if (thehex->sub_type==7 ||thehex->sub_type==8)
								{
									lpDDSBack->Blt ( &rcRect_120x120 , lpDDSOffMount4, &rcRectGet_120x120,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
							 if (thehex->sub_type==9 ||thehex->sub_type==10)
								{
									lpDDSBack->Blt ( &rcRect_120x120 , lpDDSOffMount5, &rcRectGet_120x120,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
						}
						if (planet_draw->land_type==SWAMP)
						{
								if (thehex->sub_type==1 ||thehex->sub_type==2)
								{
									lpDDSBack->Blt ( &rcRect_120x120 , lpDDSOffMount1, &rcRectGet_120x120,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
							 if (thehex->sub_type==3 ||thehex->sub_type==4)
								{
									lpDDSBack->Blt ( &rcRect_120x120 , lpDDSOffMount2, &rcRectGet_120x120,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
							 if (thehex->sub_type==5 ||thehex->sub_type==6)
								{
									lpDDSBack->Blt ( &rcRect_120x120 , lpDDSOffMount3, &rcRectGet_120x120,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
							 if (thehex->sub_type==7 ||thehex->sub_type==8)
								{
									lpDDSBack->Blt ( &rcRect_120x120 , lpDDSOffMount4, &rcRectGet_120x120,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
							 if (thehex->sub_type==9 ||thehex->sub_type==10)
								{
									lpDDSBack->Blt ( &rcRect_120x120 , lpDDSOffMount5, &rcRectGet_120x120,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
						}
						if (planet_draw->land_type==JUNGLE)
						{
								if (thehex->sub_type==1 ||thehex->sub_type==2)
								{
									lpDDSBack->Blt ( &rcRect_120x120 , lpDDSOffMount1, &rcRectGet_120x120,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
							 if (thehex->sub_type==3 ||thehex->sub_type==4)
								{
									lpDDSBack->Blt ( &rcRect_120x120 , lpDDSOffMount2, &rcRectGet_120x120,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
							 if (thehex->sub_type==5 ||thehex->sub_type==6)
								{
									lpDDSBack->Blt ( &rcRect_120x120 , lpDDSOffMount3, &rcRectGet_120x120,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
							 if (thehex->sub_type==7 ||thehex->sub_type==8)
								{
									lpDDSBack->Blt ( &rcRect_120x120 , lpDDSOffMount4, &rcRectGet_120x120,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
							 if (thehex->sub_type==9 ||thehex->sub_type==10)
								{
									lpDDSBack->Blt ( &rcRect_120x120 , lpDDSOffMount5, &rcRectGet_120x120,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
								}
						}
						if (planet_draw->land_type==GREY)
						{
								lpDDSBack->Blt( &rcRect_120x120 , lpDDSOffMount_Moon, &rcRectGet_120x120,
											   DDBLT_WAIT |
											   DDBLT_KEYSRC, NULL );
						}
						if (planet_draw->land_type==EXOTIC)
						{
								lpDDSBack->Blt( &rcRect_120x120 , lpDDSOffMount_Exotic, &rcRectGet_120x120,
											   DDBLT_WAIT |
											   DDBLT_KEYSRC, NULL );
						}
						if (planet_draw->land_type==BROWN)
						{
							if (thehex->sub_type==1 ||thehex->sub_type==2)
								{
									lpDDSBack->Blt( &rcRect_120x120 , lpDDSOffMount_Desert1, &rcRectGet_120x120,
											   DDBLT_WAIT |
											   DDBLT_KEYSRC, NULL );
								}
							 if (thehex->sub_type==3 ||thehex->sub_type==4)
								{
									lpDDSBack->Blt( &rcRect_120x120 , lpDDSOffMount_Desert2, &rcRectGet_120x120,
											   DDBLT_WAIT |
											   DDBLT_KEYSRC, NULL );
								}
							 if (thehex->sub_type==5 ||thehex->sub_type==6)
								{
									lpDDSBack->Blt( &rcRect_120x120 , lpDDSOffMount_Desert3, &rcRectGet_120x120,
											   DDBLT_WAIT |
											   DDBLT_KEYSRC, NULL );
								}
							 if (thehex->sub_type==7 ||thehex->sub_type==8)
								{
									lpDDSBack->Blt( &rcRect_120x120 , lpDDSOffMount_Desert4, &rcRectGet_120x120,
											   DDBLT_WAIT |
											   DDBLT_KEYSRC, NULL );
								}
							 if (thehex->sub_type==9 ||thehex->sub_type==10)
								{
									lpDDSBack->Blt( &rcRect_120x120 , lpDDSOffMount_Desert5, &rcRectGet_120x120,
											   DDBLT_WAIT |
											   DDBLT_KEYSRC, NULL );
								}
						}
						if (planet_draw->land_type==WHITE)
						{
								lpDDSBack->Blt( &rcRect_120x120 , lpDDSOffMount_Ice, &rcRectGet_120x120,
											   DDBLT_WAIT |
											   DDBLT_KEYSRC, NULL );
						}
						if (planet_draw->land_type==DARK)
						{
								lpDDSBack->Blt( &rcRect_120x120 , lpDDSOffMount_Lava, &rcRectGet_120x120,
											   DDBLT_WAIT |
											   DDBLT_KEYSRC, NULL );
						}
			}


			//////////////roads & rivers///////////
			///////////////rivers//////////////
			river_type = thehex->flag;

			if (planet_draw->hydro_type==LAVA)
			{
				if ( (river_type & FLAG_EAST)!= NONE )
				{
					lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRiver_E_lava, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );

				}

				if ( (river_type & FLAG_WEST)!= NONE )
				{
					lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRiver_W_lava, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );

				}

				if ( (river_type & FLAG_NORTH_EAST)!= NONE )
				{
					lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRiver_NE_lava, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );

				}

				if ( (river_type & FLAG_NORTH_WEST)!= NONE )
				{
					lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRiver_NW_lava, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );

				}

				if ( (river_type & FLAG_SOUTH_EAST)!= NONE )
				{
					lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRiver_SE_lava, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );

				}

				if ( (river_type & FLAG_SOUTH_WEST)!= NONE )
				{
					lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRiver_SW_lava, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );

				}
			}
			else if (planet_draw->hydro_type==ACID)
			{
				if ( (river_type & FLAG_EAST)!= NONE )
				{
					lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRiver_E_exotic, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );

				}

				if ( (river_type & FLAG_WEST)!= NONE )
				{
					lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRiver_W_exotic, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );

				}

				if ( (river_type & FLAG_NORTH_EAST)!= NONE )
				{
					lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRiver_NE_exotic, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );

				}

				if ( (river_type & FLAG_NORTH_WEST)!= NONE )
				{
					lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRiver_NW_exotic, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );

				}

				if ( (river_type & FLAG_SOUTH_EAST)!= NONE )
				{
					lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRiver_SE_exotic, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );

				}

				if ( (river_type & FLAG_SOUTH_WEST)!= NONE )
				{
					lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRiver_SW_exotic, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );

				}
			}
			else if (planet_draw->hydro_type==DESERT)
			{
                if ( (river_type & FLAG_EAST)!= NONE )
				{
					lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRiver_E_desert, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );

				}

				if ( (river_type & FLAG_WEST)!= NONE )
				{
					lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRiver_W_desert, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );

				}

				if ( (river_type & FLAG_NORTH_EAST)!= NONE )
				{
					lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRiver_NE_desert, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );

				}

				if ( (river_type & FLAG_NORTH_WEST)!= NONE )
				{
					lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRiver_NW_desert, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );

				}

				if ( (river_type & FLAG_SOUTH_EAST)!= NONE )
				{
					lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRiver_SE_desert, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );

				}

				if ( (river_type & FLAG_SOUTH_WEST)!= NONE )
				{
					lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRiver_SW_desert, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );

				}
			}
			else if (planet_draw->land_type==SWAMP)
			{
				if ( (river_type & FLAG_EAST)!= NONE )
				{
					lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRiver_E_swamp, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );

				}

				if ( (river_type & FLAG_WEST)!= NONE )
				{
					lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRiver_W_swamp, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );

				}

				if ( (river_type & FLAG_NORTH_EAST)!= NONE )
				{
					lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRiver_NE_swamp, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );

				}

				if ( (river_type & FLAG_NORTH_WEST)!= NONE )
				{
					lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRiver_NW_swamp, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );

				}

				if ( (river_type & FLAG_SOUTH_EAST)!= NONE )
				{
					lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRiver_SE_swamp, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );

				}

				if ( (river_type & FLAG_SOUTH_WEST)!= NONE )
				{
					lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRiver_SW_swamp, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );

				}
			}
			else
			{
				if ( (river_type & FLAG_EAST)!= NONE )
				{
					lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRiver_E, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );

				}

				if ( (river_type & FLAG_WEST)!= NONE )
				{
					lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRiver_W, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );

				}

				if ( (river_type & FLAG_NORTH_EAST)!= NONE )
				{
					lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRiver_NE, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );

				}

				if ( (river_type & FLAG_NORTH_WEST)!= NONE )
				{
					lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRiver_NW, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );

				}

				if ( (river_type & FLAG_SOUTH_EAST)!= NONE )
				{
					lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRiver_SE, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );

				}

				if ( (river_type & FLAG_SOUTH_WEST)!= NONE )
				{
					lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRiver_SW, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );

				}
			}

			//////////////roads///////////
			road_type = thehex->road;
			if ( road_type!=NONE )
			{
                if ( (road_type & FLAG_EAST)!= NONE )
				{
					lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRoad_E, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );

				}

				if (  ((road_type & FLAG_WEST)!= NONE)
				  &&  ((road_type & FLAG_NORTH_EAST)!= NONE)
				  &&   (road_type==FLAG_WEST+FLAG_NORTH_EAST)
				  &&   (thehex->build_in_hex==(LPbuilding) NULL)    )
				{
					lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRoad_W_NE , &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );

				}

				else if (  (road_type & FLAG_WEST)!= NONE  )
				{
					lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRoad_W , &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );

					if ( (road_type & FLAG_NORTH_EAST)!= NONE )
					{
						lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRoad_NE, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
					}
				}
				else if ( (road_type & FLAG_NORTH_EAST)!= NONE )
				{
					lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRoad_NE, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );

					if ( (road_type & FLAG_WEST)!= NONE )
					{
						lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRoad_W, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
					}
				}

				if (  ((road_type & FLAG_NORTH_WEST)!= NONE)
				  &&  ((road_type & FLAG_SOUTH_WEST)!= NONE)
				  &&   (road_type==FLAG_SOUTH_WEST+FLAG_NORTH_WEST)
				  &&   (thehex->build_in_hex==(LPbuilding) NULL)    )
				{
					lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRoad_NW_SW , &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );

				}

				else if (  (road_type & FLAG_NORTH_WEST)!= NONE  )
				{
					lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRoad_NW , &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );

					if ( (road_type & FLAG_SOUTH_WEST)!= NONE )
					{
						lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRoad_SW, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
					}
				}
				else if ( (road_type & FLAG_SOUTH_WEST)!= NONE )
				{
					lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRoad_SW, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );

					if ( (road_type & FLAG_NORTH_WEST)!= NONE )
					{
						lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRoad_NW, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
					}
				}

				if ( (road_type & FLAG_SOUTH_EAST)!= NONE )
				{
					lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRoad_SE, &rcRectGet_120x60,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );

				}


			}

			//////////forests/plants///////////


			if ( 	  (thehex->type==PLANT_PLAIN)
				 ||   (thehex->type==PLANT_HILL)
				 ||   ((thehex->type == PLANT_SWAMP)&&(planet_draw->planet_type != OASIS))   )
			{
										// trees
					if (thehex->sub_type==1 ||thehex->sub_type==2)
									{

										lpDDSBack->Blt( &rcRect_120x120 , lpDDSOffTrees_a_1, &rcRectGet_120x120,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
									}
						if (thehex->sub_type==3 ||thehex->sub_type==4)
									{

										lpDDSBack->Blt( &rcRect_120x120 , lpDDSOffTrees_a_2, &rcRectGet_120x120,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
									}
						if (thehex->sub_type==5 ||thehex->sub_type==6)
									{

										 lpDDSBack->Blt( &rcRect_120x120 , lpDDSOffTrees_a_3, &rcRectGet_120x120,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
									}
						if (thehex->sub_type==7 ||thehex->sub_type==8)
									{

										lpDDSBack->Blt( &rcRect_120x120 , lpDDSOffTrees_a_4, &rcRectGet_120x120,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
									}
						if (thehex->sub_type==9 ||thehex->sub_type==10)
									{
										lpDDSBack->Blt( &rcRect_120x120 , lpDDSOffTrees_a_5, &rcRectGet_120x120,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
									}
			}

			if ( thehex->type == PLANT_SWAMP && (planet_draw->planet_type == OASIS) )
			{
						if (thehex->sub_type==1 ||thehex->sub_type==2)
									{

										lpDDSBack->Blt( &rcRect_120x120 , lpDDSOffDesert_Trees1, &rcRectGet_120x120,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
									}
						if (thehex->sub_type==3 ||thehex->sub_type==4)
									{

										lpDDSBack->Blt( &rcRect_120x120 , lpDDSOffDesert_Trees2, &rcRectGet_120x120,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
									}
						if (thehex->sub_type==5 ||thehex->sub_type==6)
									{

										 lpDDSBack->Blt( &rcRect_120x120 , lpDDSOffDesert_Trees3, &rcRectGet_120x120,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
									}
						if (thehex->sub_type==7 ||thehex->sub_type==8)
									{

										lpDDSBack->Blt( &rcRect_120x120 , lpDDSOffDesert_Trees4, &rcRectGet_120x120,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
									}
						if (thehex->sub_type==9 ||thehex->sub_type==10)
									{
										lpDDSBack->Blt( &rcRect_120x120 , lpDDSOffDesert_Trees5, &rcRectGet_120x120,
										   DDBLT_WAIT |
										   DDBLT_KEYSRC, NULL );
									}

			}

			//////////////resourses////////////
				if (thehex->build_in_hex==(LPbuilding) NULL) // only show if no building
						{

							if (thehex->resourse==METAL)             	// metal
							{
									lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRes_metal, &rcRectGet_120x60,
														   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );
							}
							if (thehex->resourse==OIL)             	// metal
							{
									lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRes_oil, &rcRectGet_120x60,
														   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );
							}
							if (thehex->resourse==TRACE)             	// metal
							{
									lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRes_trace, &rcRectGet_120x60,
														   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );
							}
							if (thehex->resourse==RADIOACTIVE)             	// metal
							{
									lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRes_radioactive, &rcRectGet_120x60,
                										   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );
                			}
							if (thehex->resourse==GEM)             	// metal
                			{
									lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRes_gem, &rcRectGet_120x60,
                										   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );
                			}
							if (thehex->resourse==SPICE)             	// metal
                			{
									lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRes_spice, &rcRectGet_120x60,
                										   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );
							}
							if (thehex->resourse==CHEMY)             	//chemy
                			{
									lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRes_chemy, &rcRectGet_120x60,
                										   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );
							}
							if (thehex->resourse==HYPER_STEEL)             	// super metal
							{
									lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRes_hyper_steel, &rcRectGet_120x60,
														   DDBLT_WAIT |
                										   DDBLT_KEYSRC, NULL );
							}
							if (thehex->resourse==GOLD)             	// super metal
							{
									lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffRes_gold, &rcRectGet_120x60,
														   DDBLT_WAIT |
                										   DDBLT_KEYSRC, NULL );
							}
			}
			///////////////smalle structures////////////
			if (thehex->build_in_hex!=(LPbuilding) NULL)
			{


					if (thehex->build_in_hex->type==CHEMY)             	// town
							{
									lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffStruct_chemy, &rcRectGet_120x60,
														   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );
							}
					 if (thehex->build_in_hex->type==ELEC)             	// town
							{
									lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffStruct_elec, &rcRectGet_120x60,
														   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );
							}
					 if (thehex->build_in_hex->type==RUINS)             	// town
							{
									lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffStruct_ruins, &rcRectGet_120x60,
														   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );
							}
					 if (thehex->build_in_hex->type==WELL)             	// town
							{

									lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffStruct_well, &rcRectGet_120x60,
														   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );
								 if (thehex->build_in_hex->worker!=(LPLABOUR)NULL)
								 {
									rcRect_get_object.left=0+((animation_frame_number-1)*30);
									rcRect_get_object.right=30+((animation_frame_number-1)*30);
									rcRect_get_object.top=20;
									rcRect_get_object.bottom=40;

									rcRect_put_object.left= x+55/ZooM;
									rcRect_put_object.right= x+(55+30)/ZooM;
									rcRect_put_object.top= y+47/ZooM;
									rcRect_put_object.bottom= y+(47+20)/ZooM;

									lpDDSBack->Blt ( &rcRect_put_object , lpDDSOffJump3, &rcRect_get_object,
														   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );
								 }
							}
					 if (thehex->build_in_hex->type==OFFSHORE_WELL)             	// town
							{
									lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffStruct_offshore_well, &rcRectGet_120x60,
														   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );
								if (thehex->build_in_hex->worker!=(LPLABOUR)NULL)
								{
									rcRect_get_object.left=0+((animation_frame_number-1)*30);
									rcRect_get_object.right=30+((animation_frame_number-1)*30);
									rcRect_get_object.top=20;
									rcRect_get_object.bottom=40;

									rcRect_put_object.left= x+48/ZooM;
									rcRect_put_object.right= x+(48+30)/ZooM;
									rcRect_put_object.top= y+45/ZooM;
									rcRect_put_object.bottom= y+(45+20)/ZooM;

									lpDDSBack->Blt ( &rcRect_put_object , lpDDSOffJump3, &rcRect_get_object,
														   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );
								}
							}
					 /////mines/////
					 if (thehex->build_in_hex->type==MINE)             	// town
							{
									lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffStruct_mine, &rcRectGet_120x60,
														   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );
							}
					 else if (thehex->build_in_hex->type==MINE_TRACE)             	// town
							{
									lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffStruct_mine, &rcRectGet_120x60,
														   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );
							}
					 else if (thehex->build_in_hex->type==MINE_GEMS)             	// town
							{
									lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffStruct_mine, &rcRectGet_120x60,
														   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );
							}
					 else if (thehex->build_in_hex->type==MINE_RADIOACTIVE)             	// town
							{
									lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffStruct_mine, &rcRectGet_120x60,
														   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );
							}
					 else if (thehex->build_in_hex->type==MINE_HYPER_STEEL)             	// town
							{
									lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffStruct_mine, &rcRectGet_120x60,
														   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );
							}
					 else if (thehex->build_in_hex->type==MINE_CHEMY)             	// town
							{
									lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffStruct_mine, &rcRectGet_120x60,
														   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );
							}
					 //////
					 if (thehex->build_in_hex->type==FACTORY)             	// town
							{


									lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffStruct_factory, &rcRectGet_120x60,
														   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );
								 if (thehex->build_in_hex->worker!=(LPLABOUR)NULL)
								 {
									rcRect_get_object.left=0+((animation_frame_number-1)*30);
									rcRect_get_object.right=30+((animation_frame_number-1)*30);
									rcRect_get_object.top=0;
									rcRect_get_object.bottom=20;

									rcRect_put_object.left= x+72/ZooM;
									rcRect_put_object.right= x+102/ZooM;
									rcRect_put_object.top= y+40/ZooM;
									rcRect_put_object.bottom= y+60/ZooM;

									lpDDSBack->Blt ( &rcRect_put_object , lpDDSOffJump3, &rcRect_get_object,
														   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );
								 }
							}
					 if (thehex->build_in_hex->type==FARM)             	// town
							{
									lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffStruct_farm, &rcRectGet_120x60,
														   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );
							}
					 if (thehex->build_in_hex->type==STARPORT)             	// town
							{
									lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffStruct_starport, &rcRectGet_120x60,
														   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );
							}
					 if (thehex->build_in_hex->type==FORT)             	// town
							{
									lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffStruct_fort, &rcRectGet_120x60,
														   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );
							}
					 if (thehex->build_in_hex->type==BARRACKS)             	// town
							{
									lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffStruct_barracks, &rcRectGet_120x60,
														   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );
							}
					 if (thehex->build_in_hex->type==LAB)             	// town
							{
									lpDDSBack->Blt ( &rcRect_120x60 , lpDDSOffStruct_lab, &rcRectGet_120x60,
														   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );
							}
					 ///////////check if Leftclick on building///////////////
					 /*
					 if ( LMouse_Hex_Click==true && LMouse_Hex_Click_X == nx &&  LMouse_Hex_Click_Y == ny)

								{
									int number_of_workers=0;
									int workers_type=1;
									for ( LPLABOUR workers=thehex->build_in_hex->worker; workers != (LPLABOUR)NULL; workers=workers->next )
									{
										number_of_workers++;

										RECT rcRect_get_icon;
										RECT rcRect_put_icon;
										int icon_type=(workers->type)-100;
										rcRect_get_icon.left=0+((icon_type-1)*30);
										rcRect_get_icon.right=30+((icon_type-1)*30);
										rcRect_get_icon.top=0;
										rcRect_get_icon.bottom=30;

										rcRect_put_icon.left= x+(0+(number_of_workers*30))/ZooM;
										rcRect_put_icon.right= x+(30+(number_of_workers*30))/ZooM;
										rcRect_put_icon.top= y+40/ZooM;
										rcRect_put_icon.bottom= y+70/ZooM;

										lpDDSBack->Blt ( &rcRect_put_icon , lpDDSOffIcons1, &rcRect_get_icon,
														   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );

									}
								}
					*/
								////////////////////////////////////////////////
			 }

			///////////////////large structures//////////////////////

			if (thehex->build_in_hex!=(LPbuilding) NULL)
			{
					if (thehex->build_in_hex->type==TOWN)             	// town
							{
								if (planet_draw->land_type==WHITE)
								{
										lpDDSBack->Blt ( &rcRect_120x120 , lpDDSOffStruct_town_ice, &rcRectGet_120x120,
																							   DDBLT_WAIT |
																							   DDBLT_KEYSRC, NULL );
								}
								else if (planet_draw->land_type==BROWN)
								{
									if (thehex->sub_type==1 ||thehex->sub_type==2)
									{
										lpDDSBack->Blt ( &rcRect_120x120 , lpDDSOffStruct_town_desert1, &rcRectGet_120x120,
																							   DDBLT_WAIT |
																							   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==3 ||thehex->sub_type==4)
									{
										lpDDSBack->Blt ( &rcRect_120x120 , lpDDSOffStruct_town_desert2, &rcRectGet_120x120,
																							   DDBLT_WAIT |
																							   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==5 ||thehex->sub_type==6)
									{
										lpDDSBack->Blt ( &rcRect_120x120 , lpDDSOffStruct_town_desert3, &rcRectGet_120x120,
																							   DDBLT_WAIT |
																							   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==7 ||thehex->sub_type==8)
									{
										lpDDSBack->Blt ( &rcRect_120x120 , lpDDSOffStruct_town_desert4, &rcRectGet_120x120,
																							   DDBLT_WAIT |
																							   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==9 ||thehex->sub_type==10)
									{
										lpDDSBack->Blt ( &rcRect_120x120 , lpDDSOffStruct_town_desert5, &rcRectGet_120x120,
																							   DDBLT_WAIT |
																							   DDBLT_KEYSRC, NULL );
									}
								}
								else
								{

									if (thehex->sub_type==1 ||thehex->sub_type==2)
									{
										lpDDSBack->Blt ( &rcRect_120x80 , lpDDSOffStruct_town1, &rcRectGet_120x80,
																							   DDBLT_WAIT |
																							   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==3 ||thehex->sub_type==4)
									{
										lpDDSBack->Blt ( &rcRect_120x80 , lpDDSOffStruct_town2, &rcRectGet_120x80,
																							   DDBLT_WAIT |
																							   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==5 ||thehex->sub_type==6)
									{
										lpDDSBack->Blt ( &rcRect_120x80 , lpDDSOffStruct_town3, &rcRectGet_120x80,
																							   DDBLT_WAIT |
																							   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==7 ||thehex->sub_type==8)
									{
										lpDDSBack->Blt ( &rcRect_120x80 , lpDDSOffStruct_town4, &rcRectGet_120x80,
																							   DDBLT_WAIT |
																							   DDBLT_KEYSRC, NULL );
									}
									if (thehex->sub_type==9 ||thehex->sub_type==10)
									{
										lpDDSBack->Blt ( &rcRect_120x80 , lpDDSOffStruct_town5, &rcRectGet_120x80,
																							   DDBLT_WAIT |
																							   DDBLT_KEYSRC, NULL );
									}
								}
								///////////check if Leftclick on town///////////////
								/*
								if ( LMouse_Hex_Click==true && LMouse_Hex_Click_X == nx &&  LMouse_Hex_Click_Y == ny)

								{
									int number_of_workers=0;
									int workers_type=1;
									for ( LPLABOUR workers=thehex->build_in_hex->worker; workers != (LPLABOUR)NULL; workers=workers->next )
									{
										number_of_workers++;

										RECT rcRect_get_icon;
										RECT rcRect_put_icon;
										int icon_type=(workers->type)-100;
										rcRect_get_icon.left=0+((icon_type-1)*30);
										rcRect_get_icon.right=30+((icon_type-1)*30);
										rcRect_get_icon.top=0;
										rcRect_get_icon.bottom=30;

										rcRect_put_icon.left= x+(0+(number_of_workers*30))/ZooM;
										rcRect_put_icon.right= x+(30+(number_of_workers*30))/ZooM;
										rcRect_put_icon.top= y+40/ZooM;
										rcRect_put_icon.bottom= y+70/ZooM;

										lpDDSBack->Blt ( &rcRect_put_icon , lpDDSOffIcons1, &rcRect_get_icon,
														   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );

									}
								}
								*/
								////////////////////////////////////////////////
							}


					if (thehex->build_in_hex->type==STEEL)             	// town
							{
									lpDDSBack->Blt ( &rcRect_120x120 , lpDDSOffStruct_steel, &rcRectGet_120x120,
														   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );
								 if (thehex->build_in_hex->worker!=(LPLABOUR)NULL)
								 {


									//chimny #1
									rcRect_get_object.left=0+((animation_frame_number-1)*30);
									rcRect_get_object.right=30+((animation_frame_number-1)*30);
									rcRect_get_object.top=0;
									rcRect_get_object.bottom=20;

									rcRect_put_object.left= x+47/ZooM;
									rcRect_put_object.right= x+(47+30)/ZooM;
									rcRect_put_object.top= y+30/ZooM;
									rcRect_put_object.bottom= y+(30+20)/ZooM;

									lpDDSBack->Blt ( &rcRect_put_object , lpDDSOffJump3, &rcRect_get_object,
														   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );
									//chimny #2
									ajust_animation_frame_number= animation_frame_number+5;
									if (ajust_animation_frame_number>10)
									{
										ajust_animation_frame_number = ajust_animation_frame_number-10;
									}
									rcRect_get_object.left=0+((ajust_animation_frame_number-1)*30);
									rcRect_get_object.right=30+((ajust_animation_frame_number-1)*30);
									rcRect_get_object.top=0;
									rcRect_get_object.bottom=20;

									rcRect_put_object.left= x+50/ZooM;
									rcRect_put_object.right= x+(50+30)/ZooM;
									rcRect_put_object.top= y+32/ZooM;
									rcRect_put_object.bottom= y+(32+20)/ZooM;

									lpDDSBack->Blt ( &rcRect_put_object , lpDDSOffJump3, &rcRect_get_object,
														   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );
									//chimny #3
									rcRect_get_object.left=0+((animation_frame_number-1)*30);
									rcRect_get_object.right=30+((animation_frame_number-1)*30);
									rcRect_get_object.top=0;
									rcRect_get_object.bottom=20;

									rcRect_put_object.left= x+61/ZooM;
									rcRect_put_object.right= x+(61+30)/ZooM;
									rcRect_put_object.top= y+35/ZooM;
									rcRect_put_object.bottom= y+(35+20)/ZooM;

									lpDDSBack->Blt ( &rcRect_put_object , lpDDSOffJump3, &rcRect_get_object,
														   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );
									//chimny #4
									rcRect_get_object.left=0+((ajust_animation_frame_number-1)*30);
									rcRect_get_object.right=30+((ajust_animation_frame_number-1)*30);
									rcRect_get_object.top=0;
									rcRect_get_object.bottom=20;

									rcRect_put_object.left= x+72/ZooM;
									rcRect_put_object.right= x+(72+30)/ZooM;
									rcRect_put_object.top= y+35/ZooM;
									rcRect_put_object.bottom= y+(35+20)/ZooM;

									lpDDSBack->Blt ( &rcRect_put_object , lpDDSOffJump3, &rcRect_get_object,
														   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );
									//chimny #5
									rcRect_get_object.left=0+((animation_frame_number-1)*30);
									rcRect_get_object.right=30+((animation_frame_number-1)*30);
									rcRect_get_object.top=0;
									rcRect_get_object.bottom=20;

									rcRect_put_object.left= x+76/ZooM;
									rcRect_put_object.right= x+(76+30)/ZooM;
									rcRect_put_object.top= y+36/ZooM;
									rcRect_put_object.bottom= y+(36+20)/ZooM;

									lpDDSBack->Blt ( &rcRect_put_object , lpDDSOffJump3, &rcRect_get_object,
														   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );
									//chimny #6
									rcRect_get_object.left=0+((ajust_animation_frame_number-1)*30);
									rcRect_get_object.right=30+((ajust_animation_frame_number-1)*30);
									rcRect_get_object.top=0;
									rcRect_get_object.bottom=20;

									rcRect_put_object.left= x+85/ZooM;
									rcRect_put_object.right= x+(85+30)/ZooM;
									rcRect_put_object.top= y+48/ZooM;
									rcRect_put_object.bottom= y+(48+20)/ZooM;

									lpDDSBack->Blt ( &rcRect_put_object , lpDDSOffJump3, &rcRect_get_object,
														   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );
								  }
							}
					if (thehex->build_in_hex->type==CHURCH)             	// town
							{
									lpDDSBack->Blt ( &rcRect_120x120 , lpDDSOffStruct_church, &rcRectGet_120x120,
														   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );
							}
					if (thehex->build_in_hex->type==PALACE)             	// town
							{
									lpDDSBack->Blt ( &rcRect_120x120 , lpDDSOffStruct_palace, &rcRectGet_120x120,
														   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );
							}
					if (thehex->build_in_hex->type==UNI)             	// town
							{
									lpDDSBack->Blt ( &rcRect_120x120 , lpDDSOffStruct_uni, &rcRectGet_120x120,
														   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );
							}
					if (thehex->build_in_hex->type==ENCLOSED_FARM)             	// town
							{
									lpDDSBack->Blt ( &rcRect_120x120 , lpDDSOffStruct_farm_enc, &rcRectGet_120x120,
														   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );
							}

			 }
			///////////////////////////////////////

			if	( (LMouse_Hex_Click == true) && (Cursor_Type!=NONE) &&  (thehex->build_in_hex!=(LPbuilding) NULL))
			{
			   if (Cursor_Type!=FLAG_ICON_CURSOR)
			   {


				   if (icon_activation (popu_selected.worker, thehex->build_in_hex)== true)
				   {
					  Cursor_Type=NONE ;
					  LMouse_Hex_Click=false ;

				   }

			   }

			}

			///////////check if Right click true///////////////


			if (unit_selected!=(LPunit)NULL)
			{
					town_view_on_off=false;
					work_view_on_off=false;
			}

			if ( town_view_on_off==true || work_view_on_off==true)

			{
				if ( Cursor_Type==NONE || Cursor_Type==FLAG_ICON_CURSOR)
				{
					 popu_selected.building_selected=(LPbuilding) NULL;
					 popu_selected.worker=(LPLABOUR)NULL;
				}


				if (thehex->build_in_hex!=(LPbuilding) NULL)
				{

					  int number_of_workers=0;
					  int workers_type=1;
					  LPLABOUR workers;
					  RECT rcRect_get_icon;
					  RECT rcRect_put_icon;
					  int icon_type;
					  int x_adjust=0;
					  int y_adjust=0;
					  if (town_view_on_off==true  )
					  {
							 if (thehex->build_in_hex->worker!=(LPLABOUR)NULL)
							{
								  if (thehex->build_in_hex->type==TOWN)
								 {
									if (  thehex->build_in_hex->town_number==town_view_number )
									  {
										 for ( workers=thehex->build_in_hex->worker; workers != (LPLABOUR)NULL; workers=workers->next )
											{

												number_of_workers++;
												if (number_of_workers>2)
												{
													x_adjust= -45;
													y_adjust=  30;
												}

												RECT rcRect_get_icon;
												RECT rcRect_put_icon;
												icon_type=(workers->type)-100;
												rcRect_get_icon.left=0+((icon_type-1)*30);
												rcRect_get_icon.right=30+((icon_type-1)*30);
												rcRect_get_icon.top=0;
												rcRect_get_icon.bottom=30;

												rcRect_put_icon.left= (x)+(0+(number_of_workers*30)+x_adjust)/ZooM;
												rcRect_put_icon.right= (x)+(30+(number_of_workers*30)+x_adjust)/ZooM;
												rcRect_put_icon.top= y+(55+y_adjust)/ZooM;
												rcRect_put_icon.bottom= y+(85+y_adjust)/ZooM;

												//   find left click location

													if 	(		(LMousexPos >  rcRect_put_icon.left )
															&&  (LMousexPos <= rcRect_put_icon.right)
															&&  (LMouseyPos >  rcRect_put_icon.top )
															&&  (LMouseyPos <= rcRect_put_icon.bottom)
															&&	(LMouse_Hex_Click!=false)	  )
													{
															//off for debug
															//Cursor_Type=icon_type;
															//popu_selected.building_selected=thehex->build_in_hex;
															//popu_selected.worker=workers;
													}
													if (popu_selected.worker!=workers)
													{

															lpDDSBack->Blt ( &rcRect_put_icon , lpDDSOffIcons1, &rcRect_get_icon,
																DDBLT_WAIT |
																DDBLT_KEYSRC, NULL );

													}

												if (workers->aligence==YELLOW || workers->aligence==RED || workers->aligence==BLEU || workers->aligence==ORANGE || workers->aligence==NUTRAL)
												{
													icon_type= (workers->aligence)-100;
													rcRect_get_icon.left=0+((icon_type-1)*30);
													rcRect_get_icon.right=30+((icon_type-1)*30);
													rcRect_get_icon.top=0;
													rcRect_get_icon.bottom=30;

													lpDDSBack->Blt ( &rcRect_put_icon , lpDDSOffFactions1, &rcRect_get_icon,
														   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );
												}




											}
									  }

								 }
								 else
								 {
									 if	(thehex->build_in_hex->worker->home->town_number==town_view_number )
									 {
											//if (thehex==(LPhex)NULL) break;
											workers=thehex->build_in_hex->worker;
											number_of_workers++;

											RECT rcRect_get_icon;
											RECT rcRect_put_icon;
											icon_type=(workers->type)-100;
											rcRect_get_icon.left=0+((icon_type-1)*30);
											rcRect_get_icon.right=30+((icon_type-1)*30);
											rcRect_get_icon.top=0;
											rcRect_get_icon.bottom=30;

											rcRect_put_icon.left= x+(15+(number_of_workers*30))/ZooM;
											rcRect_put_icon.right= x+(45+(number_of_workers*30))/ZooM;
											rcRect_put_icon.top= y+70/ZooM;
											rcRect_put_icon.bottom= y+100/ZooM;

											//   find left click location

													if 	(		(LMousexPos >  rcRect_put_icon.left )
															&&  (LMousexPos <= rcRect_put_icon.right)
															&&  (LMouseyPos >  rcRect_put_icon.top )
															&&  (LMouseyPos <= rcRect_put_icon.bottom)
															&&	(LMouse_Hex_Click!=false)	  	)
													{
															//turn off for debug
															//Cursor_Type=icon_type;
															//popu_selected.building_selected=thehex->build_in_hex;
															//popu_selected.worker=workers;
													}
													if (popu_selected.worker!=workers)
													{

															lpDDSBack->Blt ( &rcRect_put_icon , lpDDSOffIcons1, &rcRect_get_icon,
																DDBLT_WAIT |
																DDBLT_KEYSRC, NULL );

													}

											if (workers->aligence==YELLOW || workers->aligence==RED || workers->aligence==BLEU || workers->aligence==ORANGE || workers->aligence==NUTRAL)
												{
													icon_type= (workers->aligence)-100;
													rcRect_get_icon.left=0+((icon_type-1)*30);
													rcRect_get_icon.right=30+((icon_type-1)*30);
													rcRect_get_icon.top=0;
													rcRect_get_icon.bottom=30;

													lpDDSBack->Blt ( &rcRect_put_icon , lpDDSOffFactions1, &rcRect_get_icon,
														   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );
												}



									  }
							}
					  }
			}

					  if (thehex==Check_popu[0].popu)
							{       //if (thehex!=(LPhex)NULL)
									for ( workers=thehex->build_in_hex->worker; workers != (LPLABOUR)NULL; workers=workers->next )
									{

										number_of_workers++;
										if (number_of_workers>2)
										{
											 x_adjust= -45;
											 y_adjust=  30;
										}

										RECT rcRect_get_icon;
										RECT rcRect_put_icon;
										icon_type=(workers->type)-100;
										rcRect_get_icon.left=0+((icon_type-1)*30);
										rcRect_get_icon.right=30+((icon_type-1)*30);
										rcRect_get_icon.top=0;
										rcRect_get_icon.bottom=30;

										rcRect_put_icon.left= (x)+(0+(number_of_workers*30)+x_adjust)/ZooM;
										rcRect_put_icon.right= (x)+(30+(number_of_workers*30)+x_adjust)/ZooM;
										rcRect_put_icon.top= y+(55+y_adjust)/ZooM;
										rcRect_put_icon.bottom= y+(85+y_adjust)/ZooM;

										//   find left click location

													if 	(		(LMousexPos >  rcRect_put_icon.left )
															&&  (LMousexPos <= rcRect_put_icon.right)
															&&  (LMouseyPos >  rcRect_put_icon.top )
															&&  (LMouseyPos <= rcRect_put_icon.bottom)
															&&	(LMouse_Hex_Click!=false)	  	)
													{
															Cursor_Type=icon_type;
															popu_selected.building_selected=thehex->build_in_hex;
															popu_selected.worker=workers;
													}
													if (popu_selected.worker!=workers)
													{

															lpDDSBack->Blt ( &rcRect_put_icon , lpDDSOffIcons1, &rcRect_get_icon,
																DDBLT_WAIT |
																DDBLT_KEYSRC, NULL );

													}

										if (workers->aligence==YELLOW || workers->aligence==RED || workers->aligence==BLEU || workers->aligence==ORANGE || workers->aligence==NUTRAL)
												{
													icon_type= (workers->aligence)-100;
													rcRect_get_icon.left=0+((icon_type-1)*30);
													rcRect_get_icon.right=30+((icon_type-1)*30);
													rcRect_get_icon.top=0;
													rcRect_get_icon.bottom=30;

													lpDDSBack->Blt ( &rcRect_put_icon , lpDDSOffFactions1, &rcRect_get_icon,
														   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );
												}



									}
							   }

							   for (int iiii = 1; iiii <= 5; iiii++)
							   {


								   if (thehex==Check_popu[iiii].popu)
								   {
										//if (thehex==(LPhex)NULL) break;
										workers=thehex->build_in_hex->worker;
										number_of_workers++;

											RECT rcRect_get_icon;
											RECT rcRect_put_icon;
											icon_type=(workers->type)-100;
											rcRect_get_icon.left=0+((icon_type-1)*30);
											rcRect_get_icon.right=30+((icon_type-1)*30);
											rcRect_get_icon.top=0;
											rcRect_get_icon.bottom=30;

											rcRect_put_icon.left= x+(15+(number_of_workers*30))/ZooM;
											rcRect_put_icon.right= x+(45+(number_of_workers*30))/ZooM;
											rcRect_put_icon.top= y+70/ZooM;
											rcRect_put_icon.bottom= y+100/ZooM;

											//   find left click location

											if 	(		(LMousexPos >  rcRect_put_icon.left )
															&&  (LMousexPos <= rcRect_put_icon.right)
															&&  (LMouseyPos >  rcRect_put_icon.top )
															&&  (LMouseyPos <= rcRect_put_icon.bottom)
															&&	(LMouse_Hex_Click!=false)	  	)
													{
															Cursor_Type=icon_type;
															popu_selected.building_selected=thehex->build_in_hex;
															popu_selected.worker=workers;
													}

											if (popu_selected.worker!=workers)  //draw icon if popu not selected to cursor
													{

															lpDDSBack->Blt ( &rcRect_put_icon , lpDDSOffIcons1, &rcRect_get_icon,
																DDBLT_WAIT |
																DDBLT_KEYSRC, NULL );

													}
											//set frame of icon
											if (workers->aligence==YELLOW || workers->aligence==RED || workers->aligence==BLEU || workers->aligence==ORANGE || workers->aligence==NUTRAL)
												{
													icon_type= (workers->aligence)-100;
													rcRect_get_icon.left=0+((icon_type-1)*30);
													rcRect_get_icon.right=30+((icon_type-1)*30);
													rcRect_get_icon.top=0;
													rcRect_get_icon.bottom=30;

													lpDDSBack->Blt ( &rcRect_put_icon , lpDDSOffFactions1, &rcRect_get_icon,
														   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );
												}


								   }
							  }




			}

	  }

			/// units/////////
			//draw//
			if ( thehex->unit_in_hex != (LPunit)NULL)
			{
				Update_unit_pos_in_hex( thehex->unit_in_hex );
				unit_draw( thehex, x, y );
			}
			//find if movement desti selected//
			if (unit_selected!=(LPunit) NULL)
			{
				if ( 	LMouse_Hex_Click == true 	&&
						LMouse_Hex_Click_X == nx 	&&
						LMouse_Hex_Click_Y == ny 	&&
						unit_selected->hex != thehex &&
						LMouse_triger==true )
				{

					   town_view_on_off=false;

						work_view_on_off=false;

					   //info: thehex =  planet_draw->planet_matrice [nx][ny];
						//go to desti check routine
						LMouse_triger=false;

						LMouse_Hex_Click = false;

						//debug turn off
						if (find_path_unit ( unit_selected, thehex, planet_draw )==true);
						{
							Cursor_Type =0;
							unit_selected=(LPunit) NULL ;

                        }
				}
			}
			////////////////////////////////////////////////

			/////////////////////////////////////////////////////////
			//next_hex = thehex->west;      // move west through hexes
			x=x-105/ZooM;  // hex x lengh
			x=x+1;
		  }  // end of 'for nx' loop


		 y=y+45/ZooM;
		 if (nn!=0)
		 {
			 first_x = first_x + 15/ZooM;   // paire ajustment (+30)
		 }
	   y=y-1;
	  }  // end of 'for ny' loop

	  ///debug to see where ends
	  if (JUST_ONCE==true)
		  {
			  debugfile ("= planet y at loop end\n", y );
			  debugfile ("= ZooM fact times 1000\n", (ZooM*1000) );
			  JUST_ONCE=false;
		  }




		//if (DRAWN_PLANET_MAP==true)
		//{
         //bla sage to wo=rld image map


			//lpDDSOffWorlds->BltFast( 0, 0 , lpDDSBack, NULL,
			//							   DDBLTFAST_WAIT |
			//						   DDBLTFAST_SRCCOLORKEY );

			/*
			rcRect_put_map.bottom = 	screen_y-(screen_y-(45/ZooM)-(48*(45/ZooM))+((45/ZooM)*ZooM));
			rcRect_put_map.right = 	screen_x;
			rcRect_put_map.left=	0;
			rcRect_put_map.top=		0

			rcRect_get_map.bottom = 	screen_y;             // default get terraines
			rcRect_get_map.right = 	screen_x;
			rcRect_get_map.left=		0;
			rcRect_get_map.top=		screen_y-(45/ZooM)-(48*(45/ZooM))+((45/ZooM)*ZooM)

			lpDDSOffWorlds->Blt ( &rcRect_put_map , lpDDSBack, &rcRect_get_map,
														   DDBLT_WAIT |
														   DDBLT_KEYSRC, NULL );
			DRAWN_PLANET_MAP=true;
			*/
		//}

		//befor we leave, and given that the orbital view can take time to draw,
		//we should see is the click on hex was not missed befor the screen was finished drawing.

		/*
		if ( ( (LMouseyPos>first_y) ) && (LMouseDown==true)  )
			{

				 x=start_at_x;
				 y=start_at_y;

				 for ( int ny = 0 ; ny < planet_size_y ; ny++ )
   				 {

	  				if ( y > screen_y ) {break;} // no point cont if out south

	  				nn = (ny+1) % 2;


	  				if (nn==0) { x= first_x; }
	  				else { x=first_x - (45.0/ZooM); }

	  				for ( int  nx = 0 ;  ; nx++ )
	  				{

						if (nx >= planet_size_x)
						{
                			nx=0;
						}

						thehex =  planet_draw->planet_matrice [nx][ny];

						rcRectHex.left = x+(7.0/ZooM);                     // default hex
						rcRectHex.right =x+(113.0/ZooM);
						rcRectHex.top =  y+60/ZooM;
						rcRectHex.bottom =y+105/ZooM;

						//   find left click location
						if 	(		(LMousexPos >  rcRectHex.left )
								&&  (LMousexPos <= rcRectHex.right)
			   					&&  (LMouseyPos >  rcRectHex.top )
			   					&&  (LMouseyPos <= rcRectHex.bottom) )
						{

							/////////////click location////////////
							LMouse_Hex_Click_X = nx;
							LMouse_Hex_Click_Y = ny;
							LMouse_Hex_Click   = true;
							//RMouse_Hex_Click   = false;
                    		//LMouse_triger=false;
						}

						x=x-105/ZooM;  // hex x lengh
						x=x+1;

		  			}  // end of 'for nx' loop


		 		y=y+45/ZooM;
		 		if (nn!=0)
		 		{
			 		first_x = first_x + 15/ZooM;   // paire ajustment (+30)
		 		}
	   			y=y-1;

	  		}  // end of 'for ny' loop

		} //end "if ( ( (LMouseyPos>first_y) ) && (LMouseDown==true) &&  (LMouse_triger==true) )"
	*/

	if (        ( ORBITAL_VIEW == true )
	         && (LMouse_Hex_Click == true)
		     && ( LMouse_triger==true)
		     && ( LMouseDown==true )          )
				{

					ORBITAL_VIEW = false;
					ZooM=1;
					//now center map at hex location of click
					//LMouse_Hex_Click_X = nx;
					//LMouse_Hex_Click_Y = ny;

					LMouse_Hex_Click   = false;
					LMouse_triger      = false;

					//y= screen_y-(45/ZooM)-(48*(45/ZooM))+((45/ZooM)*ZooM);
					//first_y= screen_y-(45/ZooM)-(48*(45/ZooM))+((45/ZooM)*ZooM);

					//x=LMouse_Hex_Click_X-(105/ZooM)  // hex x lengh
					//x=x+1;

		            planet_see_y= ( screen_y/2 )+ ( LMouse_Hex_Click_Y*(-45/ZooM) );
		 			first_y=      ( screen_y/2 )+ ( LMouse_Hex_Click_Y*(-45/ZooM) );

					planet_see_x= ( screen_x/2 )+ ( LMouse_Hex_Click_X*(105/ZooM)  );
		 			first_x=      ( screen_x/2 )+ ( LMouse_Hex_Click_X*(105/ZooM)  );

					//center hex

					first_x =       first_x - ( (105.0/ZooM) / 2 );
					planet_see_x  = first_x - ( (105.0/ZooM) / 2 );

					planet_see_y=   first_y - ( (45.0/ZooM) * 2 );
		 			first_y=        first_y - ( (45.0/ZooM) * 2 );

					//offset
					nn = (LMouse_Hex_Click_Y+1) % 2;
					if (nn!=0)
						{
							first_x=      first_x + (45.0/ZooM);
							planet_see_x= first_x + (45.0/ZooM);
						}

					//paire ajustment (+30)
					facterOFtwo=  ( (LMouse_Hex_Click_Y) /2);
					first_x =     first_x - ( (7.5/ZooM) * (facterOFtwo)  ) ;   //
					planet_see_x= first_x - ( (7.5/ZooM) * (facterOFtwo)  ) ;   //

					//if over bottom edge, set border on edge

					if (planet_see_y < screen_y-(45/ZooM)-(48*(45/ZooM))+((45/ZooM)*ZooM) )
					{
						planet_see_y= screen_y-(45/ZooM)-(48*(45/ZooM))+((45/ZooM)*ZooM);
						first_y=      screen_y-(45/ZooM)-(48*(45/ZooM))+((45/ZooM)*ZooM);
					}

				}

		///selection zoom in/out routine
		//if ( Zoom_Routine_on_Selection (1) == true )
			//{
					//planet_see_y= ( screen_y/2 )+ ( unit_selected->hex->Y_hex_location * (-45/ZooM) );
		 			//first_y=      ( screen_y/2 )+ ( unit_selected->hex->Y_hex_location * (-45/ZooM) );

					//planet_see_x= ( screen_x/2 )+ ( unit_selected->hex->X_hex_location * (105/ZooM)  );
		 			//first_x=      ( screen_x/2 )+ ( unit_selected->hex->X_hex_location * (105/ZooM)  );

					//planet_see_y= find_screen_unit_y;
		 			//first_y=      find_screen_unit_y;

					//planet_see_x= find_screen_unit_x;
		 			//first_x=      find_screen_unit_x;

					//center hex


					//first_x =       first_x - ( (105.0/ZooM) / 2 );
					//planet_see_x  = first_x - ( (105.0/ZooM) / 2 );

					//planet_see_y=   first_y - ( (45.0/ZooM) * 2 );
		 			//first_y=        first_y - ( (45.0/ZooM) * 2 );

					//offset
					//nn = (LMouse_Hex_Click_Y+1) % 2;
					//if (nn!=0)
						//{
							//first_x=      first_x + (45.0/ZooM);
							//planet_see_x= first_x + (45.0/ZooM);
						//}

					//paire ajustment (+30)
					//facterOFtwo=  ( (LMouse_Hex_Click_Y) /2);
					//first_x =     first_x - ( (7.5/ZooM) * (facterOFtwo)  ) ;   //
					//planet_see_x= first_x - ( (7.5/ZooM) * (facterOFtwo)  ) ;   //

					//if over bottom edge, set border on edge

					//if (planet_see_y < screen_y-(45/ZooM)-(48*(45/ZooM))+((45/ZooM)*ZooM) )
					//{
						//planet_see_y= screen_y-(45/ZooM)-(48*(45/ZooM))+((45/ZooM)*ZooM);
						//first_y=      screen_y-(45/ZooM)-(48*(45/ZooM))+((45/ZooM)*ZooM);
					//}
			//}
}
