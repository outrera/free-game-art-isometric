long FAR PASCAL WindowProc( HWND hWnd, UINT message,
							WPARAM wParam, LPARAM lParam )
{
	  RMousexDif=0; RMouseyDif=0;
	  //int mousemoving= false;

				switch ( message )
    {
			//case WM_SETCURSOR:
			//	SetCursor( NULL );		// Turn off the mouse cursor.
  	 		//	return TRUE;


         case WM_ACTIVATEAPP:
            bActive = wParam;
            break;

         case WM_CREATE:
            hBrushGreen = CreateHatchBrush( HS_CROSS, RGB( 0, 255, 0 ) );
            hBrushRed = CreateSolidBrush( RGB( 255, 0, 0 ) );
            hBrushJump1 = CreateSolidBrush( RGB( 204, 204, 204 ) );
            hBrushJump2 = CreateSolidBrush( RGB( 127, 127, 127 ) );
            hBrushJump3 = CreateSolidBrush( RGB( 100, 100, 100 ) );
			hPenJump1   =CreatePen( PS_SOLID	,1, RGB( 204, 204, 204 ));
            hPenJump2   =CreatePen( PS_SOLID	,1, RGB( 127, 127, 127 ));
            hPenJump3   =CreatePen( PS_SOLID	,1, RGB( 100, 100, 100 ));
			break;
          /*
		 case WM_MOUSEWHEEL:

				zDelta = GET_WHEEL_DELTA_WPARAM(wParam);
				if (zDelta>1)
				{
				   ZooM=ZooM+0.05;
				   if (ZooM>5)
				   {
					   ZooM=5.0;
				   }
				}
				if (zDelta<1)
				{
				   ZooM=ZooM-0.05;
				   if (ZooM<1)
				   {
					   ZooM=1.0;
				   }
				}
				//old_zDelta=zDelta;
			  break;
           */

		case   WM_LBUTTONUP :
			   		LMouseBeenUsed=false;
			   		LMouseDown=false;
			   		LMouse_triger=true;
			   		break;

		case   WM_RBUTTONUP :

					RMouseDown=false;
					RMousexPos=xPos;
					RMouseyPos=yPos;
					RMousexDif=0; RMouseyDif=0;
					RMouse_triger=true;
					break;


		 case WM_MOUSEMOVE:

//					fwKeys = wParam;        // key flags
					xPos = LOWORD(lParam);  // horizontal position of cursor (artificial sprite)
					yPos = HIWORD(lParam);  // vertical position of cursor
					//mousemoving=true;



         switch ( wParam )
               {
            case MK_LBUTTON:        //	Set if the left mouse button is down.
 //         xPos = LOWORD(lParam);  // horizontal position of cursor
//				yPos = HIWORD(lParam);  // vertical position of cursor
			LMousexPos=xPos;
         	LMouseyPos=yPos;
			LMouseDown=1;
			//LMouse_triger=false;
			break;
				}

		 switch ( wParam )
               {
			case MK_RBUTTON:        //	Set if the right mouse button is down.
//          xPos = LOWORD(lParam);  // horizontal position of cursor
//				yPos = HIWORD(lParam);  // vertical position of cursor
						if ( RMouseDown==1	)
						{
							RMousexDif=xPos-RMousexPos;
							RMouseyDif=yPos-RMouseyPos;
							RMousexPos=xPos;
							RMouseyPos=yPos;
							//RMouseDown=1;
						}
						else
						{
							RMousexDif=0;
							RMouseyDif=0;
							RMousexPos=xPos;
							RMouseyPos=yPos;
							RMouseDown=1;
						}
					                    /*
                        	if (mousemoving==false)
                        						{
                        							RMousexDif=0;
                        							RMouseyDif=0;
												}
                    */

            			 break;
				}
                      break;

		 case   WM_LBUTTONDOWN : //	Set if the left mouse button is down.
				//switch ( wParam )
			   //{
					//case MK_LBUTTON:        //	Set if the left mouse button is down.
            		xPos = LOWORD(lParam);  // horizontal position of cursor
             		yPos = HIWORD(lParam);  // vertical position of cursor
					LMousexPos=xPos;
					LMouseyPos=yPos;
					LMouseDown=1;
					//LMouse_triger=false;



					break;


				//}
				//break;


		case   WM_RBUTTONDOWN : //	Set if the right mouse button is down.
				  //	switch ( wParam )
				  // {
				//case MK_RBUTTON:        //	Set if the right mouse button is down.
    			   RMousexPos=xPos;
    			   RMouseyPos=yPos;
				   RMouseDown=1;
				   //RMousexDif=0;
				   //RMouseyDif=0;
/*
        			   if (mousemoving==false)
    				   {
    					   RMousexDif=0;
    					   RMouseyDif=0;
					   }
*/
    						 break;
					 //}
						 //break;



		  //case	  WM_LBUTTONDBLCLK:
		  //          break;


		  case WM_KEYDOWN:
          startgame=true;
          switch ( wParam )
  			{
			//case VK_F1:
			  // regenerate=1;
			   //arms++;
               //break;

			case VK_ESCAPE:
				PostMessage( hWnd, WM_CLOSE, 0, 0 );
				break;

            //case VK_F2:
               //regenerate=true;
               //arms--;
              // break;
            case VK_F3:
               regenerate=true;
               spread=spread+10;
               break;
            case VK_F4:
               regenerate=true;
               spread=spread-10;
               break;
            case VK_F5:
               regenerate=true;
               shapeN=shapeN+0.2;
               break;
            case VK_F6:
			   regenerate=true;
               shapeN=shapeN-0.2;
               break;
            case VK_F7:
			   regenerate=true;
			   shapeL=shapeL+0.2;
			   break;
						/*     ////////////// debug////////////////
				case VK_F8:
							   //regenerate=true;
							   //shapeL=shapeL-0.2;
							   find_red=find_red+1;
							   debugfile ("red is  \n", find_red );
							   dwGreen =RGB(find_red,find_green,find_bleu) ;
							   dwBlue =RGB(find_red,find_green,find_bleu) ;
                			   ddsd.ddckCKSrcBlt.dwColorSpaceLowValue = dwGreen;
							   ddsd.ddckCKSrcBlt.dwColorSpaceHighValue = dwBlue;
							   break;
							 case VK_F9:
								//regenerate=true;
							   //shapeL=shapeL-0.2;
							   find_green=find_green+1;
							   debugfile ("green is  \n", find_green );
							   dwGreen =RGB(find_red,find_green,find_bleu) ;
							   dwBlue =RGB(find_red,find_green,find_bleu) ;
							   ddsd.ddckCKSrcBlt.dwColorSpaceLowValue = dwGreen;
							   ddsd.ddckCKSrcBlt.dwColorSpaceHighValue = dwBlue;
							   Creat_Nebula ();
							   break;

							 case VK_F10:
								//regenerate=true;
							   //shapeL=shapeL-0.2;
							   find_bleu=find_bleu+1;
							   debugfile ("bleu is  \n", find_bleu );
							   dwGreen =RGB(find_red,find_green,find_bleu) ;
							   dwBlue =RGB(find_red,find_green,find_bleu) ;
							   ddsd.ddckCKSrcBlt.dwColorSpaceLowValue = dwGreen;
							   ddsd.ddckCKSrcBlt.dwColorSpaceHighValue = dwBlue;
							   break;
			*/



            case VK_RETURN:
               regenerate=true;
               break;
            case VK_DELETE:
               regenerate=true; arms=4;  spread=30;   shapeN=1.5;  shapeL=2.5;
               break;
            case VK_F11:
               Zoomtype=2;
               break;
			case VK_F12:
			   Zoomtype=1;
			   break;
			case VK_SPACE:
			   space_key_down=true;
			   break;
			case VK_F1:      //page up
			   ZooM=ZooM+0.05;
				   if (ZooM>6)
				   {
					   ZooM=6.0;
				   };
			   break;
			case VK_F2:       //page down
			   ZooM=ZooM-0.05;
				   if (ZooM<1)
				   {
					   ZooM=1.0;
				   };
			   break;
			}


     break;


 		case WM_DESTROY:
			ReleaseObjects();
			debugfile ("created nodes....\n", creat_nodes ); //#/#/#/
			debugfile ("deleted nodes....\n", free_nodes ); //#/#/#/
			PostQuitMessage( 0 );
			break;


		}

    return DefWindowProc( hWnd, message, wParam, lParam );
}

