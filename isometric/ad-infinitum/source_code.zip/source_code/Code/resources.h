int planet_scan_resourse_place ( LPplanet planet_scaned, int resourse_scaned,
									int first_terrain_type, int first_terrain_chance,
									int second_terrain_type, int second_terrain_chance,
									int third_terrain_type, int third_terrain_chance,
									int fourth_terrain_type, int fourth_terrain_chance)
{
   //int check_hex_x, check_hex_y;
   int scan_yes;
   int resourse_temp [100][100];
   int nx,ny;

   int dice;
   int scan_value=0;
   int total_value=0;

	for (ny=0; ny< planet_size_y; ny++)
   {
	   for (nx=0; nx< planet_size_x; nx++ )
	   { resourse_temp [nx][ny] =  0; }  //set to null
   }

   for (ny=0; ny< planet_size_y; ny++)
   {


	   for (nx=0; nx< planet_size_x; nx++ )
	   {
			//check_hex_x = nx;
			//check_hex_y = ny;
			//first work out center hex
			//scan_yes = false; //default
			scan_value = 0;   //default
			if ( (planet_scaned->planet_matrice[nx][ny]->type) == first_terrain_type )
					 { scan_value=scan_value+first_terrain_chance; scan_yes = true; }
			if ( (planet_scaned->planet_matrice[nx][ny]->type) == second_terrain_type )
					 { scan_value=scan_value+second_terrain_chance; scan_yes = true; }
			if ( (planet_scaned->planet_matrice[nx][ny]->type) == third_terrain_type )
					 { scan_value=scan_value+third_terrain_chance; scan_yes = true; }
			if ( (planet_scaned->planet_matrice[nx][ny]->type) == fourth_terrain_type )
					 { scan_value=scan_value+fourth_terrain_chance; scan_yes = true; }

			//no resourse on another resourse
			if  ( planet_scaned->planet_matrice[nx][ny]->resourse != NONE )
					 { scan_value=0; scan_yes = false;}

			resourse_temp [nx][ny] = scan_value;
			total_value=total_value+scan_value;
	   }
   }
   //now work out where resource randomly is
   if (total_value==0)
   {
		 return false;
   }
   dice = random( total_value );
   int adding_value=0;
   for (ny=0; ny< planet_size_y; ny++)
   {
	   for (nx=0; nx< planet_size_x; nx++ )
	   {
			adding_value=adding_value+resourse_temp [nx][ny];
			if (adding_value  >=  dice)
			{
				planet_scaned->planet_matrice[nx][ny]->resourse = resourse_scaned;
				return true;

			}

	   }
   }
return false;
}

int number_of_resource (int Chances)
{
		int return_value;
		int dice=(random(6)+1)+Chances;
		switch ( dice )
		{
			case 1:
			return_value=0;
			break;

			case 2:
			return_value=0;
			break;

			case 3:
			return_value=1;
			break;

			case 4:
			return_value=2;
			break;

			case 5:
			return_value=3;
			break;

			case 6:
			return_value=4;
			break;

			case 7:
			return_value=5;
			break;

			case 8:
			return_value=6;
			break;

			case 9:
			return_value=7;
			break;

			case 10:
			return_value=8;
			break;

			case 11:
			return_value=9;
			break;

			case 12:
			return_value=10;
			break;
		}
		return return_value;
}

void set_world_resources (LPplanet planet)
{

int base_oil=0;
int base_steel=0;
int base_spice=0;
int base_gem=0;
int base_trace=0;
int base_chemical=0;
int base_hyper_steel=0;
int base_gold=0;
int base_radioactive=0;
int dice; int resourse;
int world_type = planet->planet_type;
int planet_number = planet->number;


if (star [planet_number].owner==HIGH_STEWARD)
	{
		 base_oil=20;
		 base_steel=4;
		 base_spice=0;
		 base_gem=1;
		 base_trace=4;
		 base_chemical=0;
		 base_hyper_steel=0;
		 base_radioactive=1;

	}
	else if (star [planet_number].owner==RED)
	{
		 base_oil=4;
		 base_steel=3;
		 base_spice=0;
		 base_gem=0;
		 base_trace=2;
		 base_chemical=0;
		 base_hyper_steel=0;
		 base_radioactive=1;

	}
	else if (star [planet_number].owner==GREEN)
	{
		 base_oil=0;
		 base_steel=3;
		 base_spice=0;
		 base_gem=0;
		 base_trace=2;
		 base_chemical=2;
		 base_hyper_steel=0;
		 base_radioactive=3;

	}
	else if (star [planet_number].owner==ORANGE)
	{
		 base_oil=6;
		 base_steel=3;
		 base_spice=0;
		 base_gem=0;
		 base_trace=2;
		 base_chemical=0;
		 base_hyper_steel=0;
		 base_radioactive=0;
	}
	else if (star [planet_number].owner==YELLOW)
	{
		 base_oil=4;
		 base_steel=3;
		 base_spice=0;
		 base_gem=0;
		 base_trace=3;
		 base_chemical=0;
		 base_hyper_steel=0;
		 base_radioactive=0;

	}
	else if (star [planet_number].owner==GUILD)
	{
		 base_oil=5;
		 base_steel=4;
		 base_spice=0;
		 base_gem=1;
		 base_trace=3;
		 base_chemical=0;
		 base_hyper_steel=0;
		 base_radioactive=1;

	}
	else if (star [planet_number].owner==BLEU)
	{
		 base_oil=4;
		 base_steel=3;
		 base_spice=1;
		 base_gem=0;
		 base_trace=2;
		 base_chemical=0;
		 base_hyper_steel=0;
		 base_radioactive=0;

	}
	else
	{
		if (world_type==LAVA)
			{
				base_oil=0;
				base_steel=number_of_resource (6);
				base_spice=0;
				//base_gem=0;
				base_trace=number_of_resource (3);
				base_chemical=0;
				base_hyper_steel=number_of_resource (2);
				base_radioactive=2;
			}
		if (world_type==ICE)
			{
				base_oil=number_of_resource (3);
				base_steel=number_of_resource (4);
				base_spice=0;
				//base_gem=0;
				base_trace=number_of_resource (4);
				//base_chemical=10;
				base_radioactive=0;
			}

		if (world_type==TEMP)
			{
				base_oil=number_of_resource (3);
				base_steel=number_of_resource (3);
				base_spice=number_of_resource (0);
				//base_gem=0;
				base_trace=number_of_resource (2);
				//base_chemical=10;
				base_radioactive=0;
			}

		if (world_type==ISLE)
			{
				base_oil=number_of_resource (5);
				base_steel=number_of_resource (2);
				base_spice=number_of_resource (0);
				//base_gem=0;
				base_trace=number_of_resource (1);
				//base_chemical=10;
				base_radioactive=0;
			}

		if (world_type==JUNGLE)
			{
				base_oil=number_of_resource (3);
				base_steel=number_of_resource (3);
				base_spice=number_of_resource (3);
				//base_gem=0;
				base_trace=number_of_resource (3);
				//base_chemical=10;
				base_radioactive=0;
			}

		if (world_type==MOON)
			{
				base_oil=0;
				base_steel=number_of_resource (3);
				base_spice=0;
				//base_gem=0;
				base_trace=number_of_resource (3);
				//base_chemical=0;
				base_radioactive=3;
			}

		if (world_type==EXOTIC)
			{
				base_oil=0;
				base_steel=number_of_resource (3);
				base_spice=0;
				//base_gem=0;
				base_trace=number_of_resource (1);
				base_chemical=number_of_resource (3);
				base_radioactive=2;

			}

		if (world_type==DESERT)
		{
				base_oil=number_of_resource (3);
				base_steel=number_of_resource (3);
				base_spice=0;
				//base_gem=0;
				base_trace=number_of_resource (3);
				//base_chemical=0;
				base_radioactive=number_of_resource (0);
		}
		if (world_type==OASIS)
		{
				base_oil=number_of_resource (3);
				base_steel=number_of_resource (3);
				base_spice=0;
				//base_gem=0;
				base_trace=number_of_resource (3);
				//base_chemical=0;
				base_radioactive=number_of_resource (0);
		}

		if (world_type==WATER)
		{
			base_oil=number_of_resource (3);
			base_steel=number_of_resource (3);
			base_spice=number_of_resource (3);
			//base_gem=0;
			base_trace=number_of_resource (3);
			//base_chemical=10;
			base_radioactive=number_of_resource (0);
		}

		if (world_type==SWAMP)
		{
			base_oil=number_of_resource (3);
			base_steel=number_of_resource (3);
			base_spice=number_of_resource (3);
			//base_gem=0;
			base_trace=number_of_resource (3);
			//base_chemical=10;
			base_radioactive=number_of_resource (0);
		}
	}

//##############
if ( base_oil !=0 )
	{
		if ( world_type==OASIS )
		{
			for (int nnn=1;nnn <= base_oil;nnn++)
			{
				planet_scan_resourse_place ( planet, OIL,
									HYDRO, COMMAN,
									PLAIN, RARE,
									SWAMP, UNCOMMAN,
									NONE, NONE);
			}
		}
		else if ( world_type==DESERT )
		{
			for (int nnn=1;nnn <= base_oil;nnn++)
			{
				planet_scan_resourse_place ( planet, OIL,
									HYDRO, COMMAN,
									PLAIN, RARE,
									SHALOW, RARE,
									DEEP, VERY_COMMAN);
			}
		}
		else
		{
			for (int nnn=1;nnn <= base_oil;nnn++)
			{
				planet_scan_resourse_place ( planet, OIL,
									HYDRO, COMMAN,
									PLAIN, RARE,
									SWAMP, VERY_RARE,
									PLANT_PLAIN, RARE);
			}
		}
	}
if (base_steel !=0)
	{
		for (int nnn=1;nnn <= base_steel;nnn++)
		{
			planet_scan_resourse_place ( planet, METAL,
									MOUNT, COMMAN,
									HILL, RARE,
									PLANT_HILL, RARE,
									NONE, NONE) ;
		}
	}
if (base_trace !=0)
	{
		if ( world_type==OASIS )
		{
			for (int nnn=1;nnn <= base_oil;nnn++)
			{
				planet_scan_resourse_place ( planet, TRACE,
									PLAIN, COMMAN,
									HILL, RARE,
									NONE, NONE,
									NONE, NONE);
			}
		}
		else
		{
			for (int nnn=1;nnn <= base_trace;nnn++)
			{
				planet_scan_resourse_place ( planet, TRACE,
									PLAIN, COMMAN,
									HILL, RARE,
									PLANT_PLAIN, COMMAN,
									SWAMP, RARE);
			}
		}
	}
if (base_spice !=0)
	{
		for (int nnn=1;nnn <= base_spice;nnn++)
		{
			planet_scan_resourse_place ( planet, SPICE,
									PLANT_PLAIN, COMMAN,
									PLANT_HILL, COMMAN,
									SWAMP, COMMAN,
									PLANT_SWAMP, COMMAN);
		}
	}
if (base_radioactive !=0)
	{
		for (int nnn=1;nnn <= base_radioactive;nnn++)
		{
			planet_scan_resourse_place ( planet, RADIOACTIVE,
									MOUNT, COMMAN,
									HILL, RARE,
									PLANT_HILL, RARE,
									PLAIN, VERY_RARE);
		}
	}
if (base_chemical !=0)
	{
		for (int nnn=1;nnn <= base_chemical;nnn++)
		{
			planet_scan_resourse_place ( planet, CHEMICAL,
									PLAIN, COMMAN,
									HILL, RARE,
									PLANT_PLAIN, COMMAN,
									SWAMP, RARE);
		}
	}
if (base_hyper_steel !=0)
	{
		for (int nnn=1;nnn <= base_hyper_steel;nnn++)
		{
			planet_scan_resourse_place ( planet, HYPER_STEEL,
									MOUNT, COMMAN,
									HILL, RARE,
									PLANT_HILL, RARE,
									NONE, NONE);
		}
	}

dice=(random(100)+1);

if (dice>80)
{
	base_gold =1;
}
if (dice>96)
{
	base_gold =2;
}
if (dice>99)
{
	base_gold =3;
}

if (base_gold !=0)
	{
		for (int nnn=1;nnn <= base_gold;nnn++)
		{
			planet_scan_resourse_place ( planet, GOLD,
									MOUNT, COMMAN,
									HILL, RARE,
									PLANT_HILL, RARE,
									NONE, NONE);
		}
	}
}

