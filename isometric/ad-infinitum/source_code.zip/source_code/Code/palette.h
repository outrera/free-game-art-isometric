int palettes()
{
	//    PALETTEENTRY        ape;
    PALETTEENTRY        ape[256];
    // Setup our palette.
    // We'll leave entries 0 and 256 alone, and set
    // all the others to zero.
    int i;
    for ( i = 1; i < 255; i++ )
    {
        ape[i].peRed   = ( BYTE )(i);
        ape[i].peGreen = ( BYTE )(i);
        ape[i].peBlue  = ( BYTE )(i);
        ape[i].peFlags = ( BYTE )0;
    }

    // OUTDOOR TERRAINE

    //  greens
     for ( i = 0; i <=7 ; i++ )
    {
        ape[i+1].peRed   = ( BYTE )(0+i*4);
        ape[i+1].peGreen = ( BYTE )(180-i*8);
        ape[i+1].peBlue  = ( BYTE )(0+i*4);
        ape[i+1].peFlags = ( BYTE )0;
    }

     // yellow greens
     for ( i = 0; i <=15 ; i++ )
    {
        ape[i+8].peRed   = ( BYTE )(154-i*8);
        ape[i+8].peGreen = ( BYTE )(213-i*8);
        ape[i+8].peBlue  = ( BYTE )(0+i*4);
        ape[i+8].peFlags = ( BYTE )0;
    }

    // dark yellow greens
     for ( i = 0; i <=7 ; i++ )
    {
        ape[i+24].peRed   = ( BYTE )(84-i*4);
        ape[i+24].peGreen = ( BYTE )(120-i*8);
        ape[i+24].peBlue  = ( BYTE )(0+i*4);
        ape[i+24].peFlags = ( BYTE )0;
    }

     //  browns
     for ( i = 0; i <=7 ; i++ )
    {
        ape[i+32].peRed   = ( BYTE )(144-i*8);
        ape[i+32].peGreen = ( BYTE )(120-i*8);
        ape[i+32].peBlue  = ( BYTE )(96-i*8);
        ape[i+32].peFlags = ( BYTE )0;
    }

     //  browns, sand
     for ( i = 0; i <=7 ; i++ )
    {
        ape[i+40].peRed   = ( BYTE )(152+i*8);
        ape[i+40].peGreen = ( BYTE )(128+i*8);
        ape[i+40].peBlue  = ( BYTE )(104+i*8);
        ape[i+40].peFlags = ( BYTE )0;
    }

     // yellow
     for ( i = 0; i <=7 ; i++ )
    {
        ape[i+48].peRed   = ( BYTE )(213-i*12);
        ape[i+48].peGreen = ( BYTE )(213-i*4);
        ape[i+48].peBlue  = ( BYTE )(0+i*12);
        ape[i+48].peFlags = ( BYTE )0;
    }

     // brown-field
     for ( i = 0; i <=3 ; i++ )
    {
        ape[i+56].peRed   = ( BYTE )(144-i*24);
        ape[i+56].peGreen = ( BYTE )(120-i*24);
        ape[i+56].peBlue  = ( BYTE )(96-i*24);
        ape[i+56].peFlags = ( BYTE )0;
    }

     // marsh bleu green
     for ( i = 0; i <=3 ; i++ )
    {
        ape[i+60].peRed   = ( BYTE )(0);
        ape[i+60].peGreen = ( BYTE )(215-i*28);
        ape[i+60].peBlue  = ( BYTE )(253-i*32);
        ape[i+60].peFlags = ( BYTE )0;
    }

     // blue water river
     for ( i = 0; i <=7 ; i++ )
    {
        ape[i+64].peRed   = ( BYTE )(220-i*16);
        ape[i+64].peGreen = ( BYTE )(240-i*8);
        ape[i+64].peBlue  = ( BYTE )(255);
        ape[i+64].peFlags = ( BYTE )0;
    }

    // blue water sea
     for ( i = 0; i <=7 ; i++ )
    {
        ape[i+72].peRed   = ( BYTE )(0+i*8);
        ape[i+72].peGreen = ( BYTE )(43+i*8);
        ape[i+72].peBlue  = ( BYTE )(213-i*16);
        ape[i+72].peFlags = ( BYTE )0;
    }

    // Buildings, sprites, & others

    // reds
     for ( i = 0; i <=7 ; i++ )
    {
        ape[i+96].peRed   = ( BYTE )(213-i*20);
        ape[i+96].peGreen = ( BYTE )(0);
        ape[i+96].peBlue  = ( BYTE )(5);
        ape[i+96].peFlags = ( BYTE )0;
    }

    // brown 1
     for ( i = 0; i <=3 ; i++ )
    {
        ape[i+104].peRed   = ( BYTE )(168-i*32);
        ape[i+104].peGreen = ( BYTE )(94-i*16);
        ape[i+104].peBlue  = ( BYTE )(45-i*8);
        ape[i+104].peFlags = ( BYTE )0;
    }

    // brown 2
    for ( i = 0; i <=3 ; i++ )
    {
        ape[i+108].peRed   = ( BYTE )(140-i*32);
        ape[i+108].peGreen = ( BYTE )(113-i*16);
        ape[i+108].peBlue  = ( BYTE )(74-i*8);
        ape[i+108].peFlags = ( BYTE )0;
    }

    // brown 3
    for ( i = 0; i <=3 ; i++ )
    {
        ape[i+112].peRed   = ( BYTE )(135-i*32);
        ape[i+112].peGreen = ( BYTE )(78-i*16);
        ape[i+112].peBlue  = ( BYTE )(54-i*8);
        ape[i+112].peFlags = ( BYTE )0;
    }

    // Yellow
    for ( i = 0; i <=3 ; i++ )
    {
        ape[i+116].peRed   = ( BYTE )(255-i*32);
        ape[i+116].peGreen = ( BYTE )(255-i*32);
        ape[i+116].peBlue  = ( BYTE )(0);
        ape[i+116].peFlags = ( BYTE )0;
    }

    // Orange
    for ( i = 0; i <=3 ; i++ )
    {
        ape[i+120].peRed   = ( BYTE )(255-i*32);
        ape[i+120].peGreen = ( BYTE )(128-i*16);
        ape[i+120].peBlue  = ( BYTE )(0);
        ape[i+120].peFlags = ( BYTE )0;
    }

    // Pink Purple
    for ( i = 0; i <=3 ; i++ )
    {
        ape[i+124].peRed   = ( BYTE )(147-i*24);
        ape[i+124].peGreen = ( BYTE )(0);
        ape[i+124].peBlue  = ( BYTE )(217-i*32);
        ape[i+124].peFlags = ( BYTE )0;
    }

    // Green 1
    for ( i = 0; i <=3 ; i++ )
    {
        ape[i+128].peRed   = ( BYTE )(0);
        ape[i+128].peGreen = ( BYTE )(230-i*32);
        ape[i+128].peBlue  = ( BYTE )(60-i*8);
        ape[i+128].peFlags = ( BYTE )0;
    }

    // Green 2
    for ( i = 0; i <=3 ; i++ )
    {
        ape[i+132].peRed   = ( BYTE )(152-i*24);
        ape[i+132].peGreen = ( BYTE )(167-i*24);
        ape[i+132].peBlue  = ( BYTE )(50-i*6);
        ape[i+132].peFlags = ( BYTE )0;
    }

    // Bleu 1
    for ( i = 0; i <=3 ; i++ )
    {
        ape[i+136].peRed   = ( BYTE )(64-i*4);
        ape[i+136].peGreen = ( BYTE )(165-i*16);
        ape[i+136].peBlue  = ( BYTE )(255-i*32);
        ape[i+136].peFlags = ( BYTE )0;
    }
    // Bleu 2
    for ( i = 0; i <=3 ; i++ )
    {
        ape[i+140].peRed   = ( BYTE )(0);
        ape[i+140].peGreen = ( BYTE )(74-i*8);
        ape[i+140].peBlue  = ( BYTE )(227-i*24);
        ape[i+140].peFlags = ( BYTE )0;
    }

    // Grey
    for ( i = 0; i <=15 ; i++ )
    {
        ape[i+144].peRed   = ( BYTE )(255-i*16);
        ape[i+144].peGreen = ( BYTE )(255-i*16);
        ape[i+144].peBlue  = ( BYTE )(255-i*16);
        ape[i+144].peFlags = ( BYTE )0;
    }


     // tranperant 1#
    		ape[254].peRed   = ( BYTE )(255);
        ape[254].peGreen = ( BYTE )(128);
        ape[254].peBlue  = ( BYTE )(255);
        ape[254].peFlags = ( BYTE )0;
     // tranperant 2#
    		ape[253].peRed   = ( BYTE )(128);
        ape[253].peGreen = ( BYTE )(255);
        ape[253].peBlue  = ( BYTE )(220);
        ape[253].peFlags = ( BYTE )0;

   lpDD->CreatePalette( DDPCAPS_8BIT,
                    ape, &lpDDPal, NULL );

   lpDDSPrimary->SetPalette( lpDDPal );

   return 0;

}
