
void Creat_Worlds (void)
{
	/////////////////icons///////////
	ddsd.dwHeight = 30;
	ddsd.dwWidth =  630;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffIcons1, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen icons.\n",1 );
	}
	/////////////////icons factions///////////
	ddsd.dwHeight = 30;
	ddsd.dwWidth =  300;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffFactions1, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen lpDDSOffFactions1.\n",1 );
	}
	/////////////////plaine///////////
	ddsd.dwHeight = 60;
	ddsd.dwWidth =  120;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffPlain, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen PLAIN.\n",1 );
	}

	/////desert plain
		if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffPlain_Desert1, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen PLAIN desert1.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffPlain_Desert2, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen PLAIN desert2.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffPlain_Desert3, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen PLAIN desert3.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffPlain_Desert4, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen PLAIN desert4.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffPlain_Desert5, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen PLAIN desert5.\n",1 );
	}
	/////
	/////desert dry plain
		if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffPlain_Dry1, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen PLAIN desert1.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffPlain_Dry2, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen PLAIN desert2.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffPlain_Dry3, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen PLAIN desert3.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffPlain_Dry4, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen PLAIN desert4.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffPlain_Dry5, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen PLAIN desert5.\n",1 );
	}
	/////
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffDunes_Desert1, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen dunes desert.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffDunes_Desert2, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen dunes desert.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffDunes_Desert3, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen dunes desert.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffDunes_Desert4, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen dunes desert.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffDunes_Desert5, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen dunes desert.\n",1 );
	}
	/////
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRocky_Plain_Desert1, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen rockyplain desert.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRocky_Plain_Desert2, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen rockyplain desert.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRocky_Plain_Desert3, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen rockyplain desert.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRocky_Plain_Desert4, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen rockyplain desert.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRocky_Plain_Desert5, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen rockyplain desert.\n",1 );
	}

	//////
		if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffPlain_Ice, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen PLAIN ice.\n",1 );
	}
		if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffPlain_Lava, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen PLAIN lava.\n",1 );
	}
		if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffPlain_Moon, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen PLAIN moon.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffPlain_Exotic, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen PLAIN exotic.\n",1 );
	}
	////////////////swamp/////////////
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffSwamp, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen swamp.\n",1 );
	}
	////////////////sea/////////////
	/////new test to see if can creat a zoomed sprite to speed up zoom map
	ddsd.dwHeight = 60/ZooM;
	ddsd.dwWidth =  120/ZooM;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffSea, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen SEA.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffDeep_Sea, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen deep SEA.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffShalow_Sea, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen shalow SEA.\n",1 );
	}
	///old system///
	/*
	ddsd.dwHeight = 60;
	ddsd.dwWidth =  120;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffSea, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen SEA.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffDeep_Sea, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen deep SEA.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffShalow_Sea, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen shalow SEA.\n",1 );
	}
	*/
	////////////////new sea/////////////
	ddsd.dwHeight = 60;
	ddsd.dwWidth =  120;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffSea1, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen SEA1.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffSea2, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen SEA2.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffSea3, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen SEA3.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffSea4, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen SEA4.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffSea5, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen SEA5.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffSea6, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen SEA6.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffSea7, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen SEA7.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffSea8, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen SEA8.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffSea9, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen SEA9.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffSea10, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen SEA10.\n",1 );
	}
	////
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffSea_deep1, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen SEA1.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffSea_deep2, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen SEA2.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffSea_deep3, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen SEA3.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffSea_deep4, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen SEA4.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffSea_deep5, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen SEA5.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffSea_deep6, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen SEA6.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffSea_deep7, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen SEA7.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffSea_deep8, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen SEA8.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffSea_deep9, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen SEA9.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffSea_deep10, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen SEA10.\n",1 );
	}
	/////////////////desert sea////////////
	ddsd.dwHeight = 60;
	ddsd.dwWidth =  120;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffSea_desert1, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen SEAdesert.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffSea_desert2, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen SEAdesert.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffSea_desert3, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen SEAdesert.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffSea_desert4, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen SEAdesert.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffSea_desert5, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen SEAdesert.\n",1 );
	}

	/////////////////ice sea////////////
	ddsd.dwHeight = 60;
	ddsd.dwWidth =  120;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffSea_ice_1, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen SEA ice1.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffSea_ice_2, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen SEA ice2.\n",1 );
	}

	/////////////////lava sea////////////
	ddsd.dwHeight = 60;
	ddsd.dwWidth =  120;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffSea_lava, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen SEAlava.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffDeep_Sea_lava, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen deep SEAlava.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffShalow_Sea_lava, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen shalow SEAlava.\n",1 );
	}
	/////////////////exotic sea////////////
	ddsd.dwHeight = 60;
	ddsd.dwWidth =  120;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffSea_exotic, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen SEA_exotic.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffDeep_Sea_exotic, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen deep SEA_exotic.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffShalow_Sea_exotic, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen shalow SEA_exotic.\n",1 );
	}
	//////////////plants//////////////
	ddsd.dwHeight = 120;
	ddsd.dwWidth =  120;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffTrees, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen TREES.\n",1 );
	}
	////
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffHill_Trees, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen hill trees.\n",1 );
	}
	////
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffSwamp_Trees, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen hill trees.\n",1 );
	}
	////
	ddsd.dwHeight = 120;
	ddsd.dwWidth =  120;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffTrees_a_1, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen TREES_a_1.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffTrees_a_2, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen TREES_a_2.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffTrees_a_3, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen TREES_a_3.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffTrees_a_4, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen TREES_a_4.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffTrees_a_5, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen TREES_a_5.\n",1 );
	}

	////
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffDesert_Trees1, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen TREES.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffDesert_Trees2, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen TREES.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffDesert_Trees3, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen TREES.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffDesert_Trees4, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen TREES.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffDesert_Trees5, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen TREES.\n",1 );
	}
	///////////////////hill//////////
	ddsd.dwHeight = 80;
	ddsd.dwWidth =  120;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffHill1, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen HILL1.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffHill2, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen HILL2.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffHill3, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen HILL3.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffHill4, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen HILL4.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffHill5, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen HILL5.\n",1 );
	}
	///////
	ddsd.dwHeight = 120;
	ddsd.dwWidth =  120;
		if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffHill_Ice1, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen HILLice.\n",1 );
	}
		if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffHill_Ice2, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen HILLice2.\n",1 );
	}
		if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffHill_Ice3, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen HILLice3.\n",1 );
	}
		if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffHill_Ice4, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen HILLice4.\n",1 );
	}
		if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffHill_Ice5, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen HILLice5.\n",1 );
	}
	///////
		if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffHill_Desert1, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen HILLdesert.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffHill_Desert2, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen HILLdesert.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffHill_Desert3, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen HILLdesert.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffHill_Desert4, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen HILLdesert.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffHill_Desert5, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen HILLdesert.\n",1 );
	}
	/////////
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRocky_Hill_Desert1, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen rockyHILLdesert.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRocky_Hill_Desert2, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen rockyHILLdesert.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRocky_Hill_Desert3, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen rockyHILLdesert.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRocky_Hill_Desert4, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen rockyHILLdesert.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRocky_Hill_Desert5, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen rockyHILLdesert.\n",1 );
	}
	///////
		if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffHill_Lava, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen HILLlava.\n",1 );
	}
		if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffHill_Moon, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen HILLmoon.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffHill_Exotic, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen HILLexotic.\n",1 );
	}
	///////////////////mountains/////
	ddsd.dwHeight = 120;
	ddsd.dwWidth =  120;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffMount1, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen mount1.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffMount2, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen mount2.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffMount3, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen mount3.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffMount4, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen mount4.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffMount5, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen mount5.\n",1 );
	}
	////
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffMount_Desert1, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen mount.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffMount_Desert2, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen mount.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffMount_Desert3, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen mount.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffMount_Desert4, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen mount.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffMount_Desert5, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen mount.\n",1 );
	}
	/////
		if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffMount_Ice, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen mount.\n",1 );
	}
		if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffMount_Lava, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen mount.\n",1 );
	}
		if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffMount_Moon, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen mountmoon.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffMount_Exotic, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen mountexotic.\n",1 );
	}
	/////////////roads/////////////
	ddsd.dwHeight = 60;
	ddsd.dwWidth =  120;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRoad_E, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen road.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRoad_W, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen road.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRoad_W_NE, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen road.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRoad_NE, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen road.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRoad_NW, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen road.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRoad_NW_SW, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen road.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRoad_SE, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen road.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRoad_SW, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen road.\n",1 );
	}
	/////////////rivers/////////////
	ddsd.dwHeight = 60;
	ddsd.dwWidth =  120;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRiver_E, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen river.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRiver_W, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen river.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRiver_NE, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen river.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRiver_NW, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen river.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRiver_SE, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen river.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRiver_SW, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen river.\n",1 );
	}
	/////////////swampt rivers/////////////
	ddsd.dwHeight = 60;
	ddsd.dwWidth =  120;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRiver_E_swamp, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen river swamp.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRiver_W_swamp, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen river swamp.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRiver_NE_swamp, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen river swamp.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRiver_NW_swamp, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen river swamp.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRiver_SE_swamp, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen river swamp.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRiver_SW_swamp, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen river swamp.\n",1 );
	}
	/////////////desert rivers/////////////
	ddsd.dwHeight = 60;
	ddsd.dwWidth =  120;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRiver_E_desert, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen river desert.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRiver_W_desert, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen river desert.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRiver_NE_desert, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen river desert.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRiver_NW_desert, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen river desert.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRiver_SE_desert, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen river desert.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRiver_SW_desert, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen river desert.\n",1 );
	}
	////////////lava rivers/////////////
	ddsd.dwHeight = 60;
	ddsd.dwWidth =  120;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRiver_E_lava, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen river.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRiver_W_lava, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen river.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRiver_NE_lava, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen river.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRiver_NW_lava, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen river.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRiver_SE_lava, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen river.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRiver_SW_lava, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen river.\n",1 );
	}
	////////////exotic rivers/////////////
	ddsd.dwHeight = 60;
	ddsd.dwWidth =  120;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRiver_E_exotic, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen river.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRiver_W_exotic, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen river.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRiver_NE_exotic, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen river.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRiver_NW_exotic, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen river.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRiver_SE_exotic, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen river.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRiver_SW_exotic, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen river.\n",1 );
	}
	//////////////resources//////////////
	ddsd.dwHeight = 60;
	ddsd.dwWidth =  120;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRes_metal, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen resources.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRes_oil, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen resources.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRes_spice, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen resources.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRes_trace, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen resources.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRes_gem, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen resources.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRes_radioactive, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen resources.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRes_chemy, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen resources.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRes_hyper_steel, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen resources.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffRes_gold, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen resources.\n",1 );
	}
	////////////structures large///////////////////
	ddsd.dwHeight = 80;
	ddsd.dwWidth =  120;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffStruct_town1, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen town1.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffStruct_town2, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen town2.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffStruct_town3, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen town3.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffStruct_town4, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen town4.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffStruct_town5, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen town5.\n",1 );
	}
	//
	ddsd.dwHeight = 120;
	ddsd.dwWidth =  120;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffStruct_town_ice, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen town ice.\n",1 );
	}
	///
	ddsd.dwHeight = 120;
	ddsd.dwWidth =  120;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffStruct_town_desert1, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen town desert.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffStruct_town_desert2, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen town desert.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffStruct_town_desert3, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen town desert.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffStruct_town_desert4, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen town desert.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffStruct_town_desert5, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen town desert.\n",1 );
	}
	///
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffStruct_church, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen church.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffStruct_palace, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen palace.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffStruct_steel, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen steel.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffStruct_uni, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen university.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffStruct_farm_enc, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen enclosed farm.\n",1 );
	}
	////////////structures smalle///////////////////
	ddsd.dwHeight = 60;
	ddsd.dwWidth =  120;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffStruct_chemy, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen steel.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffStruct_elec, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen steel.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffStruct_factory, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen steel.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffStruct_farm, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen steel.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffStruct_farm_land, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen steel.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffStruct_mine, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen steel.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffStruct_well, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen steel.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffStruct_offshore_well, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen steel.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffStruct_ruins, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen steel.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffStruct_starport, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen steel.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffStruct_fort, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen fort.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffStruct_barracks, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen barracks.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffStruct_lab, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen lab.\n",1 );
	}

	//////coasts///////
	ddsd.dwHeight = 60;
	ddsd.dwWidth =  120;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffCoast_a_1, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen coast.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffCoast_b_1, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen coast.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffCoast_a_2, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen coast.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffCoast_b_2, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen coast.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffCoast_a_3, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen coast.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffCoast_b_3, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen coast.\n",1 );
	}
	//////ice coasts///////
	ddsd.dwHeight = 60;
	ddsd.dwWidth =  120;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffCoast_a_1_ice, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen coast_ice.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffCoast_b_1_ice, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen coast_ice.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffCoast_a_2_ice, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen coast_ice.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffCoast_b_2_ice, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen coast_ice.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffCoast_a_3_ice, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen coast_ice.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffCoast_b_3_ice, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen coast_ice.\n",1 );
	}
	////desert coasts///
	ddsd.dwHeight = 60;
	ddsd.dwWidth =  120;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffCoast_a_1_desert, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen coast.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffCoast_b_1_desert, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen coast.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffCoast_a_2_desert, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen coast.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffCoast_b_2_desert, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen coast.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffCoast_a_3_desert, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen coast.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffCoast_b_3_desert, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen coast.\n",1 );
	}
	//////lava coasts///////
	ddsd.dwHeight = 60;
	ddsd.dwWidth =  120;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffCoast_a_1_lava, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen coast.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffCoast_b_1_lava, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen coast.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffCoast_a_2_lava, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen coast.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffCoast_b_2_lava, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen coast.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffCoast_a_3_lava, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen coast.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffCoast_b_3_lava, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen coast.\n",1 );
	}
	//////exotic coasts///////
	ddsd.dwHeight = 60;
	ddsd.dwWidth =  120;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffCoast_a_1_exotic, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen coast.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffCoast_b_1_exotic, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen coast.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffCoast_a_2_exotic, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen coast.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffCoast_b_2_exotic, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen coast.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffCoast_a_3_exotic, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen coast.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffCoast_b_3_exotic, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen coast.\n",1 );
	}
	////atmosphere///
	ddsd.dwHeight = 360;
	ddsd.dwWidth =  9;
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffAtmos1, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen atmos.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffAtmos2, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen atmos.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffAtmos3, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen atmos.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffAtmos4, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen atmos.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffAtmos5, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen atmos.\n",1 );
	}
	if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffAtmos6, NULL ) ) )
	{
		debugfile (  "Couldn't create offscreen atmos.\n",1 );
	}

	////////////////////////////////////////////////////////////////////////
	/////////////#############load#############///////////////////
	///////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////
	 if ( !LoadMyImage( lpDDSOffIcons1, "grafix/town_icons.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen icons.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffFactions1, "grafix/faction_border.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen factions.\n",1 );
	}
	//////////////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////////
		 if ( !LoadMyImage( lpDDSOffPlain, "grafix/plain.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen plain.\n",1 );
	}
	///
	if ( !LoadMyImage( lpDDSOffPlain_Desert1, "grafix/plain_desert1.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen plain desert1.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffPlain_Desert2, "grafix/plain_desert2.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen plain desert2.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffPlain_Desert3, "grafix/plain_desert3.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen plain desert3.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffPlain_Desert4, "grafix/plain_desert4.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen plain desert4.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffPlain_Desert5, "grafix/plain_desert5.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen plain desert5.\n",1 );
	}
	///
	if ( !LoadMyImage( lpDDSOffPlain_Dry1, "grafix/plain_dry1.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen plain desert1.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffPlain_Dry2, "grafix/plain_dry2.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen plain desert2.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffPlain_Dry3, "grafix/plain_dry3.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen plain desert3.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffPlain_Dry4, "grafix/plain_dry4.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen plain desert4.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffPlain_Dry5, "grafix/plain_dry5.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen plain desert5.\n",1 );
	}
	///
	if ( !LoadMyImage( lpDDSOffDunes_Desert1, "grafix/dune_desert1.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen dune desert1.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffDunes_Desert2, "grafix/dune_desert2.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen dune desert2.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffDunes_Desert3, "grafix/dune_desert3.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen dune desert3.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffDunes_Desert4, "grafix/dune_desert4.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen dune desert4.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffDunes_Desert5, "grafix/dune_desert5.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen dune desert5.\n",1 );
	}
	////
	if ( !LoadMyImage( lpDDSOffRocky_Plain_Desert1, "grafix/rocky_plain_desert1.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen rocky plain desert1.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffRocky_Plain_Desert2, "grafix/rocky_plain_desert2.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen rocky plain desert2.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffRocky_Plain_Desert3, "grafix/rocky_plain_desert3.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen rocky plain desert3.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffRocky_Plain_Desert4, "grafix/rocky_plain_desert4.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen rocky plain desert4.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffRocky_Plain_Desert5, "grafix/rocky_plain_desert5.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen rocky plain desert5.\n",1 );
	}
	///
		 if ( !LoadMyImage( lpDDSOffPlain_Ice, "grafix/plain_ice.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen plain ice.\n",1 );
	}
		 if ( !LoadMyImage( lpDDSOffPlain_Lava, "grafix/plain_lava.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen plain lava.\n",1 );
	}
		if ( !LoadMyImage( lpDDSOffPlain_Moon, "grafix/plain_moon.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen plain lava.\n",1 );
	}
		if ( !LoadMyImage( lpDDSOffPlain_Exotic, "grafix/plain_exotic.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen plain exotic.\n",1 );
	}
	///////
	 if ( !LoadMyImage( lpDDSOffSwamp, "grafix/swamp.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen swamp.\n",1 );
	}
	/////////////
	/*
		 if ( !LoadMyImage( lpDDSOffSea, "grafix/sea.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen sea.\n",1 );
	}

			 if ( !LoadMyImage( lpDDSOffDeep_Sea, "grafix/deep_sea.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen sea.\n",1 );
	}

			 if ( !LoadMyImage( lpDDSOffShalow_Sea, "grafix/shalow_sea.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen sea.\n",1 );
	}
	*/
	//////////new sea load///////////
	if ( !LoadMyImage( lpDDSOffSea1, "grafix/sea1.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen sea1.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffSea2, "grafix/sea2.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen sea2.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffSea3, "grafix/sea3.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen sea3.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffSea4, "grafix/sea4.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen sea4.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffSea5, "grafix/sea5.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen sea5.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffSea6, "grafix/sea6.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen sea6.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffSea7, "grafix/sea7.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen sea7.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffSea8, "grafix/sea8.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen sea8.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffSea9, "grafix/sea9.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen sea9.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffSea10, "grafix/sea10.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen sea10.\n",1 );
	}
	//

	//
	if ( !LoadMyImage( lpDDSOffSea_deep1, "grafix/sea_deep1.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen sea1.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffSea_deep2, "grafix/sea_deep2.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen sea2.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffSea_deep3, "grafix/sea_deep3.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen sea3.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffSea_deep4, "grafix/sea_deep4.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen sea4.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffSea_deep5, "grafix/sea_deep5.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen sea5.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffSea_deep6, "grafix/sea_deep6.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen sea6.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffSea_deep7, "grafix/sea_deep7.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen sea7.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffSea_deep8, "grafix/sea_deep8.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen sea8.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffSea_deep9, "grafix/sea_deep9.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen sea9.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffSea_deep10, "grafix/sea_deep10.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen sea10.\n",1 );

	}

	////////////////////////under test/////////////////
	///////////////////turn on at draw world///////////

	RECT			rcRect_120x60    ;
	RECT			rcRectGet_120x60 ;

		rcRectGet_120x60.bottom = 	120;             // default get terraines
		rcRectGet_120x60.right = 	60;
		rcRectGet_120x60.left=		0;
		rcRectGet_120x60.top=		0;

		rcRect_120x60.left = 0;                     // default place terrains
		rcRect_120x60.top =  0;
		rcRect_120x60.right =(120.0/ZooM)-2;
		rcRect_120x60.bottom =(60.0/ZooM)-2;

		lpDDSOffSea->Blt( &rcRect_120x60 , lpDDSOffSea1, &rcRectGet_120x60,
																	   DDBLT_WAIT,
																	     NULL );

		lpDDSOffDeep_Sea->Blt( &rcRect_120x60 , lpDDSOffSea_deep1, &rcRectGet_120x60,
																	   DDBLT_WAIT , NULL );

		lpDDSOffShalow_Sea->Blt( &rcRect_120x60 , lpDDSOffSea1, &rcRectGet_120x60,
																	   DDBLT_WAIT, NULL );

		debugfile ("rcRect_120x60.righ\n", rcRect_120x60.right);
        debugfile ("rcRect_120x60.bottom\n", rcRect_120x60.bottom );

    //////////////////////////////////////////////////////////////////
	/////////////////////////////////
	if ( !LoadMyImage( lpDDSOffSea_desert1, "grafix/sea_desert1.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen sea_desert1.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffSea_desert2, "grafix/sea_desert2.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen sea_desert2.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffSea_desert3, "grafix/sea_desert3.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen sea_desert3.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffSea_desert4, "grafix/sea_desert4.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen sea_desert4.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffSea_desert5, "grafix/sea_desert5.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen sea_desert5.\n",1 );
	}
	/////////////////////////////////
	if ( !LoadMyImage( lpDDSOffSea_ice_1, "grafix/sea_ice_1.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen sea_ice.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffSea_ice_2, "grafix/sea_ice_2.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen sea_ice.\n",1 );
	}
	/////////////////////////////////
	if ( !LoadMyImage( lpDDSOffSea_lava, "grafix/lava2.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen sea_lava.\n",1 );
	}

			 if ( !LoadMyImage( lpDDSOffDeep_Sea_lava, "grafix/lava3.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen sea_lava.\n",1 );
	}

			 if ( !LoadMyImage( lpDDSOffShalow_Sea_lava, "grafix/lava1.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen sea_lava.\n",1 );
	}
	///////////
	if ( !LoadMyImage( lpDDSOffSea_exotic, "grafix/sea_exotic.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen sea_x.\n",1 );
	}

			 if ( !LoadMyImage( lpDDSOffDeep_Sea_exotic, "grafix/sea_deep_exotic.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen sea_x.\n",1 );
	}

			 if ( !LoadMyImage( lpDDSOffShalow_Sea_exotic, "grafix/shalow_sea_exotic.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen sea_x.\n",1 );
	}
	///////////
		 if ( !LoadMyImage( lpDDSOffTrees, "grafix/trees.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen trees.\n",1 );
	}
	///////////
	if ( !LoadMyImage( lpDDSOffHill_Trees, "grafix/hill_trees.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen trees.\n",1 );
	}
	///////////
	if ( !LoadMyImage( lpDDSOffSwamp_Trees, "grafix/swamp_trees.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen trees_swamp.\n",1 );
	}
	///////////
	if ( !LoadMyImage( lpDDSOffTrees_a_1, "grafix/trees_a_1.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen trees_a_1.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffTrees_a_2, "grafix/trees_a_2.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen trees_a_2.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffTrees_a_3, "grafix/trees_a_3.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen trees_a_3.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffTrees_a_4, "grafix/trees_a_4.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen trees_a_4.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffTrees_a_5, "grafix/trees_a_5.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen trees_a_5.\n",1 );
	}
	//////////
	if ( !LoadMyImage( lpDDSOffDesert_Trees1, "grafix/desert_tree1.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen desert trees1.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffDesert_Trees2, "grafix/desert_tree2.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen desert trees2.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffDesert_Trees3, "grafix/desert_tree3.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen desert trees3.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffDesert_Trees4, "grafix/desert_tree4.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen desert trees4.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffDesert_Trees5, "grafix/desert_tree5.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen desert trees5.\n",1 );
	}
	///////////
	if ( !LoadMyImage( lpDDSOffHill1, "grafix/hill1.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen hill1.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffHill2, "grafix/hill2.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen hill2.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffHill3, "grafix/hill3.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen hill3.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffHill4, "grafix/hill4.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen hill4.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffHill5, "grafix/hill5.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen hill5.\n",1 );
	}
	/////////
	if ( !LoadMyImage( lpDDSOffHill_Ice1, "grafix/hill_ice1.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen hill.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffHill_Ice2, "grafix/hill_ice2.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen hill.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffHill_Ice3, "grafix/hill_ice3.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen hill.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffHill_Ice4, "grafix/hill_ice4.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen hill.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffHill_Ice5, "grafix/hill_ice5.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen hill.\n",1 );
	}
	///
	if ( !LoadMyImage( lpDDSOffHill_Desert1, "grafix/hill_desert1.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen hill1.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffHill_Desert2, "grafix/hill_desert2.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen hill2.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffHill_Desert3, "grafix/hill_desert3.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen hill3.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffHill_Desert4, "grafix/hill_desert4.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen hill4.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffHill_Desert5, "grafix/hill_desert5.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen hill5.\n",1 );
	}
	///
	if ( !LoadMyImage( lpDDSOffRocky_Hill_Desert1, "grafix/rocky_hill_desert1.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen desert rock hill1.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffRocky_Hill_Desert2, "grafix/rocky_hill_desert2.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen desert rock hill2.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffRocky_Hill_Desert3, "grafix/rocky_hill_desert3.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen desert rock hill3.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffRocky_Hill_Desert4, "grafix/rocky_hill_desert4.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen desert rock hill4.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffRocky_Hill_Desert5, "grafix/rocky_hill_desert5.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen desert rock hill5.\n",1 );
	}
	///
	if ( !LoadMyImage( lpDDSOffHill_Lava, "grafix/hill_lava.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen hilllava.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffHill_Moon, "grafix/hill_moon.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen hillmoon.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffHill_Exotic, "grafix/hill_exotic.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen hillmoon.\n",1 );
	}
	//////////
	if ( !LoadMyImage( lpDDSOffMount1, "grafix/mount1.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen hill1.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffMount2, "grafix/mount2.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen hill2.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffMount3, "grafix/mount3.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen hill3.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffMount4, "grafix/mount4.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen hill4.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffMount5, "grafix/mount5.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen hill5.\n",1 );
	}

	/////////
	if ( !LoadMyImage( lpDDSOffMount_Desert1, "grafix/mount_desert1.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen hilldesert1.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffMount_Desert2, "grafix/mount_desert2.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen hilldesert2.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffMount_Desert3, "grafix/mount_desert3.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen hilldesert3.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffMount_Desert4, "grafix/mount_desert4.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen hilldesert4.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffMount_Desert5, "grafix/mount_desert5.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen hilldesert5.\n",1 );
	}
	///////
	if ( !LoadMyImage( lpDDSOffMount_Ice, "grafix/mount_ice.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen hillice.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffMount_Lava, "grafix/mount_lava.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen hilllava.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffMount_Moon, "grafix/mount_moon.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen hillmoon.\n",1 );
	}
		if ( !LoadMyImage( lpDDSOffMount_Exotic, "grafix/mount_exotic.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen hillmoon.\n",1 );
	}
	////////////////
			 if ( !LoadMyImage( lpDDSOffRoad_E, "grafix/road_E.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen road.\n",1 );
	}

			 if ( !LoadMyImage( lpDDSOffRoad_W, "grafix/road_W.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen road.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffRoad_W_NE, "grafix/road_W_NE.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen road.\n",1 );
	}

			 if ( !LoadMyImage( lpDDSOffRoad_NE, "grafix/road_NE.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen road.\n",1 );
	}

			 if ( !LoadMyImage( lpDDSOffRoad_NW, "grafix/road_NW.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen road.\n",1 );
	}
			 if ( !LoadMyImage( lpDDSOffRoad_NW_SW, "grafix/road_NW_SW.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen road.\n",1 );
	}

			 if ( !LoadMyImage( lpDDSOffRoad_SE, "grafix/road_SE.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen road.\n",1 );
	}

			 if ( !LoadMyImage( lpDDSOffRoad_SW, "grafix/road_SW.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen road.\n",1 );
	}
	////////////////
			 if ( !LoadMyImage( lpDDSOffRiver_E, "grafix/river_E.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen river.\n",1 );
	}

			 if ( !LoadMyImage( lpDDSOffRiver_W, "grafix/river_W.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen river.\n",1 );
	}

			 if ( !LoadMyImage( lpDDSOffRiver_NE, "grafix/river_NE.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen river.\n",1 );
	}

			 if ( !LoadMyImage( lpDDSOffRiver_NW, "grafix/river_NW.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen river.\n",1 );
	}

			 if ( !LoadMyImage( lpDDSOffRiver_SE, "grafix/river_SE.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen river.\n",1 );
	}

			 if ( !LoadMyImage( lpDDSOffRiver_SW, "grafix/river_SW.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen river.\n",1 );
	}
	////////////////
			 if ( !LoadMyImage( lpDDSOffRiver_E_swamp, "grafix/swamp_river_E.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen river_swamp.\n",1 );
	}

			 if ( !LoadMyImage( lpDDSOffRiver_W_swamp, "grafix/swamp_river_W.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen river_swamp.\n",1 );
	}

			 if ( !LoadMyImage( lpDDSOffRiver_NE_swamp, "grafix/swamp_river_NE.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen river_swamp.\n",1 );
	}

			 if ( !LoadMyImage( lpDDSOffRiver_NW_swamp, "grafix/swamp_river_NW.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen river_swamp.\n",1 );
	}

			 if ( !LoadMyImage( lpDDSOffRiver_SE_swamp, "grafix/swamp_river_SE.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen river_swamp.\n",1 );
	}

			 if ( !LoadMyImage( lpDDSOffRiver_SW_swamp, "grafix/swamp_river_SW.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen river_swamp.\n",1 );
	}
	////////////////
			 if ( !LoadMyImage( lpDDSOffRiver_E_desert, "grafix/desert_river_E.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen desert_river.\n",1 );
	}

			 if ( !LoadMyImage( lpDDSOffRiver_W_desert, "grafix/desert_river_W.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen desert_river.\n",1 );
	}

			 if ( !LoadMyImage( lpDDSOffRiver_NE_desert, "grafix/desert_river_NE.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen desert_river.\n",1 );
	}

			 if ( !LoadMyImage( lpDDSOffRiver_NW_desert, "grafix/desert_river_NW.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen desert_river.\n",1 );
	}

			 if ( !LoadMyImage( lpDDSOffRiver_SE_desert, "grafix/desert_river_SE.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen desert_river.\n",1 );
	}

			 if ( !LoadMyImage( lpDDSOffRiver_SW_desert, "grafix/desert_river_SW.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen desert_river.\n",1 );
	}
	////////////////
	if ( !LoadMyImage( lpDDSOffRiver_E_lava, "grafix/lava_river_E.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen lava_river.\n",1 );
	}

			 if ( !LoadMyImage( lpDDSOffRiver_W_lava, "grafix/lava_river_W.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen lava_river.\n",1 );
	}

			 if ( !LoadMyImage( lpDDSOffRiver_NE_lava, "grafix/lava_river_NE.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen lava_river.\n",1 );
	}

			 if ( !LoadMyImage( lpDDSOffRiver_NW_lava, "grafix/lava_river_NW.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen lava_river.\n",1 );
	}

			 if ( !LoadMyImage( lpDDSOffRiver_SE_lava, "grafix/lava_river_SE.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen lava_river.\n",1 );
	}

			 if ( !LoadMyImage( lpDDSOffRiver_SW_lava, "grafix/lava_river_SW.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen lava_river.\n",1 );
	}
	//////////////
	if ( !LoadMyImage( lpDDSOffRiver_E_exotic, "grafix/exotic_river_E.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen lava_river.\n",1 );
	}

			 if ( !LoadMyImage( lpDDSOffRiver_W_exotic, "grafix/exotic_river_W.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen lava_river.\n",1 );
	}

			 if ( !LoadMyImage( lpDDSOffRiver_NE_exotic, "grafix/exotic_river_NE.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen lava_river.\n",1 );
	}

			 if ( !LoadMyImage( lpDDSOffRiver_NW_exotic, "grafix/exotic_river_NW.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen lava_river.\n",1 );
	}

			 if ( !LoadMyImage( lpDDSOffRiver_SE_exotic, "grafix/exotic_river_SE.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen lava_river.\n",1 );
	}

			 if ( !LoadMyImage( lpDDSOffRiver_SW_exotic, "grafix/exotic_river_SW.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen lava_river.\n",1 );
	}
	//////////////
	if ( !LoadMyImage( lpDDSOffRes_metal, "grafix/res_metal.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen resources.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffRes_oil, "grafix/res_oil.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen resources.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffRes_trace, "grafix/res_trace.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen resources.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffRes_gem, "grafix/res_gem.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen resources.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffRes_spice, "grafix/res_spice.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen resources.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffRes_radioactive, "grafix/res_radioactive.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen resources.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffRes_chemy, "grafix/res_chemy.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen resources.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffRes_hyper_steel, "grafix/res_hyper_metal.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen resources.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffRes_gold, "grafix/res_gold.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen resources.\n",1 );
	}
	/////////
	if ( !LoadMyImage( lpDDSOffStruct_town1, "grafix/struct_town1.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen town.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffStruct_town2, "grafix/struct_town2.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen town.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffStruct_town3, "grafix/struct_town3.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen town.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffStruct_town4, "grafix/struct_town4.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen town.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffStruct_town5, "grafix/struct_town5.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen town.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffStruct_town_ice, "grafix/struct_town_ice.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen town ice.\n",1 );
	}
	/////////////
	if ( !LoadMyImage( lpDDSOffStruct_town_desert1, "grafix/struct_town_desert1.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen town desert1.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffStruct_town_desert2, "grafix/struct_town_desert2.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen town desert2.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffStruct_town_desert3, "grafix/struct_town_desert3.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen town desert3.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffStruct_town_desert4, "grafix/struct_town_desert4.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen town desert4.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffStruct_town_desert5, "grafix/struct_town_desert5.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen town desert5.\n",1 );
	}
	////////
	if ( !LoadMyImage( lpDDSOffStruct_chemy, "grafix/struct_chemy.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen chemy.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffStruct_steel, "grafix/struct_steel.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen steel.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffStruct_elec, "grafix/struct_elec.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen elec.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffStruct_church, "grafix/struct_church.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen church.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffStruct_palace, "grafix/struct_palace.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen palace.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffStruct_ruins, "grafix/struct_ruins.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen ruins.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffStruct_well, "grafix/struct_well.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen well.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffStruct_offshore_well, "grafix/struct_offshore_well.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen well.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffStruct_mine, "grafix/struct_mine.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen mine.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffStruct_farm, "grafix/struct_farm.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen farm.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffStruct_farm_land, "grafix/struct_farm_land.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen farm land.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffStruct_factory, "grafix/struct_factory.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen factory.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffStruct_starport, "grafix/struct_starport.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen starport.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffStruct_fort, "grafix/struct_fort.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen fort.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffStruct_barracks, "grafix/struct_barracks.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen barracks.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffStruct_uni, "grafix/struct_uni.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen uni.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffStruct_lab, "grafix/struct_lab.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen lab.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffStruct_farm_enc, "grafix/struct_farm_enc.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen farm enc.\n",1 );
	}
	////
	if ( !LoadMyImage( lpDDSOffCoast_a_1, "grafix/Coast_a_1.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen coast.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffCoast_b_1, "grafix/Coast_b_1.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen coast.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffCoast_a_2, "grafix/Coast_a_2.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen coast.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffCoast_b_2, "grafix/Coast_b_2.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen coast.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffCoast_a_3, "grafix/Coast_a_3.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen coast.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffCoast_b_3, "grafix/Coast_b_3.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen coast.\n",1 );
	}
	////
	////
	if ( !LoadMyImage( lpDDSOffCoast_a_1_ice, "grafix/ice_Coast_a_1.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen coast_ice.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffCoast_b_1_ice, "grafix/ice_Coast_b_1.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen coast_ice.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffCoast_a_2_ice, "grafix/ice_Coast_a_2.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen coast_ice.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffCoast_b_2_ice, "grafix/ice_Coast_b_2.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen coast_ice.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffCoast_a_3_ice, "grafix/ice_Coast_a_3.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen coast_ice.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffCoast_b_3_ice, "grafix/ice_Coast_b_3.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen coast_ice.\n",1 );
	}
	////
	if ( !LoadMyImage( lpDDSOffCoast_a_1_desert, "grafix/desert_coast_a_1.bmp" ) )
	{
		debugfile (  "Couldn't load offscreen coast.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffCoast_b_1_desert, "grafix/desert_coast_b_1.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen coast.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffCoast_a_2_desert, "grafix/desert_coast_a_2.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen coast.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffCoast_b_2_desert, "grafix/desert_coast_b_2.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen coast.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffCoast_a_3_desert, "grafix/desert_coast_a_3.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen coast.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffCoast_b_3_desert, "grafix/desert_coast_b_3.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen coast.\n",1 );
	}
	////
	if ( !LoadMyImage( lpDDSOffCoast_a_1_lava, "grafix/lava_coast_a_1.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen coast.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffCoast_b_1_lava, "grafix/lava_coast_b_1.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen coast.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffCoast_a_2_lava, "grafix/lava_coast_a_2.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen coast.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffCoast_b_2_lava, "grafix/lava_coast_b_2.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen coast.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffCoast_a_3_lava, "grafix/lava_coast_a_3.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen coast.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffCoast_b_3_lava, "grafix/lava_coast_b_3.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen coast.\n",1 );
	}
	////
	if ( !LoadMyImage( lpDDSOffCoast_a_1_exotic, "grafix/exotic_coast_a_1.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen coast.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffCoast_b_1_exotic, "grafix/exotic_coast_b_1.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen coast.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffCoast_a_2_exotic, "grafix/exotic_coast_a_2.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen coast.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffCoast_b_2_exotic, "grafix/exotic_coast_b_2.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen coast.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffCoast_a_3_exotic, "grafix/exotic_coast_a_3.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen coast.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffCoast_b_3_exotic, "grafix/exotic_coast_b_3.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen coast.\n",1 );
	}
	/////
	if ( !LoadMyImage( lpDDSOffAtmos1, "grafix/atmos1.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen atmos.bmp.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffAtmos2, "grafix/atmos2.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen atmos.bmp.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffAtmos3, "grafix/atmos3.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen atmos.bmp.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffAtmos4, "grafix/atmos4.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen atmos.bmp.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffAtmos5, "grafix/atmos5.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen atmos.bmp.\n",1 );
	}
	if ( !LoadMyImage( lpDDSOffAtmos6, "grafix/atmos6.BMP" ) )
	{
		debugfile (  "Couldn't load offscreen atmos.bmp.\n",1 );
	}
}
