/////////////////////////////////////////////////////////////////////////////////////
int river_value (unsigned char terre_type)
{
    if ( terre_type == MOUNT         ) { return 0 ;}
    if ( terre_type == EDGE_OF_WORLD ) { return 0 ;}
    if ( terre_type == 255           ) { return 0 ;}//river loop
	if ( terre_type == HILL          ) { return 10 ;}
	if ( terre_type == PLAIN         ) { return 100 ;}
	if ( terre_type == PLANT_PLAIN   ) { return 100 ;}
	if ( terre_type == PLANT_HILL    ) { return 10 ;}
	if ( terre_type == PLANT_SWAMP    ){ return 200 ;}
	if ( terre_type == SWAMP    )      { return 200 ;}
	if ( terre_type == RIVER         ) { return 2000 ;}
	if ( terre_type == HYDRO         ) { return 5000 ;}
	if ( terre_type == SHALOW       ) { return 5000 ;}
    return 0 ;
}
/////////////////////////////////////////////////////////////////////////////////////
void get_hydro_percent( LPplanet planet_creat )
{
   int ny,nx;
   float hex_hydro = 0.0;
   float size_total = planet_size_y*planet_size_x;
   float hydro_percent = 0.0;

   for (ny=0; ny< planet_size_y; ny++)
   {
       for (nx=0; nx< planet_size_x; nx++ )
       {
           // list all types of hydro
           if  (  (planet_creat->planet_matrice[nx][ny]->type == HYDRO)  ||
                  (planet_creat->planet_matrice[nx][ny]->type == SHALOW) ||
                  (planet_creat->planet_matrice[nx][ny]->type == DEEP)       )
           {
               hex_hydro++;
           }
       }
   }
   // now work out percentage
   hydro_percent = 100.0 * (hex_hydro/size_total);
   planet_creat->hydro_size = hydro_percent;
}
///////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////
void rivers( LPplanet planet_creat )
{
    // note the chance of a river as well as the rivers lengh will be based on the hydro percent

    unsigned char river_finder[100][100];// set to large to take posible world size increase
    int ny, nx, nnx, nny, river_section;
    int river_now_x, river_now_y;
    int rand_hill_river, rand_mount_river;
	int river_max_lengh;
	int river_min_lengh;
    int dice;
    int river_start;
    int river_end;
    int check_hex_x, check_hex_y;
    int odd_even;
    int hex_e, hex_w, hex_ne, hex_nw, hex_se, hex_sw;
    int hex_e_x, hex_w_x, hex_ne_x, hex_nw_x, hex_se_x, hex_sw_x;
    int hex_e_y, hex_w_y, hex_ne_y, hex_nw_y, hex_se_y, hex_sw_y;
    int e_value, w_value, ne_value, nw_value, se_value, sw_value;
    int total_value;
    unsigned char river_loop = 255;
	unsigned char direction;

    // make sure rivers are set to zero, and set virtual creater to zero
     for (ny=0; ny< planet_size_y; ny++)
   {
       for (nx=0; nx< planet_size_x; nx++ )
       {
           if  (  planet_creat->planet_matrice[nx][ny]->flag != NONE )
           {
               planet_creat->planet_matrice[nx][ny]->flag = NONE;
           }
           river_finder[nx][ny] = NONE;
       }
   }
   if (planet_creat->planet_type==SWAMP)
   {
		river_max_lengh =  45;
		river_min_lengh = 0;
		rand_mount_river = 90;
		rand_hill_river =  60;
   }
   else if (planet_creat->planet_type==JUNGLE)
   {
		river_max_lengh =  35;
		river_min_lengh = 1;
		rand_mount_river = 80;
		rand_hill_river =  50 ;
   }
   else
   {
		river_max_lengh =  25;
		river_min_lengh = 2;
		rand_mount_river =  ( (planet_creat->hydro_size)/ 3 );
		rand_hill_river =   ( (planet_creat->hydro_size)/ 6 );
   }

   for (ny=0; ny< planet_size_y; ny++)
   {
       for (nx=0; nx< planet_size_x; nx++ )
       {
           river_start = false;
           if  (  planet_creat->planet_matrice[nx][ny]->flag == NONE )///debug czar note
           {
                if  (  planet_creat->planet_matrice[nx][ny]->type == HILL )
                {
                    dice=random(100)+1;
                    if  (  dice < rand_hill_river ) {river_start = true;}

                }

                if  (  planet_creat->planet_matrice[nx][ny]->type == MOUNT )
                {
                    dice=random(100)+1;
                    if  (  dice < rand_mount_river ) {river_start = true; out_mount_rivers++;}
                }

                if  (  river_start == true )
                {
                    //flags:   0     0     0     0     0     0     0     0
                    //         e     w     ne    nw    se    sw  blank  true

                  river_finder[nx][ny] = river_finder[nx][ny] | FLAG_ON; // 00000001  // set flag to: true for river

                  river_now_x = nx; river_now_y = ny;

                  river_end = false;
                  rivers_seeking++;
                  for (river_section=0; river_section <= river_max_lengh; river_section++)
                  {  //********************
                    odd_even = (river_now_y+1) % 2;
                    ///////get info on hexes around///////////

                    /// check east hex
                    check_hex_x = river_now_x + 1;
                    if ( check_hex_x >= planet_size_x ) { check_hex_x = 0; }  //go round world if over
                    hex_e = planet_creat->planet_matrice[check_hex_x][river_now_y]->type;
                    if  (  planet_creat->planet_matrice[check_hex_x][river_now_y]->flag != NONE ) { hex_e = RIVER; }
                    if ( river_finder[check_hex_x][river_now_y] != NONE ) { hex_e = river_loop; }
                    hex_e_x = check_hex_x; hex_e_y = river_now_y;

                    /// check west hex
                    check_hex_x = river_now_x-1;
                    if ( check_hex_x < 0 ) { check_hex_x = planet_size_x-1; }  //go round world if over
                    hex_w = planet_creat->planet_matrice[check_hex_x][river_now_y]->type;
                    if  (  planet_creat->planet_matrice[check_hex_x][river_now_y]->flag != NONE ) { hex_w = RIVER; }
                    if ( river_finder[check_hex_x][river_now_y] != NONE ) { hex_w = river_loop; }
                    hex_w_x = check_hex_x; hex_w_y = river_now_y;

                    /// check north west hex
                    check_hex_y = river_now_y-1;
                    if ( check_hex_y >= 0 ) //only check if not over top
                    {
                         if ( odd_even == 1 )
                         {
                               hex_nw = planet_creat->planet_matrice[river_now_x][check_hex_y]->type;
                               if  (  planet_creat->planet_matrice[river_now_x][check_hex_y]->flag != NONE ) { hex_nw = RIVER; }
                               if ( river_finder[river_now_x][check_hex_y] != NONE ) { hex_nw = river_loop; }
                               hex_nw_x = river_now_x; hex_nw_y = check_hex_y;
                         }
                         else
                         {
                               check_hex_x = river_now_x-1;
                               if ( check_hex_x < 0 ) { check_hex_x = planet_size_x-1; }  //go round world if over
                               hex_nw = planet_creat->planet_matrice[check_hex_x][check_hex_y]->type;
                               if  (  planet_creat->planet_matrice[check_hex_x][check_hex_y]->flag != NONE ) { hex_nw = RIVER; }
                               if ( river_finder[check_hex_x][check_hex_y] != NONE ) { hex_nw = river_loop; }
                               hex_nw_x = check_hex_x; hex_nw_y = check_hex_y;
                         }

                    }
                    else { hex_nw = EDGE_OF_WORLD; }

                    /// check north east hex
                    check_hex_y = river_now_y-1;
                    if ( check_hex_y >= 0 ) //only check if not over top
                    {
                         if ( odd_even == 0 )
                         {
                               hex_ne = planet_creat->planet_matrice[river_now_x][check_hex_y]->type;
                               if  (  planet_creat->planet_matrice[river_now_x][check_hex_y]->flag != NONE ) { hex_ne = RIVER; }
                               if ( river_finder[river_now_x][check_hex_y] != NONE ) { hex_ne = river_loop; }
                               hex_ne_x = river_now_x; hex_ne_y = check_hex_y;
                         }
                         else
                         {
                               check_hex_x = river_now_x+1;
                               if ( check_hex_x >= planet_size_x )  { check_hex_x = 0; }  //go round world if over
                               hex_ne = planet_creat->planet_matrice[check_hex_x][check_hex_y]->type;
                               if  (  planet_creat->planet_matrice[check_hex_x][check_hex_y]->flag != NONE ) { hex_ne = RIVER; }
                               if ( river_finder[check_hex_x][check_hex_y] != NONE ) { hex_ne = river_loop; }
                               hex_ne_x = check_hex_x; hex_ne_y = check_hex_y;
                         }
                    }
                    else { hex_ne = EDGE_OF_WORLD; }

                    /// check South west hex
                    check_hex_y = river_now_y+1;
                    if ( check_hex_y < planet_size_y ) //only check if not over bottom
                    {
                         if ( odd_even == 1 )
                         {
                               hex_sw = planet_creat->planet_matrice[river_now_x][check_hex_y]->type;
                               if  (  planet_creat->planet_matrice[river_now_x][check_hex_y]->flag != NONE ) { hex_sw = RIVER; }
                               if ( river_finder[river_now_x][check_hex_y] != NONE ) { hex_sw = river_loop; }
                               hex_sw_x = river_now_x; hex_sw_y = check_hex_y;
                         }
                         else
                         {
                               check_hex_x = river_now_x-1;
                               if ( check_hex_x < 0 ) { check_hex_x = planet_size_x-1; }  //go round world if over
                               hex_sw = planet_creat->planet_matrice[check_hex_x][check_hex_y]->type;
                               if  (  planet_creat->planet_matrice[check_hex_x][check_hex_y]->flag != NONE ) { hex_sw = RIVER; }
                               if ( river_finder[check_hex_x][check_hex_y] != NONE ) { hex_sw = river_loop; }
                               hex_sw_x = check_hex_x; hex_sw_y = check_hex_y;
                         }
                     }
                    else { hex_sw = EDGE_OF_WORLD; }

                    /// check South east hex
                    check_hex_y = river_now_y+1;
                    if ( check_hex_y < planet_size_y ) //only check if not over bottom
                    {
                         if ( odd_even == 0 )
                         {
                               hex_se = planet_creat->planet_matrice[river_now_x][check_hex_y]->type;
                               if  (  planet_creat->planet_matrice[river_now_x][check_hex_y]->flag != NONE ) { hex_se = RIVER; }
                               if ( river_finder[river_now_x][check_hex_y] != NONE ) { hex_se = river_loop; }
                               hex_se_x = river_now_x; hex_se_y = check_hex_y;
                         }
                         else
                        {
                               check_hex_x = river_now_x+1;
                               if ( check_hex_x >= planet_size_x ) { check_hex_x = 0; }  //go round world if over
                               hex_se = planet_creat->planet_matrice[check_hex_x][check_hex_y]->type;
                               if  (  planet_creat->planet_matrice[check_hex_x][check_hex_y]->flag != NONE ) { hex_se = RIVER; }
                               if ( river_finder[check_hex_x][check_hex_y] != NONE ) { hex_se = river_loop; }
                               hex_se_x = check_hex_x; hex_se_y = check_hex_y;
                        }
                    }
                    else { hex_se = EDGE_OF_WORLD; }
                    /////////////////////////////////
                    e_value = river_value (hex_e);
                    w_value = river_value (hex_w);
                    ne_value = river_value (hex_ne);
                    nw_value = river_value (hex_nw);
                    se_value = river_value (hex_se);
                    sw_value = river_value (hex_sw);
                    total_value = e_value + w_value + ne_value + nw_value + se_value + sw_value;
                    if ( total_value > 0 )
                    {
                        dice=random(total_value)+1;
                        if ( dice <= e_value )
                        {
							direction= EAST;

                            river_finder[river_now_x][river_now_y] = river_finder[river_now_x][river_now_y] | FLAG_EAST; // 10000000

                            // if going to hex is not sea, set next hex river
                            if ( (planet_creat->planet_matrice[hex_e_x][hex_e_y]->type != HYDRO) &&
                                 (planet_creat->planet_matrice[hex_e_x][hex_e_y]->type != SHALOW)&&
                                 (planet_creat->planet_matrice[hex_e_x][hex_e_y]->type != DEEP)    )
                                 {
                                     river_finder[hex_e_x][hex_e_y] = river_finder[hex_e_x][hex_e_y] | FLAG_ON; // 00000001  // set flag to: true for river in hex going to
                                     river_finder[hex_e_x][hex_e_y] = river_finder[hex_e_x][hex_e_y] | FLAG_WEST; // 10000000  // set flag to: west for river in hex going to
                                     river_now_x = hex_e_x;   //set new x,y values
                                     river_now_y = hex_e_y;
                                 }
                            else {
                                     river_end = true; // hex going is sea, so end
                                     goto find_river;
                                 }

                        }
                        else if ( dice <= (e_value + w_value) )
                        {
                            direction= WEST;

                            river_finder[river_now_x][river_now_y] = river_finder[river_now_x][river_now_y] | FLAG_WEST; // 01000000

                            // if going to hex is not sea, set next hex river
                            if ( (planet_creat->planet_matrice[hex_w_x][hex_w_y]->type != HYDRO) &&
                                 (planet_creat->planet_matrice[hex_w_x][hex_w_y]->type != SHALOW)&&
                                 (planet_creat->planet_matrice[hex_w_x][hex_w_y]->type != DEEP)    )
                                 {
                                     river_finder[hex_w_x][hex_w_y] = river_finder[hex_w_x][hex_w_y] | FLAG_ON; // 00000001  // set flag to: true for river in hex going to
                                     river_finder[hex_w_x][hex_w_y] = river_finder[hex_w_x][hex_w_y] | FLAG_EAST; // 01000000  // set flag to: west for river in hex going to
                                     river_now_x = hex_w_x;   //set new x,y values
                                     river_now_y = hex_w_y;
                                 }
                            else {
                                     river_end = true; // hex going is sea, so end
                                     goto find_river;
                                 }

                        }
                        else if ( dice <= (e_value + w_value + ne_value) )
                        {
                            direction= NORTH_EAST;

                            river_finder[river_now_x][river_now_y] = river_finder[river_now_x][river_now_y] | FLAG_NORTH_EAST; // 00100000

                            // if going to hex is not sea, set next hex river
                            if ( (planet_creat->planet_matrice[hex_ne_x][hex_ne_y]->type != HYDRO) &&
                                 (planet_creat->planet_matrice[hex_ne_x][hex_ne_y]->type != SHALOW)&&
                                 (planet_creat->planet_matrice[hex_ne_x][hex_ne_y]->type != DEEP)    )
                                 {
                                     river_finder[hex_ne_x][hex_ne_y] = river_finder[hex_ne_x][hex_ne_y] | FLAG_ON; // 00000001  // set flag to: true for river in hex going to
                                     river_finder[hex_ne_x][hex_ne_y] = river_finder[hex_ne_x][hex_ne_y] | FLAG_SOUTH_WEST; // 00000100  // set flag to: west for river in hex going to
                                     river_now_x = hex_ne_x;   //set new x,y values
                                     river_now_y = hex_ne_y;
                                 }
                            else {
                                     river_end = true; // hex going is sea, so end
                                     goto find_river;
                                 }

                        }
                        else if ( dice <= (e_value + w_value + ne_value + nw_value) )
                        {
                            direction= NORTH_WEST;

                            river_finder[river_now_x][river_now_y] = river_finder[river_now_x][river_now_y] | FLAG_NORTH_WEST; // 00010000

                            // if going to hex is not sea, set next hex river
                            if ( (planet_creat->planet_matrice[hex_nw_x][hex_nw_y]->type != HYDRO) &&
                                 (planet_creat->planet_matrice[hex_nw_x][hex_nw_y]->type != SHALOW)&&
                                 (planet_creat->planet_matrice[hex_nw_x][hex_nw_y]->type != DEEP)    )
                                 {
                                     river_finder[hex_nw_x][hex_nw_y] = river_finder[hex_nw_x][hex_nw_y] | FLAG_ON; // 00000001  // set flag to: true for river in hex going to
                                     river_finder[hex_nw_x][hex_nw_y] = river_finder[hex_nw_x][hex_nw_y] | FLAG_SOUTH_EAST; // 00001000  // set flag to: west for river in hex going to
                                     river_now_x = hex_nw_x;   //set new x,y values
                                     river_now_y = hex_nw_y;
                                 }
                            else {
                                     river_end = true; // hex going is sea, so end
                                     goto find_river;
                                 }

                        }
                        else if ( dice <= (e_value + w_value + ne_value + nw_value + se_value) )
                        {
                            direction= SOUTH_EAST;

                            river_finder[river_now_x][river_now_y] = river_finder[river_now_x][river_now_y] | FLAG_SOUTH_EAST; // 00001000

                            // if going to hex is not sea, set next hex river
                            if ( (planet_creat->planet_matrice[hex_se_x][hex_se_y]->type != HYDRO) &&
                                 (planet_creat->planet_matrice[hex_se_x][hex_se_y]->type != SHALOW)&&
                                 (planet_creat->planet_matrice[hex_se_x][hex_se_y]->type != DEEP)    )
                                 {
                                     river_finder[hex_se_x][hex_se_y] = river_finder[hex_se_x][hex_se_y] | FLAG_ON; // 00000001  // set flag to: true for river in hex going to
                                     river_finder[hex_se_x][hex_se_y] = river_finder[hex_se_x][hex_se_y] | FLAG_NORTH_WEST; // 00010000  // set flag to: west for river in hex going to
                                     river_now_x = hex_se_x;   //set new x,y values
                                     river_now_y = hex_se_y;
                                 }
                            else {
                                     river_end = true; // hex going is sea, so end
                                     goto find_river;
                                 }

                        }
                        else if ( dice <= (e_value + w_value + ne_value + nw_value + se_value + sw_value) )
                        {
                            direction= SOUTH_WEST;

                            river_finder[river_now_x][river_now_y] = river_finder[river_now_x][river_now_y] | FLAG_SOUTH_WEST; // 00000100

                            // if going to hex is not sea, set next hex river
                            if ( (planet_creat->planet_matrice[hex_sw_x][hex_sw_y]->type != HYDRO) &&
                                 (planet_creat->planet_matrice[hex_sw_x][hex_sw_y]->type != SHALOW)&&
                                 (planet_creat->planet_matrice[hex_sw_x][hex_sw_y]->type != DEEP)    )
                                 {
                                     river_finder[hex_sw_x][hex_sw_y] = river_finder[hex_sw_x][hex_sw_y] | FLAG_ON; // 00000001  // set flag to: true for river in hex going to
                                     river_finder[hex_sw_x][hex_sw_y] = river_finder[hex_sw_x][hex_sw_y] | FLAG_NORTH_EAST; // 00100000  // set flag to: west for river in hex going to
                                     river_now_x = hex_sw_x;   //set new x,y values
                                     river_now_y = hex_sw_y;
                                 }
                            else {
                                     river_end = true; // hex going is sea, so end
                                     goto find_river;
                                 }

                        }
                        else //just in case........
                        {
                            debugfile ("error...over total river value\n", dice );
                            direction= SOUTH_WEST;

                            river_finder[river_now_x][river_now_y] = river_finder[river_now_x][river_now_y] | FLAG_SOUTH_WEST; // 00000100

                            // if going to hex is not sea, set next hex river
                            if ( (planet_creat->planet_matrice[hex_sw_x][hex_sw_y]->type != HYDRO) &&
                                 (planet_creat->planet_matrice[hex_sw_x][hex_sw_y]->type != SHALOW)&&
                                 (planet_creat->planet_matrice[hex_sw_x][hex_sw_y]->type != DEEP)    )
                                 {
                                     river_finder[hex_sw_x][hex_sw_y] = river_finder[hex_sw_x][hex_sw_y] | FLAG_ON; // 00000001  // set flag to: true for river in hex going to
                                     river_finder[hex_sw_x][hex_sw_y] = river_finder[hex_sw_x][hex_sw_y] | FLAG_NORTH_EAST; // 00100000  // set flag to: west for river in hex going to
                                     river_now_x = hex_sw_x;   //set new x,y values
                                     river_now_y = hex_sw_y;
                                 }
                            else {
                                     river_end = true; // hex going is sea, so end
                                     goto find_river;
                                 }

                        }

                        if ( planet_creat->planet_matrice[river_now_x][river_now_y]->flag != NONE ) /// if joins river
                             {
                                  river_end = true;
                                  goto find_river;
                             }

                    }
                    else{
                             rivers_no_path_value++;
                             river_end = false; // no path; so end
                             goto find_river;
                        }

                  }  //****************
                  // now check if river true, if so place on world //
                  //////////------///////
                  find_river:
				  if ( (river_end == true) && (river_section > river_min_lengh)  )
                      {
                          out_num_rivers_ok++;
                          for (nny=0; nny< planet_size_y; nny++)
                          {
                             for (nnx=0; nnx< planet_size_x; nnx++ )
                             {
                                 if  (  river_finder[nnx][nny] != NONE )
                                 {
									 planet_creat->planet_matrice[nnx][nny]->flag = planet_creat->planet_matrice[nnx][nny]->flag | river_finder[nnx][nny];
									 // now turn hill terains into plain type if it has river//
									 if ( (planet_creat->planet_matrice[nnx][nny]->type==HILL) )
									 {planet_creat->planet_matrice[nnx][nny]->type=PLAIN;}
									 if ( (planet_creat->planet_matrice[nnx][nny]->type==PLANT_HILL) )
									 {planet_creat->planet_matrice[nnx][nny]->type=PLANT_PLAIN;}
									 if ( (planet_creat->planet_matrice[nnx][nny]->type==MOUNT) )
									 {planet_creat->planet_matrice[nnx][nny]->type=PLAIN;}
									 /////////////////////////////////////////////////////
                                     river_finder[nnx][nny] = NONE; //set back to zero
                                 }

                             }
                          }
                      }
                   else
                      {
                          out_num_rivers_ko++;
                          for (nny=0; nny< planet_size_y; nny++)
                          {
                             for (nnx=0; nnx< planet_size_x; nnx++ )
                             {
                                 river_finder[nnx][nny] = NONE; //set back to zero
                             }
                          }
                      }
                  /////////--------/////
                }

           }


       }
   }

}
///////////////////////////////////////////////////////////////////////////////////////


