void Creat_Nebula (void)
{
    int diceA ;
    diceA = random( Num_Nebulas );
    debugfile ("creating nebula\n", diceA+1 );

    // release offscreen nebula if it exists
    if ( lpDDSOffNebula1 != NULL )
            {
                lpDDSOffNebula1->Release();
                lpDDSOffNebula1 = NULL;
            }

    // Create the offscreen nebula.
    ddsd.dwHeight = 500;
    ddsd.dwWidth = 500;
    if ( FAILED( lpDD->CreateSurface( &ddsd, &lpDDSOffNebula1, NULL ) ) )
	{
		debugfile ("could not creat nebula\n", 1 );
	}

    if ( diceA < 1 )
    	  {
			 if ( !LoadMyImage( lpDDSOffNebula1, "grafix/nebula1.bmp" ) )
	    	     {
		    	     debugfile ("could not load nebula1\n", 1 );
                 }
	      }

    if ( diceA == 1 )
    	  {
			 if ( !LoadMyImage( lpDDSOffNebula1, "grafix/nebula2.bmp" ) )
	    	     {
		    	     debugfile ("could not load nebula2\n", 1 );
                 }
	      }

     if ( diceA == 2 )
    	  {
			 if ( !LoadMyImage( lpDDSOffNebula1, "grafix/nebula3.bmp" ) )
	    	     {
		    	     debugfile ("could not load nebula3\n", 1 );
                 }
	      }

     if ( diceA == 3 )
    	  {
			 if ( !LoadMyImage( lpDDSOffNebula1, "grafix/nebula4.bmp" ) )
	    	     {
		    	     debugfile ("could not load nebula4\n", 1 );
                 }
	      }

      if ( diceA == 4 )
    	  {
			 if ( !LoadMyImage( lpDDSOffNebula1, "grafix/nebula5.bmp" ) )
	    	     {
		    	     debugfile ("could not load nebula5\n", 1 );
                 }
	      }

           if ( diceA == 5 )
    	  {
			 if ( !LoadMyImage( lpDDSOffNebula1, "grafix/nebula6.bmp" ) )
	    	     {
		    	     debugfile ("could not load nebula6\n", 1 );
                 }
	      }

	      if ( diceA == 6 )
    	  {
			 if ( !LoadMyImage( lpDDSOffNebula1, "grafix/nebula7.bmp" ) )
	    	     {
		    	     debugfile ("could not load nebula7\n", 1 );
                 }
	      }

	      if ( diceA == 7 )
    	  {
			 if ( !LoadMyImage( lpDDSOffNebula1, "grafix/nebula8.bmp" ) )
	    	     {
		    	     debugfile ("could not load nebula8\n", 1 );
                 }
	      }

	      if ( diceA == 8 )
    	  {
			 if ( !LoadMyImage( lpDDSOffNebula1, "grafix/nebula9.bmp" ) )
	    	     {
		    	     debugfile ("could not load nebula9\n", 1 );
                 }
	      }

	      if ( diceA == 9 )
    	  {
			 if ( !LoadMyImage( lpDDSOffNebula1, "grafix/nebula10.bmp" ) )
	    	     {
		    	     debugfile ("could not load nebula10\n", 1 );
                 }
	      }

	      if ( diceA == 10 )
    	  {
			 if ( !LoadMyImage( lpDDSOffNebula1, "grafix/nebula11.bmp" ) )
	    	     {
		    	     debugfile ("could not load nebula11\n", 1 );
                 }
	      }

	      if ( diceA == 11 )
    	  {
			 if ( !LoadMyImage( lpDDSOffNebula1, "grafix/nebula12.bmp" ) )
	    	     {
		    	     debugfile ("could not load nebula12\n", 1 );
                 }
	      }

	      if ( diceA == 12 )
    	  {
			 if ( !LoadMyImage( lpDDSOffNebula1, "grafix/nebula13.bmp" ) )
	    	     {
		    	     debugfile ("could not load nebula13\n", 1 );
                 }
	      }

	      if ( diceA == 13 )
    	  {
			 if ( !LoadMyImage( lpDDSOffNebula1, "grafix/nebula14.bmp" ) )
	    	     {
		    	     debugfile ("could not load nebula14\n", 1 );
                 }
	      }

	      if ( diceA == 14 )
    	  {
			 if ( !LoadMyImage( lpDDSOffNebula1, "grafix/nebula15.bmp" ) )
	    	     {
		    	     debugfile ("could not load nebula15\n", 1 );
                 }
	      }

	      if ( diceA == 15 )
    	  {
			 if ( !LoadMyImage( lpDDSOffNebula1, "grafix/nebula16.bmp" ) )
	    	     {
		    	     debugfile ("could not load nebula16\n", 1 );
                 }
	      }

	      if ( diceA == 16 )
    	  {
			 if ( !LoadMyImage( lpDDSOffNebula1, "grafix/nebula17.bmp" ) )
	    	     {
		    	     debugfile ("could not load nebula17\n", 1 );
                 }
	      }

	      if ( diceA == 17 )
    	  {
			 if ( !LoadMyImage( lpDDSOffNebula1, "grafix/nebula18.bmp" ) )
	    	     {
		    	     debugfile ("could not load nebula18\n", 1 );
                 }
	      }

	      if ( diceA == 18 )
    	  {
			 if ( !LoadMyImage( lpDDSOffNebula1, "grafix/nebula19.bmp" ) )
	    	     {
		    	     debugfile ("could not load nebula19\n", 1 );
                 }
	      }

	      if ( diceA > 18 )
    	  {
			 if ( !LoadMyImage( lpDDSOffNebula1, "grafix/nebula20.bmp" ) )
	    	     {
		    	     debugfile ("could not load nebula20\n", 1 );
                 }
	      }

	      if ( lpDDSOffNebula1 == NULL )
            {
                debugfile ("did not load any nebula\n", 1 );
            }

}

void Place_Nebula (float x, float y)
{
    double MapAjuster=GalaxySize/280;
	float minX= ((x-513.0-14.0)/Small_Place  )*MapAjuster;
    float minY= ((y-313.0-14.0)/Small_Place  )*MapAjuster;
	//float Xpos, Ypos;
	RECT  rcRectNebula;
	float neb_stretch_factor = (500 * nebula_size)/2;


	rcRect.left=   ( 800 - minX * 4 ) -neb_stretch_factor  ;
	rcRect.top=  (( 800 - minY * 4 )+100) -neb_stretch_factor;
	rcRect.right=   ( 800 - minX * 4 )+neb_stretch_factor;
	rcRect.bottom=    (( 800 - minY * 4 )+100)+neb_stretch_factor;

//	Xpos= ( 600 - minX * 4 )    ;
//	Ypos= ( 400 - minY * 4 )+100;
	rcRectNebula.top=     0;
	rcRectNebula. bottom= 500;
	rcRectNebula.left=    0;
	rcRectNebula.right=   500;

	if (rcRect.left<0 && rcRect.right>0)
	{
		rcRectNebula.left =rcRectNebula.left+((0+(rcRect.left*-1))/nebula_size);
		rcRect.left=0;
	}
	if (rcRect.bottom>0 && rcRect.top<0  )
	{

		rcRectNebula.top= rcRectNebula.top+((0+(rcRect.top*-1))/nebula_size);
		rcRect.top=0;
	}
	if (rcRect.bottom>screen_y  &&  rcRect.top<screen_y)
	{
		rcRectNebula.bottom= rcRectNebula.bottom-((rcRect.bottom-screen_y)/nebula_size);
		rcRect.bottom=screen_y;
	}
	if (rcRect.right>screen_x && rcRect.left<screen_x)
	{
		rcRectNebula.right=rcRectNebula.right-((rcRect.right-screen_x)/nebula_size);
		rcRect.right=screen_x;
	}

	//if (  (Xpos>-500) && (Ypos>-500)  )
	//             {
	//       	          if  (Xpos<0)   { int(rcRectNebula.left=abs(Xpos)); Xpos=0;}
	//                  if  (Ypos<0)   {int(rcRectNebula.top=abs(Ypos));  Ypos=0;}
	//				  if  (Xpos>480-500+(12)+(screen_x-500))
	//						   {int(rcRectNebula.right=500+(12)+(480-500-Xpos)+(screen_x-500));}
	//				  if  (Ypos>599-500+(screen_y-600))
	//						   {int(rcRectNebula.bottom=500+(599-500-Ypos)+(screen_y-600));}
	//			 }

	lpDDSOffScreen->Blt(   &rcRect,
							lpDDSOffNebula1,
							&rcRectNebula,
							DDBLT_WAIT |
							DDBLT_KEYSRC,NULL );


	//lpDDSOffScreen->BltFast( Xpos,
	//                         Ypos,
	 //						 lpDDSOffNebula1,
	 //                        &rcRectNebula,
	 //                        DDBLTFAST_WAIT |
	 //                        DDBLTFAST_SRCCOLORKEY );

}
