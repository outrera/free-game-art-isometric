void buttonOFF(int xb, int yb)
{
	// rect for main sreen button : off
   RECT   rcRectButton1off;
	rcRectButton1off.top=0; rcRectButton1off.bottom=43; rcRectButton1off.left=0; rcRectButton1off.right=99;
   lpDDSOffScreen->BltFast( xb,yb , lpDDSOffButtons, &rcRectButton1off,
                                           DDBLTFAST_WAIT |
                                           DDBLTFAST_SRCCOLORKEY );
}

void buttonON(int xb, int yb)
{
   // rect for main sreen button : on
   RECT   rcRectButton1on;
	rcRectButton1on.top=0; rcRectButton1on.bottom=43; rcRectButton1on.left=100; rcRectButton1on.right=199;
   lpDDSOffScreen->BltFast( xb,yb , lpDDSOffButtons, &rcRectButton1on,
                                           DDBLTFAST_WAIT |
                                           DDBLTFAST_SRCCOLORKEY );
}

void buttonsStatus()
{
    //				button #1
    if  (	((xPos>496 && yPos>4) && (xPos<590 && yPos<42))|| (startgame==true)	)
       	{
         	if  ( botton1==true )  { botton1=false; buttonOFF( 494, 2 ); }
            else                   { botton1=true; buttonON( 494, 2 ); }
         }
    //				button #2
    if  (	((xPos>496 && yPos>49) && (xPos<590 && yPos<87)) || (startgame==true)	)
       	{
         	if  ( botton2==true )  { botton2=false; buttonOFF( 494, 47 ); }
            else                   { botton2=true; buttonON( 494, 47 ); }
         }
    //				button #3
    if  (	((xPos>496 && yPos>94) && (xPos<590 && yPos<132)) || (startgame==true)	)
       	{
         	if  ( botton3==true )  { botton3=false; buttonOFF( 494, 92 ); }
            else                   { botton3=true; buttonON( 494, 92 ); }
         }
    //				button #4
    if  (	((xPos>496 && yPos>139) && (xPos<590 && yPos<177)) || (startgame==true)	)
       	{
         	if  ( botton4==true )  { botton4=false; buttonOFF( 494, 137 ); }
            else                   { botton4=true; buttonON( 494, 137 ); }
         }
    //				button #5
    if  (	((xPos>596 && yPos>4) && (xPos<690 && yPos<42)) || (startgame==true)	)
       	{
         	if  ( botton5==true )  { botton5=false; buttonOFF( 595, 2 ); }
            else                   { botton5=true; buttonON( 595, 2 ); }
         }
    //				button #6
    if  (	((xPos>596 && yPos>49) && (xPos<690 && yPos<87)) || (startgame==true)	)
       	{
         	if  ( botton6==true )  { botton6=false; buttonOFF( 595, 47 ); }
            else                   { botton6=true; buttonON( 595, 47 ); }
         }
    //				button #7
    if  (	((xPos>596 && yPos>94) && (xPos<690 && yPos<132))|| (startgame==true)	)
       	{
         	if  ( botton7==true )  { botton7=false; buttonOFF( 595, 92 ); }
            else                   { botton7=true; buttonON( 595, 92 ); }
         }
    //				button #8
    if  (	((xPos>596 && yPos>139) && (xPos<690 && yPos<177))|| (startgame==true)	)
       	{
         	if  ( botton8==true )  { botton8=false; buttonOFF( 595, 137 ); }
            else                   { botton8=true; buttonON( 595, 137 ); }
         }
    //				button #9
    if  (	((xPos>698 && yPos>4) && (xPos<792 && yPos<42))|| (startgame==true)	)
       	{
         	if  ( botton9==true )  { botton9=false; buttonOFF( 696, 2 ); }
            else                   { botton9=true; buttonON( 696, 2 ); }
         }
    //				button #10
    if  (	((xPos>698 && yPos>49) && (xPos<792 && yPos<87))|| (startgame==true)	)
       	{
         	if  ( botton10==true )  { botton10=false; buttonOFF( 696, 47 ); }
            else                   { botton10=true; buttonON( 696, 47 ); }
         }
    //				button #11
    if  (	((xPos>698 && yPos>94) && (xPos<792 && yPos<132))|| (startgame==true)	)
       	{
         	if  ( botton11==true )  { botton11=false; buttonOFF( 696, 92 ); }
            else                   { botton11=true; buttonON( 696, 92 ); }
         }
    //				button #12
    if  (	((xPos>698 && yPos>139) && (xPos<792 && yPos<177))|| (startgame==true)	)
       	{
         	if  ( botton12==true )  { botton12=false; buttonOFF( 696, 137 ); }
            else                   { botton12=true; buttonON( 696, 137 ); }
         }
}


