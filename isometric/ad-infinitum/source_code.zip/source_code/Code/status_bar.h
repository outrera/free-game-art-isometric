


void generation_bar_move (int number_at, int total_finish)
{
	int bar_at;

	long percent_point;

	percent_point= 250/total_finish;
	bar_at=number_at*percent_point;

	RECT rcRect_get_the_box;
	RECT rcRect_put_the_box;

	rcRect_get_the_box.top=			0	;
	rcRect_get_the_box.bottom = 	22	;
	rcRect_get_the_box.left=		0	;
	rcRect_get_the_box.right = 		256	;

	rcRect_put_the_box.top=			(screen_x/2)-(22/2)	;
	rcRect_put_the_box.bottom = 	rcRect_put_the_box.top + 22	;
	rcRect_put_the_box.left=		(screen_x/2)-(256/2);
	rcRect_put_the_box.right = 		rcRect_put_the_box.left +	256;
	/////////////////////////////////////	;

	RECT rcRect_get_the_bar;
	RECT rcRect_put_the_bar;

	rcRect_get_the_bar.top=			24	;
	rcRect_get_the_bar.bottom = 	34	;
	rcRect_get_the_bar.left=		0	;
	rcRect_get_the_bar.right = 		243	;

	rcRect_put_the_bar.top=			rcRect_put_the_box.top  + 6	;
	rcRect_put_the_bar.bottom = 	rcRect_put_the_bar.top  + 10	;
	rcRect_put_the_bar.left=		rcRect_put_the_box.left + 6	;
	rcRect_put_the_bar.right = 		rcRect_put_the_bar.left + bar_at;

	debugfile ("status bar right\n", rcRect_put_the_bar.right );

	ZeroMemory( &ddbltfx, sizeof( ddbltfx ) );
   ddbltfx.dwSize = sizeof( ddbltfx );

   // Fill the surface with background colour .
   ddbltfx.dwFillColor = dwBackground;
   lpDDSBack->Blt( NULL, NULL,        // black out screen
							NULL,
						DDBLT_COLORFILL |
						DDBLT_WAIT, &ddbltfx );

	lpDDSBack->Blt ( &rcRect_put_the_box , lpDDSOffBar1, &rcRect_get_the_box,
						DDBLT_WAIT |
						DDBLT_KEYSRC, NULL );

    lpDDSBack->Blt ( &rcRect_put_the_bar , lpDDSOffBar1, &rcRect_get_the_bar,
						DDBLT_WAIT |
						DDBLT_KEYSRC, NULL );

	lpDDSPrimary->Flip( NULL, DDFLIP_WAIT );
}
