 ////////////////////////////////////////////////////////////////////////
////////// forests///////////////////////////////////////////////////////

void plants ( LPplanet planet_creat )
{
   int ny,nx; int dice;
   //find individual hills from sections
   for (ny=0; ny< planet_size_y; ny++)
   {
	   for (nx=0; nx< planet_size_x; nx++ )
       {
		   if  (planet_creat->planet_matrice[nx][ny]->type  == PLAIN)
		   {

				   dice=random(100)+1;
				   if ( dice < planet_creat->plant_size )
				   {
					   planet_creat->planet_matrice[nx][ny]->type = PLANT_PLAIN;
				   }

		   }

		   if  (planet_creat->planet_matrice[nx][ny]->type  == HILL)
		   {

				   dice=random(100)+1;
				   if ( dice < planet_creat->plant_size )
				   {
					   planet_creat->planet_matrice[nx][ny]->type = PLANT_HILL;
				   }

           }

       }
   }
	place_terain( planet_creat, PLAIN, HILL, PLANT_PLAIN, PLANT_HILL, plant_adjust, GROW_BY_INCREES );
	place_terain( planet_creat, PLAIN, HILL, PLANT_PLAIN, PLANT_HILL, plant_adjust, GROW_BY_INCREES );
	place_terain( planet_creat, PLAIN, HILL, PLANT_PLAIN, PLANT_HILL, plant_adjust, GROW_BY_INCREES );
	place_terain( planet_creat, PLAIN, HILL, PLANT_PLAIN, PLANT_HILL, plant_adjust, GROW_BY_INCREES );
	place_terain( planet_creat, PLAIN, HILL, PLANT_PLAIN, PLANT_HILL, plant_adjust, GROW_BY_INCREES );
	place_terain( planet_creat, PLAIN, HILL, PLANT_PLAIN, PLANT_HILL, plant_adjust, GROW_BY_INCREES );
	place_terain( planet_creat, PLAIN, HILL, PLANT_PLAIN, PLANT_HILL, plant_adjust, GROW_BY_INCREES );

}

/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
////////// swamps///////////////////////////////////////////////////////

void swamps ( LPplanet planet_creat )
{
   int ny,nx; int dice;
   //find individual swamps from sections
   for (ny=0; ny< planet_size_y; ny++)
   {
	   for (nx=0; nx< planet_size_x; nx++ )
       {
		   if  (planet_creat->planet_matrice[nx][ny]->type  == PLAIN)
		   {

				   dice=random(100)+1;
				   if ( dice < planet_creat->swamp_size )
				   {
					   planet_creat->planet_matrice[nx][ny]->type = SWAMP;
				   }

		   }

		   if  (planet_creat->planet_matrice[nx][ny]->type  == PLANT_PLAIN)
		   {

				   dice=random(100)+1;
				   if ( dice < planet_creat->swamp_size )
				   {
					   planet_creat->planet_matrice[nx][ny]->type = PLANT_SWAMP;
				   }

           }

       }
   }
	place_terain( planet_creat, PLAIN, PLANT_PLAIN, SWAMP, PLANT_SWAMP, plant_adjust, GROW_BY_INCREES );
	place_terain( planet_creat, PLAIN, PLANT_PLAIN, SWAMP, PLANT_SWAMP, plant_adjust, GROW_BY_INCREES );
	place_terain( planet_creat, PLAIN, PLANT_PLAIN, SWAMP, PLANT_SWAMP, plant_adjust, GROW_BY_INCREES );
	place_terain( planet_creat, PLAIN, PLANT_PLAIN, SWAMP, PLANT_SWAMP, plant_adjust, GROW_BY_INCREES );

}


////////////////oasis/////////////
 ///scan world for best locations
int planet_scan_oasis_place ( LPplanet planet_scaned )
{
   int check_hex_x, check_hex_y;
   int scan_yes;

   int town_oasis [100][100];
   int nx,ny;
   int odd_even;
   int planet_number = planet_scaned->number;
   int dice;
   int scan_value;
   int total_value=0;

	for (ny=0; ny< planet_size_y; ny++)
   {
	   for (nx=0; nx< planet_size_x; nx++ )
	   { town_oasis [nx][ny] =  0; }  //set to null
   }

   for (ny=0; ny< planet_size_y; ny++)
   {
	   odd_even = (ny+1) % 2;

	   for (nx=0; nx< planet_size_x; nx++ )
	   {
			check_hex_x = nx;
			check_hex_y = ny;
			//first work out center hex
			scan_yes = false; //default
			scan_value = 0;   //default
			if ( ((planet_scaned->planet_matrice[nx][ny]->type) == PLAIN)
					||((planet_scaned->planet_matrice[nx][ny]->type) == HILL)
					||((planet_scaned->planet_matrice[nx][ny]->type) == MOUNT)  )
					 {  scan_yes = true; }


			//then scan neibours for adjustments on value
			if (scan_yes == true) //scan hexs only if center can build
			{
				//Number_diferent=0;

				if ( planet_scaned->planet_matrice[nx][ny] == NULL )
				{debugfile ("error....no hex in scan town \n", planet_number );}

                /// check east hex
				check_hex_x = nx+1;
				if ( check_hex_x >= planet_size_x )
					 { check_hex_x = 0; }  //go round world if over
				if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SHALOW )
					 { scan_value=scan_value+100; }
				if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->flag) != NONE )
					 { scan_value=scan_value+40; }

				/// check west hex
				check_hex_x = nx-1;
                if ( check_hex_x < 0 )
                     { check_hex_x = planet_size_x-1; }  //go round world if over
				if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SHALOW )
					 { scan_value=scan_value+100; }
				if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->flag) != NONE )
					 { scan_value=scan_value+40; }


				/// check north west hex
				check_hex_x = nx;
                check_hex_y = ny-1;
				if ( check_hex_y >= 0 ) //only check if not over top
				{
					 if ( odd_even == 1 )
					 {
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SHALOW )
								{ scan_value=scan_value+100; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->flag) != NONE )
								{ scan_value=scan_value+40; }
					 }
					 else
                     {
						   check_hex_x = nx-1;
						   if ( check_hex_x < 0 )
							 { check_hex_x = planet_size_x-1; }  //go round world if over
						   if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SHALOW )
								{ scan_value=scan_value+100; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->flag) != NONE )
								{ scan_value=scan_value+40; }
                     }
				}

				/// check north east hex
				check_hex_x = nx;
                check_hex_y = ny-1;
                if ( check_hex_y >= 0 ) //only check if not over top
				{
					 if ( odd_even == 0 )
                     {
						   if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SHALOW )
								{ scan_value=scan_value+100; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->flag) != NONE )
								{ scan_value=scan_value+40; }
					 }
					 else
					 {
                           check_hex_x = nx+1;
						   if ( check_hex_x >= planet_size_x )
								{ check_hex_x = 0; }  //go round world if over
						   if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SHALOW )
								{ scan_value=scan_value+100; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->flag) != NONE )
								{ scan_value=scan_value+40; }
					 }
                }


				/// check South west hex
				check_hex_x = nx;
				check_hex_y = ny+1;
				if ( check_hex_y < planet_size_y ) //only check if not over bottom
				{
                     if ( odd_even == 1 )
                     {
						   if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SHALOW )
								{ scan_value=scan_value+100; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->flag) != NONE )
								{ scan_value=scan_value+40; }
					 }
					 else
                     {
                           check_hex_x = nx-1;
						   if ( check_hex_x < 0 )
                             { check_hex_x = planet_size_x-1; }  //go round world if over
						   if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SHALOW )
								{ scan_value=scan_value+100; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->flag) != NONE )
								{ scan_value=scan_value+40; }
                     }
				}

				/// check South east hex
				check_hex_x = nx;
				check_hex_y = ny+1;
				if ( check_hex_y < planet_size_y ) //only check if not over bottom
				{
					 if ( odd_even == 0 )
                     {
						   if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SHALOW )
								{ scan_value=scan_value+100; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->flag) != NONE )
								{ scan_value=scan_value+40; }
					 }
                     else
					 {
						   check_hex_x = nx+1;
						   if ( check_hex_x >= planet_size_x )
								{ check_hex_x = 0; }  //go round world if over
						   if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->type) == SHALOW )
								{ scan_value=scan_value+100; }
							if ( (planet_scaned->planet_matrice[check_hex_x][check_hex_y]->flag) != NONE )
								{ scan_value=scan_value+40; }
					 }
                }

								/*
                    if ( Number_diferent > 0 )
									{  town_oasis [nx][ny] = 1;  }
									else
									{  town_oasis [nx][ny] = 2;  }
                */

				if ( check_hex_x < 0 ) debugfile ("error....check hex less than zero, x\n", check_hex_x );
				if ( check_hex_x >= planet_size_x ) debugfile ("error....check hex too big, x\n", check_hex_x );
			}
			town_oasis [nx][ny] = scan_value;
			total_value=total_value+scan_value;
	   }
   }
   //now work out where oasis randomly is
   if (total_value==0)
   {
		 return false;
   }
   //dice = random( total_value );
   //int adding_value=0;
   for (ny=0; ny< planet_size_y; ny++)
   {
	   for (nx=0; nx< planet_size_x; nx++ )
	   {
			//adding_value=adding_value+town_oasis [nx][ny];
			if (town_oasis [nx][ny]  !=  0)
			{

				planet_scaned->planet_matrice[nx][ny]->type = SWAMP ;

				//return true;
			}

	   }
   }

return false;
}

 /////////////////////////
void plants_oasis ( LPplanet planet_creat )
{
   int ny,nx; int dice;
   //find individual hills from sections
   for (ny=0; ny< planet_size_y; ny++)
   {
	   for (nx=0; nx< planet_size_x; nx++ )
       {
		   if  (planet_creat->planet_matrice[nx][ny]->type  == SWAMP)
		   {

				   dice=random(100)+1;
				   if ( dice < planet_creat->plant_size )
				   {
					   planet_creat->planet_matrice[nx][ny]->type = PLANT_SWAMP;
				   }

		   }

       }
   }
	place_terain( planet_creat, SWAMP, SWAMP, PLANT_SWAMP, PLANT_SWAMP, plant_adjust, GROW_BY_INCREES );
	place_terain( planet_creat, SWAMP, SWAMP, PLANT_SWAMP, PLANT_SWAMP, plant_adjust, GROW_BY_INCREES );
	place_terain( planet_creat, SWAMP, SWAMP, PLANT_SWAMP, PLANT_SWAMP, plant_adjust, GROW_BY_INCREES );
}
