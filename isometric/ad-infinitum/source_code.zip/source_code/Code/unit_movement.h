   ////file for unit movements ////
void remove_all_link_movement_chain (LPunit unit_with_chain)
{
	///first: security
	if ( unit_with_chain->going_path==(LPhex_path) NULL ) {return;}

	LPhex_path chain_part;
	LPhex_path next_chain_part= (LPhex_path) NULL;

	for ( chain_part=unit_with_chain->going_path; chain_part != (LPhex_path) NULL; chain_part=next_chain_part )
		{
			next_chain_part = chain_part->next_path_node;
			free( chain_part );

		}

		unit_with_chain->going_path=(LPhex_path) NULL;
}
   //////////////////////////////
void remove_first_link_movement_chain (LPunit unit_with_chain)
{
	//debugfile ("remove_first_link_movement_chain\n", 1 );

	LPhex_path chain_part_to_be_freed;

	chain_part_to_be_freed = unit_with_chain->going_path;
	unit_with_chain->going_path = unit_with_chain->going_path->next_path_node;

	free( chain_part_to_be_freed );
}
//////////////////////
/*
	void Add_unit_Task (
    			  LPUNIT_DOING_TASK new_uni_task    // the node to be added
    			  )
    {   // added at top of list
    	//debugfile ("add unit_task\n", 1 );
    	if (g_bottom_unit_task == (LPUNIT_DOING_TASK) NULL )    // if no other node
    	{
    		g_bottom_unit_task = new_uni_task;
    		new_uni_task->prev = (LPUNIT_DOING_TASK) NULL ;
    	}
    	else                                    // else add to top
    	{
    		new_uni_task->prev = g_top_unit_task;
    		new_uni_task->prev->next = new_uni_task;
    	}
    	g_top_unit_task = new_uni_task;
    	new_uni_task->next = (LPUNIT_DOING_TASK) NULL;
	}
*/
////////remove a units doing task////////
void Remove_units_going_task(
				LPUNIT_DOING_TASK task     // the units task to be removed
				)
{

	if ( task != (LPUNIT_DOING_TASK) NULL)
	{
		if (task == g_bottom_unit_task)
        	{
        		g_bottom_unit_task = task->prev;
				if ( g_bottom_unit_task != (LPUNIT_DOING_TASK) NULL )
        		{
        			g_bottom_unit_task->next = (LPUNIT_DOING_TASK) NULL;
				}
				if (task == g_top_unit_task)
				{
					g_bottom_unit_task=(LPUNIT_DOING_TASK) NULL;
					g_top_unit_task   =(LPUNIT_DOING_TASK) NULL;
				}
        	}
		else if (task == g_top_unit_task)
        	{
        		g_top_unit_task = task->next;
        		if ( g_top_unit_task != (LPUNIT_DOING_TASK) NULL )
        		{
        				g_top_unit_task->prev = (LPUNIT_DOING_TASK) NULL;
				}
				if (task == g_bottom_unit_task)
				{
					g_bottom_unit_task=(LPUNIT_DOING_TASK) NULL;
					g_top_unit_task   =(LPUNIT_DOING_TASK) NULL;
				}
        	}
        else
        	{
        		task->prev->next = task->next;
        		task->next->prev = task->prev;
        	}
			free( task );
			//debugfile ("Removed units going task\n", 1 );
	}
}
///free all units tasks///
void Freeunit_tasks ( void )
{
	//debugfile ("free unit task\n", 1 );
	int number_of_freed=0;
	LPUNIT_DOING_TASK the_unit_task;
	LPUNIT_DOING_TASK next_task;
	for ( the_unit_task=g_bottom_unit_task; the_unit_task != (LPUNIT_DOING_TASK)NULL; the_unit_task=next_task )
    {
		next_task = the_unit_task->next;
		free( the_unit_task );
		number_of_freed++;
	}
	//debugfile ("freed unit_tasks\n", number_of_freed );
	g_bottom_unit_task = NULL;
	g_top_unit_task    = NULL;
}
///////add unit task//////////////
void Add_unit_Task (
			  LPUNIT_DOING_TASK newTask    // the task to be added
			  )
{   // added by order of time
	//debugfile ("add task\n", 1 );

	///debug: just add to bottom

	if (g_top_unit_task == (LPUNIT_DOING_TASK) NULL )    						// if no other task
	{
		g_bottom_unit_task = newTask;
		g_top_unit_task=     newTask;
		newTask->prev = (LPUNIT_DOING_TASK) NULL ;
		newTask->next = (LPUNIT_DOING_TASK) NULL ;
		return;
	}
	else  //  at top of list
	{
		 g_top_unit_task->prev=newTask;
		 newTask->prev = (LPUNIT_DOING_TASK) NULL ;
		 newTask->next = g_top_unit_task ;
		 g_top_unit_task = newTask;
		 return;
	}

////debug: turn off
/*

	if (g_bottom_unit_task == (LPUNIT_DOING_TASK) NULL )    						// if no other task
	{
		g_bottom_unit_task = newTask;
		g_top_unit_task=     newTask;
		newTask->prev = (LPUNIT_DOING_TASK) NULL ;
		newTask->next = (LPUNIT_DOING_TASK) NULL ;
		return;
	}
	else if ( (newTask->time) >= (g_bottom_unit_task->time) )   // if at end of list
	{
		 g_bottom_unit_task->next=newTask;
		 newTask->prev = g_bottom_unit_task ;
			newTask->next = (LPUNIT_DOING_TASK) NULL ;
		 g_bottom_unit_task = newTask;
		 return;
	}
	else if ( (newTask->time) < (g_top_unit_task->time) )       // if first of list                                     	  // if first of list
	{
		 g_top_unit_task->prev=newTask;
		 newTask->prev = (LPUNIT_DOING_TASK) NULL ;
			newTask->next = g_top_unit_task ;
		 g_top_unit_task = newTask;
		 return;
	}
	else
	{                                                      // else in middle
		 LPUNIT_DOING_TASK temp_task; LPUNIT_DOING_TASK next_task = (LPUNIT_DOING_TASK) NULL;
		 for ( temp_task=g_top_unit_task; temp_task != (LPUNIT_DOING_TASK)NULL; temp_task=next_task )
		 {
			 next_task = temp_task->next;
			 if ( (newTask->time) < (temp_task->time) )
			 {
					newTask->prev = temp_task->prev ;
						newTask->next = temp_task ;
				  newTask->prev->next = newTask;
				  temp_task->prev = newTask;
				  return;
			 }
		 }
	}

*/

}
////////creat UNIT_DOING_TASK//////
LPUNIT_DOING_TASK get_doing_task	( 	LPunit				the_unit,
										LPunit				the_unit_linked,
										LPUNIT_DOING_TASK	next_task,
										LPUNIT_DOING_TASK	prev_task,
										int					going_place_x,
										int					going_place_y,
										long				start_place_x,
										long				start_place_y,
										short int 			doing_task,
										DWORD 		arrival_time,
										DWORD		start_trip_time    )
{
		//debugfile ("get doing task\n", 1 );

		LPUNIT_DOING_TASK task_now;

		task_now = (LPUNIT_DOING_TASK) malloc( sizeof(UNIT_DOING_TASK) );

		if ( task_now == NULL )
		return task_now;


		task_now->unit_doing	=    the_unit;
		task_now->link_to_another_unit= the_unit_linked;///for attacking///following
		task_now->next			=    next_task;
		task_now->prev 			=    prev_task;
		task_now->going_to_x  	=    going_place_x;
		task_now->going_to_y	=    going_place_y;
		task_now->start_at_x 	=    start_place_x;
		task_now->start_at_y 	=    start_place_y;
		task_now->doing   		=    doing_task;
		task_now->time          =    arrival_time;
		task_now->start_time    =    start_trip_time;

		//debugfile ("going_to_x\n", going_place_x );
		//debugfile ("going_to_y\n", going_place_y );
		//debugfile ("start_at_x\n", start_place_x);
		//debugfile ("start_at_y\n", start_place_y );
		//debugfile ("time\n", arrival_time );
		//debugfile ("start_time\n", start_trip_time );
		if (task_now->unit_doing==(LPunit) NULL)
		{
			//debugfile ("task_now->unit_doing=FALSE\n", 1 );
		}
		//else  debugfile ("task_now->unit_doing=TRUE\n", 1 );

		if (task_now->next==(LPUNIT_DOING_TASK) NULL)
		{
			//debugfile ("task_now->task_now->next=FALSE\n", 1 );
		}
		//else  debugfile ("task_now->task_now->next=TRUE\n", 1 );

		if (task_now->prev==(LPUNIT_DOING_TASK) NULL)
		{
			//debugfile ("task_now->task_now->prev=FALSE\n", 1 );
		}
		//else  debugfile ("task_now->task_now->prev=TRUE\n", 1 );

	   return task_now;
}

////////////////////////////////////////////////////////////////////////////////
void find_unit_move_time (LPunit unit_finding_path, LPUNIT_DOING_TASK units_task)
{
		 //debugfile ("find unit move time\n", 1 );

		 dwCopy_time = timeGetTime();

		 double start_x=unit_finding_path->hex_x_loc;
		 double start_y=unit_finding_path->hex_y_loc;
		 double desti_x=units_task->going_to_x;
		 double desti_y=units_task->going_to_y;

		 double xdist= (start_x)  - (desti_x) ;
		 double ydist= (start_y)  - (desti_y) ;

		 xdist= abs ( xdist );
		 ydist= abs ( ydist );

		 double Distance= (sqrt ( (xdist*xdist)+(ydist*ydist) ) );
		 DWORD time= ( dwCopy_time + (Distance*Unit_Speed) );   // add distance  //note the value multiplied is the units speed (the larger:the slower)

		 units_task->time= time;
		 units_task->start_time=dwCopy_time;

		 //debugfile ("found unit arive time\n", time );
		 //debugfile ("found start time\n", dwCopy_time );
		 //debugfile ("total time\n", time-dwCopy_time );
}
////get new unit combat task/////////////////////////////////////////////////////////////
int get_new_combat_task (LPunit unit_in_combat, LPunit against_this_unit)
{
	//DWORD DWCombat_Time= (ATTACK_TIME*1000)+(dwCopy_time);
	unit_in_combat->task=get_doing_task	( 		unit_in_combat,
												against_this_unit,
												(LPUNIT_DOING_TASK) NULL,
												(LPUNIT_DOING_TASK) NULL,
												unit_in_combat->hex_x_loc,
												unit_in_combat->hex_y_loc,
												unit_in_combat->hex_x_loc,
												unit_in_combat->hex_y_loc,
												ATTACKING,
												10000+dwCopy_time,
												dwCopy_time    				 );

	Add_unit_Task ( unit_in_combat->task );

	return true;
}
////get new unit movement task//////////////////////////////////////////////////////////
void get_new_movement_task (LPunit unit_for_new_path)
{
	//debugfile ("get new task\n", 1 );
	int					going_to_x;
	int					going_to_y;

	///check if new path is on movement chain
	if (unit_for_new_path->going_path != (LPhex_path) NULL)
	{
	   if (unit_for_new_path->going_path->next_path_node != (LPhex_path) NULL)
	   {
			if (unit_for_new_path->going_path->next_path_node != (LPhex_path) NULL)
			{
				int next_path_node_creator=unit_for_new_path->going_path->next_path_node->direction_next_path_node;

				if (next_path_node_creator==EAST)
				{
					going_to_x= HEX_BORDER_E_X;
					going_to_y= HEX_BORDER_E_Y;
				}
				else if (next_path_node_creator==WEST)
				{
					going_to_x= HEX_BORDER_W_X;
					going_to_y= HEX_BORDER_W_Y;
				}
				else if (next_path_node_creator==NORTH_EAST)
				{
					going_to_x= HEX_BORDER_SE_X;
					going_to_y= HEX_BORDER_SE_Y;
				}
				else if (next_path_node_creator==NORTH_WEST)
				{
					going_to_x= HEX_BORDER_SW_X;
					going_to_y= HEX_BORDER_SW_Y;
				}
				else if (next_path_node_creator==SOUTH_EAST)
				{
					going_to_x= HEX_BORDER_NE_X;
					going_to_y= HEX_BORDER_NE_Y;
				}
				else if (next_path_node_creator==SOUTH_WEST)
				{
					going_to_x= HEX_BORDER_NW_X;
					going_to_y= HEX_BORDER_NW_Y;
				}
				///just in case
				else if (next_path_node_creator==CENTER)
				{
					going_to_x= HEX_CENTER_X;
					going_to_y= HEX_CENTER_Y;
				}
				else
				{
					going_to_x= HEX_BORDER_SW_X;
					going_to_y= HEX_BORDER_SW_Y;
				}
			 }
			 else    //go to center hex
			{
				debugfile ("Error going_to_centor section 1b\n", 1 );
				going_to_x = HEX_CENTER_X ;
				going_to_y = HEX_CENTER_Y ;
			}
		}
		else    //go to center hex
		{
			 debugfile ("Error going_to_centor section 1a\n", 1 );
			 going_to_x = HEX_CENTER_X ;
			 going_to_y = HEX_CENTER_Y ;
		}
	}
	else
	{
		going_to_x = HEX_CENTER_X ;
	    going_to_y = HEX_CENTER_Y ;

		debugfile ("ERROR no going_to_xy\n", 1 );
	}
	unit_for_new_path->task=get_doing_task	( 	unit_for_new_path,
												(LPunit) NULL,
												(LPUNIT_DOING_TASK) NULL,
												(LPUNIT_DOING_TASK) NULL,
												going_to_x,
												going_to_y,
												unit_for_new_path->hex_x_loc,
												unit_for_new_path->hex_y_loc,
												MOVING,
												NONE,
												NONE    				 );
	find_unit_move_time (unit_for_new_path, unit_for_new_path->task);
	Add_unit_Task ( unit_for_new_path->task );
}
////////////////////////
void set_unit_at_hex_x_y_going (LPunit the_unit)
{
	LPUNIT_DOING_TASK units_task = the_unit->task;
	if ( units_task != (LPUNIT_DOING_TASK) NULL)
	{
		the_unit->hex_x_loc = units_task->going_to_x;
		the_unit->hex_y_loc = units_task->going_to_y;
	}
}
///////////////////////////////////////////////////////////////////////////////
void Unit_arrive_at_desti (LPunit the_unit)
{
	 //debugfile ("unit arrived at desti\n", 1);
	 //force unit to be at hex coordinates that it was going
	// set_unit_at_hex_x_y_going (the_unit);

	 //remove task
	 Remove_units_going_task( the_unit->task );
	 the_unit->task = (LPUNIT_DOING_TASK) NULL;
	 remove_all_link_movement_chain (the_unit);
}

////////////////////////////////////////////////////////////////////////
int unit_entering_new_hex (LPunit unit_in_hex)
{
	//debugfile ("unit entering new hex\n", 1 );

	//befor we actualy enter hex, should check if hex not ocupied by foreign troop
	if (unit_in_hex->going_path != (LPhex_path) NULL)
	{
		//first check that there is a unit in next hex
		//find unit in next hex and call it Unit_in_next_hex
		LPunit Unit_in_next_hex=unit_in_hex->going_path->next_path_node->hex_this_path_node_at->unit_in_hex;
		if (   Unit_in_next_hex != (LPunit) NULL )	//if a unit is there
		{
			//then check if it is not same aligence
			if (   Unit_in_next_hex->aligence != unit_in_hex->aligence )
			{
                //if so
				//then stop the unit in its tracks
				//but not forgeting to get the direction of obstacle unit
				unit_in_hex->facing=unit_in_hex->going_path->next_path_node->direction_next_path_node;

				//clean up path, as this is now desti
				Unit_arrive_at_desti (unit_in_hex);

				if (unit_in_hex->task!=(LPUNIT_DOING_TASK) NULL)
				{
		   			Remove_units_going_task( unit_in_hex->task )  ;
		  		 	unit_in_hex->task = (LPUNIT_DOING_TASK) NULL;
				}
				if (unit_in_hex->going_path != (LPhex_path) NULL)
				{
					remove_all_link_movement_chain (unit_in_hex);
					unit_in_hex->going_path = (LPhex_path) NULL;
				}
				///get new path node
				LPhex_path path_now;
				path_now = (LPhex_path) malloc( sizeof(hex_path) );
				if ( path_now == NULL )
				{
					debugfile ("NO MEM path for unit movement\n", 1 );
				}
				path_now->hex_this_path_node_at = unit_in_hex->hex;
				path_now->next_path_node = (LPhex_path) NULL;
				path_now->direction_next_path_node = CENTER;
				unit_in_hex->going_path=path_now;

				//now check if ordered to attack or at war with intercepted units faction
				///on debug we will always attack ///so leave blank

				//then go to center of hex
				unit_in_hex->task=get_doing_task	( 	unit_in_hex,
												 Unit_in_next_hex,//a useful link to the attacked unit
												(LPUNIT_DOING_TASK) NULL,
												(LPUNIT_DOING_TASK) NULL,
												HEX_CENTER_X,
												HEX_CENTER_Y,
												unit_in_hex->hex_x_loc,
												unit_in_hex->hex_y_loc,
												MOVING_TO_ATTACK,
												NONE,
												NONE    				 );
				find_unit_move_time (unit_in_hex, unit_in_hex->task);
				Add_unit_Task ( unit_in_hex->task );

				//now pass the info to the unit in next hex so it can defend or attack

				//Direction of Unit_in_next_hex is oposite of facing unit_in_hex
				if (unit_in_hex->facing==EAST){Unit_in_next_hex->facing=WEST;}
				if (unit_in_hex->facing==WEST){Unit_in_next_hex->facing=EAST;}
				if (unit_in_hex->facing==NORTH_EAST){Unit_in_next_hex->facing=SOUTH_WEST;}
				if (unit_in_hex->facing==NORTH_WEST){Unit_in_next_hex->facing=SOUTH_EAST;}
				if (unit_in_hex->facing==SOUTH_EAST){Unit_in_next_hex->facing=NORTH_WEST;}
				if (unit_in_hex->facing==SOUTH_WEST){Unit_in_next_hex->facing=NORTH_EAST;}

				Unit_arrive_at_desti (Unit_in_next_hex); //clean up if on the move
				//note Unit_arrive_at_desti () and it links should have inbuilt securities
				//if any pointer is null, otherwise, well it doesnt bare thinking

				//not sure these below are necesary (along with those above
				//just overkill to be on safe side
				if (Unit_in_next_hex->task!=(LPUNIT_DOING_TASK) NULL)
				{
		   			Remove_units_going_task( Unit_in_next_hex->task )  ;
		  		 	Unit_in_next_hex->task = (LPUNIT_DOING_TASK) NULL;
				}
				if (Unit_in_next_hex->going_path != (LPhex_path) NULL)
				{
					remove_all_link_movement_chain (Unit_in_next_hex);
					Unit_in_next_hex->going_path = (LPhex_path) NULL;
				}

				///get new path node
				path_now = (LPhex_path) malloc( sizeof(hex_path) );
				if ( path_now == NULL )
				{
					debugfile ("NO MEM path for unit movement\n", 1 );
				}

				//path_now->hex_this_path_node_at = Unit_in_next_hex->hex;
				path_now->next_path_node = (LPhex_path) NULL;
				path_now->direction_next_path_node = CENTER;
				Unit_in_next_hex->going_path=path_now;

				//now check if ordered to attack or at war with intercepted units faction
				///on debug we will always attack ///so leave blank

				//then go to center of hex
				Unit_in_next_hex->task=get_doing_task	( 	Unit_in_next_hex,
												 unit_in_hex,//a useful link to the attacked unit
												(LPUNIT_DOING_TASK) NULL,
												(LPUNIT_DOING_TASK) NULL,
												HEX_CENTER_X,
												HEX_CENTER_Y,
												Unit_in_next_hex->hex_x_loc,
												Unit_in_next_hex->hex_y_loc,
												MOVING_TO_ATTACK,
												NONE,
												NONE    				 );
				find_unit_move_time (Unit_in_next_hex, Unit_in_next_hex->task);
				Add_unit_Task ( Unit_in_next_hex->task );


				return false;
			}
		}
	}

	//after it is ok to enter new hex a scan should be made to see neibouring troops


	//else enter hex and set new course

	int start_at_x;
	int	start_at_y;

	if (unit_in_hex->going_path != (LPhex_path) NULL)
	{
		 if (unit_in_hex->going_path->next_path_node->direction_next_path_node==EAST)
		 {
				start_at_x= HEX_BORDER_W_X;
				start_at_y= HEX_BORDER_W_Y;
		 }
		 else if (unit_in_hex->going_path->next_path_node->direction_next_path_node==WEST)
		 {


			 start_at_x= HEX_BORDER_E_X;
			 start_at_y= HEX_BORDER_E_Y;
		 }
		 else if (unit_in_hex->going_path->next_path_node->direction_next_path_node==NORTH_EAST)
		 {

			 start_at_x= HEX_BORDER_NW_X;
			 start_at_y= HEX_BORDER_NW_Y;

		 }

		 ///////////
		 else if (unit_in_hex->going_path->next_path_node->direction_next_path_node==NORTH_WEST)
		 {
			 start_at_x= HEX_BORDER_NE_X;
			 start_at_y= HEX_BORDER_NE_Y;
		 }
		 else if (unit_in_hex->going_path->next_path_node->direction_next_path_node==SOUTH_EAST)
		 {


			 start_at_x= HEX_BORDER_SW_X;
			 start_at_y= HEX_BORDER_SW_Y;
		 }
		 else if (unit_in_hex->going_path->next_path_node->direction_next_path_node==SOUTH_WEST)
		 {

			 start_at_x= HEX_BORDER_SE_X;
			 start_at_y= HEX_BORDER_SE_Y;

		 }
		 ///just in case
		 else if (unit_in_hex->going_path->next_path_node->direction_next_path_node==CENTER)
		 {
			 start_at_x= HEX_CENTER_X;
			 start_at_y= HEX_CENTER_Y;
		 }
		 ////debug///
		 else
		 {
			 start_at_x= HEX_CENTER_X;
			 start_at_y= HEX_CENTER_Y;
		 }
		 //set new values
		 unit_in_hex->hex_x_loc=start_at_x;
		 unit_in_hex->hex_y_loc=start_at_y;

		 //remove unit from old hex
		 RemoveUnitFromHex (  unit_in_hex   );

		 ///unit enters new hex

		 unit_in_hex->hex=unit_in_hex->going_path->next_path_node->hex_this_path_node_at;
		 Add_unit_to_hex (   unit_in_hex    );

		 //get units facing direction
		 unit_in_hex->facing=unit_in_hex->going_path->next_path_node->direction_next_path_node;

		 ///remove first link of movement chain LPhex_path
		 remove_first_link_movement_chain (unit_in_hex);
	}
	else
	{
         debugfile ("ERROR entering new hex\n", 1 );
    }
	return true;
}
///////////////////////////////////////////////////////////// /////////////////
void Unit_Task_waiting_list()
{

  // debugfile ("Unit_Task_waiting_list()\n", 1 );
   if ( g_top_unit_task != (LPUNIT_DOING_TASK) NULL  )
   {
		LPUNIT_DOING_TASK the_next_task=g_top_unit_task;

		dwCopy_time = timeGetTime();

	  for ( the_next_task=g_top_unit_task; the_next_task!=(LPUNIT_DOING_TASK) NULL; the_next_task=the_next_task->next )//debug: go through all
	  {

		if ( (the_next_task->time) <= ( dwCopy_time ) )
		{
			//debugfile ("g top unit task time up\n", 1 );
			LPunit theunit = the_next_task->unit_doing ;

			if (  theunit->task->doing == MOVING )
			{
				//check that unit has not reached last task
				if (the_next_task->unit_doing->going_path->next_path_node==(LPhex_path) NULL)
				{
					set_unit_at_hex_x_y_going (theunit);
					Unit_arrive_at_desti (theunit);

					////ai test: random high steward movement on capital
					if (theunit->aligence == HIGH_STEWARD )
					{
						//if ( Unit_Go_Random_Location (theunit) == false )
						{
							Unit_Wait_Random_Time ( theunit );
						}
					}

					//the_next_task=the_next_task->next;
					if ( the_next_task->next==(LPUNIT_DOING_TASK) NULL )
					{return;}
					else continue;
				}
				//define units new location
				//debugfile ("unit_entering_new_hex\n", 1 );
				if ( unit_entering_new_hex (theunit) == false )
					{
						//the_next_task=the_next_task->next;
						if ( the_next_task->next==(LPUNIT_DOING_TASK) NULL )
						{return;}
						else continue;
					}
				//remove task
				//debugfile ("Remove_units_going_task\n", 1 ) ;
				Remove_units_going_task( the_next_task );
				theunit->task = (LPUNIT_DOING_TASK) NULL;
				//get new task
				//debugfile ("get_new_task\n", 1 );
				get_new_movement_task (theunit);

				//the_next_task=the_next_task->next;
				if ( the_next_task==(LPUNIT_DOING_TASK) NULL )
					{return;}
				///else continue;
			}//end of if (theunit->task->doing == MOVING)

			else if (  theunit->task->doing == ATTACKING )
			{
				//unit finished moving into attack position
				//we need to know who is being attacked

				//start hostilities //debug
				//if (get_new_combat_task ( theunit, theunit->task->link_to_another_unit )==false)
				//	{return;}

				//debug//end hostilities
				Remove_units_going_task ( theunit->task );
				theunit->task = (LPUNIT_DOING_TASK) NULL;

		    }//end of: if (  theunit->task->doing == MOVING_TO_ATTACK )

			else if (  theunit->task->doing == MOVING_TO_ATTACK )
			{
				//unit finished moving into attack position
				//we need to know who is being attacked
				LPunit Unit_being_attacked = theunit->task->link_to_another_unit;
				//clean up movement tasks
				set_unit_at_hex_x_y_going (theunit);
			    Unit_arrive_at_desti (theunit);
				//start hostilities
				if (get_new_combat_task ( theunit, Unit_being_attacked )==false)
					{return;}

		    }//end of: if (  theunit->task->doing == MOVING_TO_ATTACK )

			else if (theunit->task->doing == WAITING)
			{

				//debugfile ("unit finnished waiting...get new task\n", 1 ) ;

				Remove_units_going_task ( theunit->task );
				theunit->task = (LPUNIT_DOING_TASK) NULL;

				//debugfile ("Removed_units_going_task ( theunit->task )\n", 1 ) ;

				 ////ai test: random high steward movement on capital
					if (theunit->aligence == HIGH_STEWARD )
					{
						if ( Unit_Go_Random_Location (theunit) == false )
						{
							Unit_Wait_Random_Time ( theunit );
						}
					}
				//debugfile ("waiting unit got new task\n", 1 );

			}///end of else if (theunit->task->doing == WAITING)

		}///end of if ( (the_next_task->time) <= ( dwCopy_time ) )

			//debugfile ("got_new_task\n", 1 );
			//debugfile ("***********\n", 1 );
			//debugfile ("info on new task\n", 1 );
			//if (g_top_unit_task == (LPUNIT_DOING_TASK) NULL )
			//{
				//debugfile ("ERROR, not top task\n", 1 );
			//}
			//if (g_top_unit_task == theunit->task )
			//{
				//debugfile ("top task is unit task\n", 1 );
				//debugfile ("going_to_x\n", theunit->task->going_to_x );
				//debugfile ("going_to_y\n", theunit->task->going_to_y );
				//debugfile ("start_at_x\n", theunit->hex_x_loc);
				//debugfile ("start_at_y\n", theunit->hex_y_loc );
				//debugfile ("time\n", theunit->task->time );
				//debugfile ("start_time\n", theunit->task->start_time );
				//if (g_top_unit_task->unit_doing==LPunit (NULL))
				//{
					//debugfile ("task_now->unit_doing=FALSE\n", 1 );
				//}
				//else
				//{
					//debugfile ("task_now->unit_doing=TRUE\n", 1 );
					//debugfile ("unit new hex X\n", g_top_unit_task->unit_doing->hex->X_hex_location );
					//debugfile ("unit new hex Y\n", g_top_unit_task->unit_doing->hex->Y_hex_location );
					//if (g_top_unit_task->unit_doing->hex->unit_in_hex==LPunit (NULL))
					//{
						//debugfile ("ERROR hex cant find new unit\n", 1 );
					//}
				//}

				//if (g_top_unit_task->next==LPUNIT_DOING_TASK (NULL))
				//{
					//debugfile ("task_now->task_now->next=FALSE\n", 1 );
				//}
				//else  debugfile ("task_now->task_now->next=TRUE\n", 1 );

				//if (g_top_unit_task->prev==LPUNIT_DOING_TASK (NULL))
				//{
					//debugfile ("task_now->task_now->prev=FALSE\n", 1 );
				//}
				//else  debugfile ("task_now->task_now->prev=TRUE\n", 1 );
			//}
		}//end of for ( the_next_task=g_top_unit_task; the_next_task!=(LPUNIT_DOING_TASK) NULL; the_next_task=the_next_task->next )//debug: go through all

   } //end of: if ( g_top_unit_task != (LPUNIT_DOING_TASK) NULL  )

}
///////////////////////////////////////////////////////////////////////////////

void Update_unit_pos_in_hex( LPunit first_unit_in_hex )
{
	// Go through each unit in the hex

	LPunit next_node = (LPunit) NULL;
	LPunit theunit;

	long unit_x_pos; long unit_y_pos;
	DWORD unit_time_loc;
	DWORD unit_time_total;
	long double unit_time_percent=0.01;

	dwCopy_time = timeGetTime();

	for ( theunit=first_unit_in_hex; theunit!=(LPunit)NULL; theunit=next_node )
	{

		next_node = theunit->next_in_hex;
		if (theunit->task != (LPUNIT_DOING_TASK) NULL)  //will need a securitty for none movement tasks//
		{


			if (  (theunit->task->doing == MOVING) ||
				  (theunit->task->doing == MOVING_TO_ATTACK) ||
		   		  (theunit->task->doing == INTERCEPTED)   )
			{
				//work out unit with tasks new position in percent of movement
				unit_time_loc  = ( dwCopy_time) - (theunit->task->start_time);
				unit_time_total= (theunit->task->time) - (theunit->task->start_time);
				unit_time_percent= unit_time_loc / (unit_time_total + 0.0000001);
				//now give unit its new position x and y from the percent
				theunit->hex_x_loc= theunit->task->start_at_x +
								( (	theunit->task->going_to_x - theunit->task->start_at_x)
									* (unit_time_percent) );

				theunit->hex_y_loc= theunit->task->start_at_y +
								( (theunit->task->going_to_y - theunit->task->start_at_y)
								*(unit_time_percent) );
			}
		}

	}

}


///////////////////////////////////////////////////////////////////////////////
int  find_path_unit ( LPunit unit_finding_path, LPhex hex_destination, LPplanet planet_on )
   {
		//debugfile ("find_path_unit\n", 1 );
		////////////
		//first check if unit does not already have path or task
		if (unit_finding_path->task!=(LPUNIT_DOING_TASK) NULL)
		{
		   Remove_units_going_task( unit_finding_path->task )  ;
		   unit_finding_path->task = (LPUNIT_DOING_TASK) NULL;
		}

		//error in doing this///check later why
		//if (unit_finding_path->going_path != (LPhex_path) NULL)
		//{
		//   remove_all_link_movement_chain (unit_finding_path)  ;
		//}

		int  start_XX=unit_finding_path->hex->X_hex_location;
		int  start_YY=unit_finding_path->hex->Y_hex_location;
		int dest_XX=hex_destination->X_hex_location;
		int dest_YY=hex_destination->Y_hex_location;
		int type_of_desty=NONE;
		int lengh_of_seek=2000;
		int type_of_value=ROAD;

		if ( set_up_path (start_XX, start_YY, dest_XX, dest_YY, type_of_desty,  planet_on, lengh_of_seek, type_of_value) == true)
		{

		   //unit_finding_path->desty_path = desti_hex_list;
		   unit_finding_path->going_path=(LPhex_path) NULL; //security
		   //go through list to find path
		   LPHEX_LIST temp_path;
		   for ( temp_path = desti_hex_list; temp_path != (LPHEX_LIST) NULL; temp_path=temp_path->creater )
		   {
				LPhex_path path_now;
				path_now = (LPhex_path) malloc( sizeof(hex_path) );
				if ( path_now == NULL )
				{
					debugfile ("NO MEM path for unit movement\n", 1 );
				}
				path_now->hex_this_path_node_at = planet_on->planet_matrice[temp_path->x_location][temp_path->y_location];
				path_now->next_path_node = unit_finding_path->going_path;
				path_now->direction_next_path_node = temp_path->creater_direction;
				unit_finding_path->going_path=path_now;
		   }
		   // free the search list
			LPHEX_LIST next_path = (LPHEX_LIST) NULL;
			for ( LPHEX_LIST temp_path=g_top_hex_list; temp_path != (LPHEX_LIST) NULL; temp_path=next_path )
					{
						next_path = temp_path->next;
						free( temp_path );
						free_nodes++;
					}
			g_bottom_hex_list= (LPHEX_LIST) NULL;
			g_top_hex_list= (LPHEX_LIST) NULL;
			desti_hex_list= (LPHEX_LIST) NULL;


		   ////debug info////
			//LPhex_path debug_test;
			//debugfile ("***************\n", 1 );
			//debugfile ("hex unit starting at X\n", unit_finding_path->hex->X_hex_location );
			//debugfile ("hex unit starting at Y\n", unit_finding_path->hex->Y_hex_location );

			//for ( debug_test = unit_finding_path->going_path ; debug_test != LPhex_path (NULL); debug_test=debug_test->next_path_node )
			//{
				//debugfile ("---------------\n", 1 );
				//debugfile ("hex_this_path_node_at X\n", debug_test->hex_this_path_node_at->X_hex_location );
				//debugfile ("hex_this_path_node_at Y\n", debug_test->hex_this_path_node_at->Y_hex_location );
				//if (debug_test->next_path_node==LPhex_path (NULL))
				//{
				   //debugfile ("next path node FALSE\n", debug_test->hex_this_path_node_at->Y_hex_location );
			   //	}
				//else
				//{
				   //debugfile ("next path node TRUE\n", debug_test->hex_this_path_node_at->Y_hex_location );
				//}

			   //	unsigned char direction_next_path_node;
			   //debugfile ("direction_next_path_node\n", debug_test->direction_next_path_node );
			//}
			////////////////
			get_new_movement_task (unit_finding_path);

			//debugfile ("find_path_unit true and got new task\n", 1 );

			return true;
		 }
	   return false;
   }

///////////////////////////////////////////////////////////////////////////////
int  find_path_ai_patrol ( LPunit unit_finding_path, int type_of_desty, LPplanet planet_on )
   {
		//debugfile ("find_path_unit\n", 1 );
		////////////
		//first check if unit does not already have path or task
		if (unit_finding_path->task!=(LPUNIT_DOING_TASK) NULL)
		{
		   Remove_units_going_task( unit_finding_path->task )  ;
		   unit_finding_path->task = (LPUNIT_DOING_TASK) NULL;
		}

		//error in doing this///check later why
		//if (unit_finding_path->going_path != (LPhex_path) NULL)
		//{
		//   remove_all_link_movement_chain (unit_finding_path)  ;
		//}

		int  start_XX=unit_finding_path->hex->X_hex_location;
		int  start_YY=unit_finding_path->hex->Y_hex_location;

		int lengh_of_seek=500;
		int type_of_value=ROAD;

		if ( set_up_path (start_XX, start_YY, NONE, NONE, type_of_desty,  planet_on, lengh_of_seek, type_of_value) == true)
		{

		   //unit_finding_path->desty_path = desti_hex_list;
		   unit_finding_path->going_path=(LPhex_path) NULL; //security
		   //go through list to find path
		   LPHEX_LIST temp_path;
		   for ( temp_path = desti_hex_list; temp_path != (LPHEX_LIST) NULL; temp_path=temp_path->creater )
		   {
				LPhex_path path_now;
				path_now = (LPhex_path) malloc( sizeof(hex_path) );
				if ( path_now == NULL )
				{
					debugfile ("NO MEM path for unit movement\n", 1 );
				}
				path_now->hex_this_path_node_at = planet_on->planet_matrice[temp_path->x_location][temp_path->y_location];
				path_now->next_path_node = unit_finding_path->going_path;
				path_now->direction_next_path_node = temp_path->creater_direction;
				unit_finding_path->going_path=path_now;
		   }
		   // free the search list
			LPHEX_LIST next_path = (LPHEX_LIST) NULL;
			for ( LPHEX_LIST temp_path=g_top_hex_list; temp_path != (LPHEX_LIST) NULL; temp_path=next_path )
					{
						next_path = temp_path->next;
						free( temp_path );
						free_nodes++;
					}
			g_bottom_hex_list= (LPHEX_LIST) NULL;
			g_top_hex_list= (LPHEX_LIST) NULL;
			desti_hex_list= (LPHEX_LIST) NULL;


			get_new_movement_task (unit_finding_path);

			//debugfile ("find_path_unit true and got new task\n", 1 );

			return true;
		 }
	   return false;
   }
