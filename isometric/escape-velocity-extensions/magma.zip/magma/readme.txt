author: Meowx Design and Animation (http://meowx.com/ and http://www.modenstudios.com/)
license: CC-BY-SA 3.0
source: http://opengameart.org/users/emr
        http://opengameart.org/content/magma-projectiles
        http://opengameart.org/content/magma-planets-and-moons
        http://opengameart.org/content/magma-items
        http://opengameart.org/content/magma-spacescapes
        http://opengameart.org/content/meowx-shipyard-large-number-of-spaceship-sprites

All sprites are coming Meowx's Magma mod fro Escape Velocity.

The items.png and imemps2x.png graphics was remasterd using https://github.com/nagadomi/waifu2x

Attribution Instructions: 
Include a link back to the author's website, http://www.meowx.com/ (which forwards to http://www.modenstudios.com/ which is the same site.)